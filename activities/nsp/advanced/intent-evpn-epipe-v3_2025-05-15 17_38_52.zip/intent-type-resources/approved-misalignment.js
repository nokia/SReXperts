load({ script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk' });
load({ script: resourceProvider.getResource('sf-logger.js'), name: 'ServiceFulfillmentLogger' });

function ApprovedMisAlignmentFWK() {
    this.sfLogger = new ServiceFulfillmentLogger();
    this.nspMediatorFwk = new MediatorFramework("NSP");
    this.nfmpMediatorFwk = new MediatorFramework("NFMP");
}

ApprovedMisAlignmentFWK.prototype.nfmpResolveSynchronize = function (intentType, target, device, serviceMgrId, config) {
    this.sfLogger.info("resolving config for intent-type: {}, target: {}, device: {}, serviceMgrId: {}, config: {}", intentType, target, device, serviceMgrId, config);
    let sitePayload;

    try{
        sitePayload = JSON.parse(config);//config is string
    } catch (e){
        sitePayload = config;//config is object
    }

    if (sitePayload && sitePayload.hasOwnProperty("distinguishedName") && sitePayload.hasOwnProperty("objectFullName") && sitePayload.hasOwnProperty("childConfigInfo")) {   
        config = sitePayload;
    } else {
        let nfmpSiteClassName = Object.keys(sitePayload)[0];
        let serviceFdn = serviceMgrId.replace(":" + device, "");

        config = {
            "distinguishedName": serviceFdn,
            "objectFullName": serviceFdn + ":" + device,
            "childConfigInfo": {}
        }

        config["childConfigInfo"][nfmpSiteClassName] = sitePayload[nfmpSiteClassName][0];
    }

    config["intent-type"] = intentType;
    config["target"] = encodeURIComponent(target);//target will be same as service name
    config["device-name"] = encodeURIComponent(target);

    // Call the mediator to resolve config
    const resolveResponse = this.nfmpMediatorFwk.post("/resolve-synchronize", config);

    if (resolveResponse.success) {
        const parsedResponse = JSON.parse(resolveResponse.response);
        this.sfLogger.debug("resolved config report: {}", JSON.stringify(parsedResponse, null, 4));
        return parsedResponse;
    } else {
        throw new Error(resolveResponse.response);
    }
}

ApprovedMisAlignmentFWK.prototype.resolveSynchronize = function (intentType, target, deviceName, rootXPath, config) {
    this.sfLogger.info("resolving config for intent-type: {}, target: {}, device-name: {}, root-xpath: {}, config: {}",
        intentType, target, deviceName, rootXPath, config);
    const unresolvedConfig = {
        "intent-type": intentType,
        "target": Java.type("java.net.URLEncoder").encode(target, "UTF-8").replaceAll("\\+", "%20"),
        "device-name": deviceName,
        "root-xpath": rootXPath,
        "intent-configuration": config
    };

    // Call the mediator to resolve config
    const resolveResponse = this.nspMediatorFwk.post("/resolve-synchronize", unresolvedConfig);

    if (resolveResponse.success) {
        const parsedResponse = JSON.parse(resolveResponse.response);
        this.sfLogger.debug("resolved config report: " + parsedResponse);
        return parsedResponse;
    } else {
        throw new Error(resolveResponse.response);
    }
}

ApprovedMisAlignmentFWK.prototype.resolveAudit = function (unresolvedAuditReport) {
    // Convert audit report from java to JSON
    const unresolvedAuditReportJson = {
        "target": encodeURIComponent(unresolvedAuditReport.getTarget()),
        "intent-type": unresolvedAuditReport.getIntentType()
    };

    // Handle misaligned attributes if any
    if (unresolvedAuditReport.getMisAlignedAttributes()) {
        unresolvedAuditReportJson["misaligned-attribute"] = [];
        // For each misAlignedAttribute convert to json
        unresolvedAuditReport.getMisAlignedAttributes().forEach(function (misAlignedAttribute) {
            const misAlignedAttributeJson = {
                "name": misAlignedAttribute.getName(),
                "device-name": misAlignedAttribute.getDeviceName(),
                "expected-value": misAlignedAttribute.getExpectedValue(),
                "actual-value": misAlignedAttribute.getActualValue(),
            };
            unresolvedAuditReportJson["misaligned-attribute"].push(misAlignedAttributeJson);
        });
    }

    // Handle misaligned objects if any
    if (unresolvedAuditReport.getMisAlignedObjects()) {
        unresolvedAuditReportJson["misaligned-object"] = [];
        // For each misaligned object convert to json
        unresolvedAuditReport.getMisAlignedObjects().forEach(function (misAlignedObject) {
            const misAlignedObjectJson = {
                "object-id": misAlignedObject.getObjectId(),
                "device-name": misAlignedObject.getDeviceName(),
                "is-configured": misAlignedObject.isConfigured(),
                "is-undesired": misAlignedObject.isUndesired()
            };
            unresolvedAuditReportJson["misaligned-object"].push(misAlignedObjectJson);
        });
    }

    this.sfLogger.info("unresolved audit report: {}", JSON.stringify(unresolvedAuditReportJson));

    // Create a new audit report to send back
    const resolvedAuditReport = auditFactory.createAuditReport(unresolvedAuditReport.getIntentType(), unresolvedAuditReport.getTarget());

    // Call the mediator to resolve audit report
    let resolveResponse = this.nspMediatorFwk.post("/resolve-audit", unresolvedAuditReportJson);

    if (resolveResponse.success) {
        const resolvedAuditReportJson = JSON.parse(resolveResponse.response);
        this.sfLogger.info("resolved audit report: " + resolveResponse);
        for (let i = 0; i < resolvedAuditReportJson["misaligned-attribute"].length; i++) {
            const attributeData = resolvedAuditReportJson["misaligned-attribute"][i];
            const misalignedAttribute = auditFactory.createMisAlignedAttribute(
                attributeData.name, attributeData["expected-value"], attributeData["actual-value"], attributeData["device-name"]);
            resolvedAuditReport.addMisAlignedAttribute(misalignedAttribute);
        }

        for (let i = 0; i < resolvedAuditReportJson["misaligned-object"].length; i++) {
            let misalignedObjectAttribute = resolvedAuditReportJson["misaligned-object"][i];
            let misalignedObject = auditFactory.createMisAlignedObject(
                misalignedObjectAttribute["object-id"], misalignedObjectAttribute["is-configured"], misalignedObjectAttribute["device-name"], misalignedObjectAttribute["is-undesired"]);
            resolvedAuditReport.addMisAlignedObject(misalignedObject);
        }
    } else {
        throw new Error(resolveResponse.response);
    }

    return resolvedAuditReport;
};

ApprovedMisAlignmentFWK.prototype.deleteApprovedChanges = function (intentType,target) {
    //This should run on delete of intent to clean up the related artifacts
    let baseRestconfUrl = "https://restconf-gateway/restconf/data/nsp-intent-approved-changes:approved-change/approved-changes";
    let url = baseRestconfUrl+"="+encodeURIComponent(intentType)+','+encodeURIComponent(target)+'/';
    let deleteResponse = this.nspMediatorFwk.delete(url);
    if(deleteResponse.success || deleteResponse.response.indexOf("does not exist") !== -1){
        return deleteResponse;
    }else{
        return null;
    }
};
