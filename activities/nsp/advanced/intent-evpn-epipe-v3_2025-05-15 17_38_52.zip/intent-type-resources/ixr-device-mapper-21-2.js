function IxrDeviceMapper212(sfLogger) {
    SrDeviceMapper212.call(this)
    if (sfLogger){
        this.sfLogger = sfLogger;
        this.srSvcFwk = new SrSvcFwk(sfLogger);
    }
}

IxrDeviceMapper212.prototype = Object.create(SrDeviceMapper212.prototype);
IxrDeviceMapper212.prototype.constructor = IxrDeviceMapper212;

/*
   function: mapToDeviceModel
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model
 */
IxrDeviceMapper212.prototype.mapToDeviceModel = function (templateArgs, siteId, target, requestContext) {
    this.sfLogger.debug("IxrDeviceMapper212 Device:{}", siteId);
    let payload = new SrDeviceMapper212().mapToDeviceModel(templateArgs, siteId, target, requestContext);
    if (payload["bgp-evpn"] && payload["bgp-evpn"]["mpls"]){
        payload["bgp-evpn"]["mpls"].forEach(function (lMpls) {
            delete lMpls["force-vc-forwarding"];
        })
    }
    return payload
};
