function IxrDeviceMapper(sfLogger) {
    SrDeviceMapper.call(this)
    if (sfLogger){
        this.sfLogger = sfLogger;
        this.srSvcFwk = new SrSvcFwk(sfLogger);
    }
}

IxrDeviceMapper.prototype = Object.create(SrDeviceMapper.prototype);
IxrDeviceMapper.prototype.constructor = IxrDeviceMapper;


/*
   function: mapToDeviceModel
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model
 */
IxrDeviceMapper.prototype.mapToDeviceModel = function (templateArgs, siteId, target, requestContext) {
    let payload = new SrDeviceMapper().mapToDeviceModel(templateArgs, siteId, target, requestContext);
    if (payload["bgp-evpn"] && payload["bgp-evpn"]["mpls"]){
        payload["bgp-evpn"]["mpls"].forEach(function (lMpls) {
            delete lMpls["force-vc-forwarding"];
        })
    }
    return payload
};
