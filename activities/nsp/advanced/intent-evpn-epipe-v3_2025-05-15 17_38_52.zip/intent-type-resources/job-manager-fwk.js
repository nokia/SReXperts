load({script: resourceProvider.getResource('nfmp-mapper.js'), name: 'nfmp-mapper'});
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk'});
var HashMap = Java.type('java.util.HashMap');

function JobManagerFwk(requestContext, sfLogger, nfmpMapper) {
    this.svcObjMap = requestContext.get("svcObjMap");
    this.svcTopo = requestContext.get("currentTopology");
    this.managedTasks = [];
    this.mediatorFwk = new MediatorFramework("NSP");

    this.intentType = requestContext.get("intentType");
    this.intentVersion = requestContext.get("intentTypeVersion");
    this.target = requestContext.get("target");

    if (nfmpMapper) {
        this.nfmpMapper = nfmpMapper;
    } else if (sfLogger) {
        this.nfmpMapper = new NfmpMapper(sfLogger);
    } else {
        this.nfmpMapper = new NfmpMapper();
    }

    if (sfLogger) {
        this.sfLogger = sfLogger;
    }
    this.nfmpMediators = new HashMap();
}

JobManagerFwk.prototype.managedTasks = [];
JobManagerFwk.prototype.svcObjMap = null;
JobManagerFwk.prototype.svcTopo = null;
JobManagerFwk.prototype.RESTCONF_HOST = "restconf-gateway";
JobManagerFwk.prototype.RESTCONF_PORT = "443";
JobManagerFwk.prototype.mediatorFwk = null;
JobManagerFwk.prototype.JOB_MANAGER_URL = "/restconf/data/nsp-jobs-manager:jobs-manager";
JobManagerFwk.prototype.svcOperModelFwk = null;
JobManagerFwk.prototype.sfLogger = new ServiceFulfillmentLogger();
JobManagerFwk.prototype.nfmpMapper = null;
JobManagerFwk.prototype.nfmpUrl = "v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true";
JobManagerFwk.prototype.nspRestconfFwk = new NspRestconfFwk();
JobManagerFwk.prototype.nfmpMediators = new HashMap();

JobManagerFwk.prototype.constructNfmpUrl = function (mediatorName) {
    if (!mediatorName)
        return "http://nsp-mdt-nfmp-mediator-svc/"
    else {
        let mediatorManager = mds.getManagerByName(mediatorName);
        return mediatorManager.getProtocol() + "://" + mediatorManager.getIp() + ":" + mediatorManager.getPort() + "/";
    }
}
/*
   function: constructTaskPayload
    since: NSP 21.11
    short_description: Generate Job Manager task payload
    description:
        - Generate MDM task with proper header
        - Generate NFMP task with proper header
    input:
        method:
          description: POST/PUT/PATCH/DELETE
          type: String
          mandatory: True
        pathUrl:
          description: URL of the device path
          type: String
          mandatory: True
        payload:
          description: task payload
          type: String
          mandatory: True
        deviceId:
          description: NE system ID
          type: String
          mandatory: True
        mediation:
          description: MDM/NFMP
          type: String
          mandatory: True
        order:
          description: deployment order
          type: String
          mandatory: False
        editIds:
          description: Yang patch EditIds for MDM managed nodes
          type: String
          mandatory: False
    output:
      payload:
        type: String
        description: JobManager Task Payload
    examples:
      "function call": |
        this.constructTaskPayload("PATCH", pathUrl, payload, deviceId, "MDM", order, editIds)
    example_responses:
      payload: |
        result:
          "{
          "url": "https://restconf-gateway:443/restconf/data/nsp-network:network/node=3.3.3.3/node-root/nokia-conf:/configure/service?client-context=ibsf:epipe:1:test24",
          "method": "PATCH",
          "task-name": "Node-3.3.3.3-1-1636389715770",
          "order": 1,
          "priority": 10,
          "type": "nsp-jobs-manager-tasks:task-restconf",
          "meta": "{\"intenttype\":\"epipe\",\"intentversion\":\"1\",\"target\":\"test24\",\"mediation\":\"MDM\",\"edit-ids\":[\"config-epipe-1\"]}",
          "payload": "{\"ietf-yang-patch:yang-patch\":{\"patch-id\":\"edit-epipe-1\",\"edit\":[{\"edit-id\":\"config-epipe-1\",\"target\":\"/epipe=test24\",\"operation\":\"replace\",\"value\":{\"service-name\":\"test24\",\"description\":\"test description changed\",\"customer\":\"1\",\"admin-state\":\"enable\",\"service-id\":33,\"service-mtu\":1400,\"sap\":[{\"sap-id\":\"1/1/12:4.1\",\"description\":\"sap description1\",\"admin-state\":\"enable\"}]}}]}}",
          "headers": [
            "Content-Type: application/yang-patch+json",
            "Accept: application/yang-data+json"
          ]
        }"
*/
JobManagerFwk.prototype.constructTaskPayload = function (method, pathUrl, payload, deviceId, mediation, order, editIds) {
    if (!order)
        order = 1;
    let  ret = {
        "url": pathUrl,
        "method": method,
        "task-name": "Node-" + deviceId + "-" + order + "-" + Date.now(),
        "order": order,
        "priority": 10,
        "queue-name":"high",
        "type": "nsp-jobs-manager-tasks:task-restconf",
        "meta": {
            "intenttype": this.intentType,
            "intentversion": this.intentVersion,
            "target": this.target
        }
    };
    if (payload)
        ret["payload"] = JSON.stringify(payload);
    if (mediation === "MDM") {
        ret ["headers"] = [
            "Content-Type: application/yang-patch+json",
            "Accept: application/yang-data+json"
        ];
        ret["meta"]["mediation"] = "MDM";
        ret["meta"]["edit-ids"] = editIds;

    } else if (mediation === "MDMAMI") {
        ret ["headers"] = [
            "Content-Type: application/json",
            "Accept: application/json"
        ];
        ret["meta"]["mediation"] = "MDM";

    } else {
        ret ["headers"] = [
            "Content-Type: application/json",
            "Accept: application/json"
        ];
        ret["meta"]["mediation"] = "NFMP";
    }

    if (mediation === "NFMP" && method === "DELETE")
        ret["payload"] = "";

    ret ["meta"] = JSON.stringify(ret["meta"]);
    return ret;
};

/*
   function: send
    since: NSP 21.11
    short_description: Execute payload to Job manager
    description:
        - send the payload to job manager
*/
JobManagerFwk.prototype.send = function () {
    this.sfLogger.debug("Job Manager {}", JSON.stringify(this.managedTasks, null, 2));
    let  url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + this.JOB_MANAGER_URL;
    let  payload = {
        "nsp-jobs-manager:managed-jobs": [
            {
                "name": this.intentType + "_" + this.target + "_" + Date.now(),
                "reference": JSON.stringify(
                    {
                        "intenttype": this.intentType,
                        "intentversion": this.intentVersion,
                        "target": this.target
                    }),
                "owner": "ibsf",
                "managed-tasks": this.managedTasks
            }
        ]
    };
    let  response = this.mediatorFwk.post(url, payload);
    this.sfLogger.debug("[JobManagerFwk][findByXpath] response = {}", JSON.stringify(response));

    if (!response.success) {
        throw new RuntimeException("Failed to create Job: " + JSON.stringify(response["response"]));
    }
};

/*
   function: mdmYangPatchTask
    since: NSP 21.11
    short_description: MDM Yang patch task generate - MDC
    description:
        - Generate MDC/Deployer App Cut thought adapter deployment task
    input:
        deviceId:
          description: NE system ID
          type: String
          mandatory: True
        pathUrl:
          description: URL of the device path
          type: String
          mandatory: True
        payload:
          description: task payload
          type: String
          mandatory: True
        order:
          description: deployment order
          type: String
          mandatory: False
      alienMediatorName:
          description: HCO - MDC Alien mediator name
          type: String
          mandatory: False
    output:
      payload:
        type: String
        description: MDC Yang Patch Payload
    example_responses:
      payload: |
        result:
          "{
          "url": "https://restconf-gateway:443/restconf/data/nsp-network:network/node=3.3.3.3/node-root/nokia-conf:/configure/service?client-context=ibsf:epipe:1:test24",
          "method": "PATCH",
          "task-name": "Node-3.3.3.3-1-1636389715770",
          "order": 1,
          "priority": 10,
          "type": "nsp-jobs-manager-tasks:task-restconf",
          "meta": "{\"intenttype\":\"epipe\",\"intentversion\":\"1\",\"target\":\"test24\",\"mediation\":\"MDM\",\"edit-ids\":[\"config-epipe-1\"]}",
          "payload": "{\"ietf-yang-patch:yang-patch\":{\"patch-id\":\"edit-epipe-1\",\"edit\":[{\"edit-id\":\"config-epipe-1\",\"target\":\"/epipe=test24\",\"operation\":\"replace\",\"value\":{\"service-name\":\"test24\",\"description\":\"test description changed\",\"customer\":\"1\",\"admin-state\":\"enable\",\"service-id\":33,\"service-mtu\":1400,\"sap\":[{\"sap-id\":\"1/1/12:4.1\",\"description\":\"sap description1\",\"admin-state\":\"enable\"}]}}]}}",
          "headers": [
            "Content-Type: application/yang-patch+json",
            "Accept: application/yang-data+json"
          ]
        }"
*/
JobManagerFwk.prototype.mdmYangPatchTask = function (deviceId, pathUrl, payload, order, alienMediatorName) {
    if (!order)
        order = 1;
    let  editIds = payload["ietf-yang-patch:yang-patch"]["edit"].map(function (el) {
        el["edit-id"] = el["edit-id"] + "_" + Math.random();
        return el["edit-id"];
    });
    if (pathUrl.indexOf("nsp-network:network") !== -1){
        pathUrl += "&policy-name=ibsf"
    }
    if (alienMediatorName) {
        let mediatorManager = mds.getManagerByName(alienMediatorName.replace("MDC", "NSP"));
        pathUrl = mediatorManager.getProtocol() + "://" + mediatorManager.getIp() + "/" + pathUrl;
    }
    this.managedTasks.push(this.constructTaskPayload("PATCH", pathUrl, payload, deviceId, "MDM", order, editIds));
};

/*
   function: mdmPostTask
    since: NSP 21.11
    short_description: MDM Deployer App POST Create - AMI Payload generation
    input:
        deviceId:
          description: NE system ID
          type: String
          mandatory: True
        pathUrl:
          description: URL of the device path
          type: String
          mandatory: True
        payload:
          description: task payload
          type: String
          mandatory: True
        order:
          description: deployment order
          type: String
          mandatory: False
    output:
      payload:
        type: String
        description: MDC Yang Patch Payload
*/
JobManagerFwk.prototype.mdmPostTask = function (deviceId, pathUrl, payload, order) {
    if (!order)
        order = 1;
    this.managedTasks.push(this.constructTaskPayload("POST", pathUrl, payload, deviceId, "MDMAMI", order, null));
};

/*
   function: mdmDeleteTask
    since: NSP 21.11
    short_description: MDM Deployer App DELETE Create - AMI Payload generation
    input:
        deviceId:
          description: NE system ID
          type: String
          mandatory: True
        pathUrl:
          description: URL of the device path
          type: String
          mandatory: True
        payload:
          description: task payload
          type: String
          mandatory: True
        order:
          description: deployment order
          type: String
          mandatory: False
    output:
      payload:
        type: String
        description: MDC Yang Patch Payload
*/
JobManagerFwk.prototype.mdmDeleteTask = function (deviceId, pathUrl) {
    this.managedTasks.push(this.constructTaskPayload("DELETE", pathUrl, {}, deviceId, "MDMAMI", 1, null));
};

/*
   function: nfmpTask
    since: NSP 21.11
    short_description: NFMP Payload generate
    input:
        preServiceDeployResponse:
          description: If service payload generation needs another NFMP object
          type: String
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
    output:
      payload:
        type: String
        description: MDC Yang Patch Payload
    example_responses:
      payload: |
        result:
          "{
              "nsp-jobs-manager:managed-jobs": [
                {
                  "name": "epipe_test24_1636393162915",
                  "reference": "{\"intenttype\":\"epipe\",\"intentversion\":\"1\",\"target\":\"test24\"}",
                  "owner": "ibsf",
                  "managed-tasks": [
                    {
                      "url": "http://nsp-mdt-nfmp-mediator-svc/v3/synchronize?synchronousDeploy=true",
                      "method": "POST",
                      "task-name": "Node-NFMP-1-1636393162914",
                      "order": 1,
                      "priority": 10,
                      "type": "nsp-jobs-manager-tasks:task-restconf",
                      "meta": "{\"intenttype\":\"epipe\",\"intentversion\":\"1\",\"target\":\"test24\",\"mediation\":\"NFMP\"}",
                      "payload": "{\"distinguishedName\":\"svc-mgr\",\"childConfigInfo\":{\"epipe.Epipe\":{\"displayedName\":\"test24\",\"serviceId\":32,\"description\":\"svc description\",\"nsdManaged\":\"true\",\"id\":\"2000000002\",\"subscriberPointer\":\"subscriber:1\",\"administrativeState\":\"down\",\"children-Set\":{\"epipe.Site\":[{\"displayedName\":\"asdsd\",\"siteId\":\"1.1.1.1\",\"mtu\":555,\"description\":\"site description\",\"children-Set\":{\"vll.L2AccessInterface\":[{\"outerEncapValue\":1,\"innerEncapValue\":1,\"description\":\"sap description1\",\"children-Set\":{\"service.IngressSchedulerPolicyEntryOverride\":[{\"schedulerPolicyEntryDisplayedName\":\"Scheduler_Ingress_1\",\"pir\":23,\"cir\":\"-1\"}],\"service.IngressAccessPolicyQueueOverride\":[{\"accessPolicyQueueId\":1,\"pir\":23,\"cir\":\"-1\",\"committedBurstSize\":66666,\"maximumBurstSize\":5555}],\"service.SapIngressPolicerOverride\":[{\"accessPolicyId\":\"987\",\"policerId\":2,\"cbs\":4441,\"mbs\":4441}],\"service.EgressAccessPolicyQueueOverride\":[{\"accessPolicyQueueId\":1,\"committedBurstSize\":66666,\"maximumBurstSize\":5555}]},\"portPointer\":\"network:1.1.1.1:shelf-1:cardSlot-1:card:daughterCardSlot-1:daughterCard:port-12\",\"administrativeState\":\"serviceUp\",\"ingressSchedulerObjectPointer\":\"Scheduler:Scheduler_Policy_1\",\"ingressPolicerPolicyPointer\":\"hPolicing:policerPo2\",\"ingressPolicyObjectPointer\":\"Access Ingress:987\",\"egressSchedulerObjectPointer\":\"Scheduler:Scheduler_Policy_1\",\"egressPolicerPolicyPointer\":\"hPolicing:policerPo2\",\"egressPolicyObjectPointer\":\"Access Egress:987\"}],\"svt.SpokeSdpBinding\":[{\"tunnelSelectionTerminationSiteId\":\"0.0.0.0\",\"pathId\":3,\"vcId\":1006666,\"description\":\"sdp description\",\"administrativeState\":\"circuitUp\",\"vcType\":\"vlan\"}]}},{\"displayedName\":\"test24\",\"siteId\":\"4.4.4.4\",\"mtu\":555,\"children-Set\":{\"vll.L2AccessInterface\":[{\"outerEncapValue\":1,\"innerEncapValue\":1,\"description\":\"sap description\",\"children-Set\":{},\"portPointer\":\"network:4.4.4.4:shelf-1:cardSlot-1:card:daughterCardSlot-1:daughterCard:port-12\",\"administrativeState\":\"serviceUp\"}],\"svt.SpokeSdpBinding\":[{\"tunnelSelectionTerminationSiteId\":\"0.0.0.0\",\"pathId\":3,\"vcId\":1006666,\"description\":\"sdp description\",\"administrativeState\":\"circuitUp\",\"vcType\":\"vlan\"}]}}]}}}}",
                      "headers": [
                        "Content-Type: application/json",
                        "Accept: application/json"
                      ]
                    }
                  ]
                }
              ]
            }"
*/
JobManagerFwk.prototype.nfmpTask = function (preServiceDeployResponse, requestContext) {
    let self = this;
    let lnfmpMedItr = this.nfmpMediators.keySet().iterator();
    while (lnfmpMedItr.hasNext()) {
        let lMediatorName = lnfmpMedItr.next();
        let lSvcObj = JSON.parse(JSON.stringify(this.svcObjMap));
        if (requestContext.get("intentType") !== "tunnel" && this.nfmpMediators.get(lMediatorName)) {
            let lSvcMgrId = this.nfmpMediators.get(lMediatorName).split("-");
            lSvcObj["serviceMgrId"] = lSvcMgrId[lSvcMgrId.length - 1];
        }
        let nfmpPayload = this.nfmpMapper.mapToNfmpSvc(lSvcObj, {}, preServiceDeployResponse, this.svcTopo, requestContext.get("isCreate"), requestContext);
        if (Array.isArray(nfmpPayload)) {
            let  count = 1;
            nfmpPayload.forEach(function (lPayload) {
                self.managedTasks.push(self.constructTaskPayload("POST", self.constructNfmpUrl(lMediatorName) + self.nfmpUrl, lPayload, "NFMP" + count++, "NFMP", 1, null));
            })
        } else if (nfmpPayload) {
            if (!nfmpPayload["objectFullName"] && requestContext.get("intentType") !== "tunnel" && this.nfmpMediators.get(lMediatorName)) {
                nfmpPayload["objectFullName"] = this.nfmpMediators.get(lMediatorName);
            } else if (!nfmpPayload["objectFullName"] && requestContext.get("intentType") !== "tunnel" && this.nfmpMediators.get("NFM-P"))
                nfmpPayload["objectFullName"] = this.nfmpMediators.get("NFM-P");
            else {
                nfmpPayload["objectFullName"] = requestContext.get("svcObjMap")["serviceMgrId"]
            }
            this.managedTasks.push(this.constructTaskPayload("POST", this.constructNfmpUrl(lMediatorName) + this.nfmpUrl, nfmpPayload, "NFMP", "NFMP", 1, null));
        }

    }
};

/*
   function: nfmpSecondaryTask
    since: NSP 21.11
    short_description: NFMP Payload generate
    description:
        - Generate NFMP payload with higher order than service deployment to handle post deployment task
    input:
        payload:
          description: NFMP Payload
          type: String
          mandatory: True
        order:
          description: deployment order
          type: String
          mandatory: False
        alienMediatorName:
          description: HCO - NFMP Alien mediator name
          type: String
          mandatory: False
*/
JobManagerFwk.prototype.nfmpSecondaryTask = function (payload, order, alienMediatorName) {
    if (!order)
        order = 3;
    this.managedTasks.push(this.constructTaskPayload("POST", this.constructNfmpUrl(alienMediatorName) + this.nfmpUrl, payload, "NFMP", "NFMP", order, null));
};

/*
   function: nfmpDelete
    since: NSP 21.11
    short_description: NFMP Payload Delete payload generate
    input:
        fdn:
          description: NFMP fdn to be deleted
          type: String
          mandatory: True
        order:
          description: deployment order
          type: String
          mandatory: False
        alienMediatorName:
          description: HCO - NFMP Alien mediator name
          type: String
          mandatory: False
    output:
      payload:
        type: String
        description: NFMP delete payload
*/
JobManagerFwk.prototype.nfmpDelete = function (fdn, order, count, alienMediatorName) {
    return this.constructTaskPayload("DELETE", this.constructNfmpUrl(alienMediatorName) + "v3/delete/" + fdn + "?synchronousDeploy=true&clearOnDeployFailure=true", null, "NFMP-" + count + Date.now(), "NFMP", order, null);
};

/*
   function: nfmpDeleteTask
    since: NSP 21.11
    short_description: Order NFMP FDN for deletion
    input:
        deleteNfmpDeploy:
          description: object that holds FDN before and after service FDN
          type: Object
          mandatory: True
        serviceFdn:
          description: Actual Service FDN to be deleted
          type: String
          mandatory: True
        alienMediatorName:
          description: HCO - NFMP Alien mediator name
          type: String
          mandatory: False
*/
JobManagerFwk.prototype.nfmpDeleteTask = function (deleteNfmpDeploy, serviceFdn, nfmpAlienMediator) {
    let count = 1;
    let self = this;
    if (deleteNfmpDeploy && deleteNfmpDeploy.preDeleteFdn && deleteNfmpDeploy.preDeleteFdn.length > 0) {
        deleteNfmpDeploy.preDeleteFdn.forEach(function (lFdn) {
            self.managedTasks.push(self.nfmpDelete(lFdn, 1, count++));
        });
    }

    if (serviceFdn) this.managedTasks.push(this.nfmpDelete(serviceFdn, 2, count++, nfmpAlienMediator));

    if (deleteNfmpDeploy && deleteNfmpDeploy.postDeleteFdn && deleteNfmpDeploy.postDeleteFdn.length > 0) {
        deleteNfmpDeploy.postDeleteFdn.forEach(function (lFdn) {
            self.managedTasks.push(self.nfmpDelete(lFdn, 3, count++));
        });
    }
};

/*
   function: appendNFMPSitePayload
    since: NSP 21.11
    short_description: Generate site payload to job manager
    input:
        sitePayload:
          description: Site payload object
          type: Object
          mandatory: True
        serviceMgrId:
          description: NFMP Service Manager ID
          type: String
          mandatory: True
        device:
          description: NFMP NE ID
          type: String
          mandatory: True
        alienMediatorName:
          description: HCO - NFMP Alien mediator name
          type: String
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
*/
JobManagerFwk.prototype.appendNFMPSitePayload = function (sitePayload, serviceMgrId, device, alienMediatorName, requestContext) {
    let nfmpSitePayload = null;
    let serviceFdn = serviceMgrId.replace(":"+device,"");
    if (sitePayload && sitePayload.hasOwnProperty("distinguishedName") && sitePayload.hasOwnProperty("objectFullName") && sitePayload.hasOwnProperty("childConfigInfo")) {
        nfmpSitePayload = sitePayload;
    } else {
        let nfmpSiteClassName = Object.keys(sitePayload)[0];

        nfmpSitePayload = {
            "distinguishedName": serviceFdn,
            "objectFullName": serviceFdn + ":" + device,
            "childConfigInfo": {}
        }
        nfmpSitePayload["childConfigInfo"][nfmpSiteClassName] = sitePayload[nfmpSiteClassName][0];
        if (!requestContext.get("nfmpSitePayload")) {
            requestContext.put("nfmpSitePayload", {});
        }
        if (!(nfmpSiteClassName in requestContext.get("nfmpSitePayload"))) {
            requestContext.get("nfmpSitePayload")[nfmpSiteClassName] = [];
        }
        requestContext.get("nfmpSitePayload")[nfmpSiteClassName] = requestContext.get("nfmpSitePayload")[nfmpSiteClassName].concat(sitePayload[nfmpSiteClassName]);
    }
    if (alienMediatorName){
        this.nfmpMediators.put(alienMediatorName, serviceFdn);
    } else
        this.nfmpMediators.put("NFM-P", serviceFdn);
    this.managedTasks.push(this.constructTaskPayload("POST", this.constructNfmpUrl(alienMediatorName) + this.nfmpUrl, nfmpSitePayload, device, "NFMP", 2, null));
};
