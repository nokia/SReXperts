load({script: resourceProvider.getResource('sf-logger.js'), name: 'ServiceFulfillmentLogger'});

function MediatorFramework(name, sflogger) {
    this.mediatorName = name;
    if (sflogger)
        this.sfLogger = sflogger;
    else
        this.sfLogger = new ServiceFulfillmentLogger();

    if (name === "MDC") {
        this.mediatorIp = "nsp-mdt-mdc-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
        this.contentType = "application/yang-patch+json";
    } else if (name === "NFMP") {
        this.mediatorIp = "nsp-mdt-nfmp-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
    } else if (name === "NSP") {
        this.mediatorIp = "nsp-mdt-nsp-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
    } else {
        try {
            let mediatorManager = mds.getManagerByName(name);
            this.mediatorIp = mediatorManager.getIp();
            this.mediatorPort = mediatorManager.getPort();
            this.mediatorProtocol = mediatorManager.getProtocol();
            this.sfLogger.debug("[MEDIATOR-FWK] Constructor type: {} protocol: {} ip: {} port: {}", this.mediatorName, this.mediatorProtocol, this.mediatorIp, this.mediatorPort);
        } catch (e) {
            throw new RuntimeException (e);
        }
    }
}

MediatorFramework.prototype.mediatorIp = "";
MediatorFramework.prototype.mediatorPort = "";
MediatorFramework.prototype.mediatorProtocol = "";
MediatorFramework.prototype.mediatorName = "";
MediatorFramework.prototype.contentType = "application/json";
MediatorFramework.prototype.acceptType = "application/json";
MediatorFramework.prototype.sfLogger = new ServiceFulfillmentLogger();

/*
   function: configRestClient
    since: NSP 21.11
    short_description: Set Restclient ip address and port
    input:
        url:
          description: URL where payload needs to be sent
          type: String
          mandatory: True
        httpMethod:
          description: POST/PUT/PATCH/DELETE
          type: String
          mandatory: True
*/
MediatorFramework.prototype.configRestClient = function (url, httpMethod) {
    this.sfLogger.debug("[MEDIATOR-FWK] Mediator-type: {} protocol: {} ip: {} port: {} URL :{} mediatorHttpMethod :{}", this.mediatorName, this.mediatorProtocol, this.mediatorIp, this.mediatorPort, url, httpMethod);
    restClient.setIp(this.mediatorIp);
    restClient.setPort(this.mediatorPort);
    restClient.setProtocol(this.mediatorProtocol);
};

/*
   function: fetch
    since: NSP 21.11
    short_description: Performs HTTP GET
    input:
        targetUrl:
          description: URL to be fetched
          type: String
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http GET response (as Object)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed to fetch service from MDC, got response {"ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"bad-element","error-path":"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/a","error-message":"Query failed INTERNAL: Path not part of module : nokia-conf:/configure......"}]}",
            response: {"ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"bad-element","error-path":"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/a","error-message":"Query failed INTERNAL: Path not part of module : nokia-conf:/configure......"}]}
          }
*/
MediatorFramework.prototype.fetch = function (targetUrl) {
    let restStartTime = Date.now();
    let result = {};
    this.configRestClient(targetUrl, "GET");
    let self = this;
    restClient.get(targetUrl, "application/json", function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        self.sfLogger.info("[MEDIATOR-FWK][GET] Took : {} ms httpStatus {} response : {} url : {} MediatorSvcName: {}", Date.now() - restStartTime, httpStatus, response, targetUrl, self.mediatorIp);
        if (exception) {
            self.sfLogger.error("[MEDIATOR-FWK][GET] Exception Found " + exception);
            result.msg = "Couldn't connect to " + this.mediatorName + ", got response " + response + ", exception " + exception;
        } else if (httpStatus != 200 && httpStatus != 201) {
            result.msg = "Failed to fetch service from " + this.mediatorName + ", got response " + response;
            result.response = JSON.parse(response);
        } else {
            result.success = true;
            result.msg = JSON.parse(response);
            result.response = JSON.parse(response);
        }
    });
    return result;
};

/*
   function: post
    since: NSP 21.11
    short_description: Performs HTTP POST
    input:
        targetUrl:
          description: URL for POST
          type: String
          mandatory: True
        payloadObj:
          description: Payload for POST
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http POST response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to NFMP, got response {"generic.GenericObject.configureChildInstanceException":{"description":"[ app: generic:property:mutator ] [ class: epipe.Site ] [ instance: epipe.Site.1.1.1.1 ] [ descr: property mtu cannot be set to value passed in : -2. Value out of range., {mtu=-2} ]"},"objectFullName":""}",
            response: "{\"generic.GenericObject.configureChildInstanceException\":{\"description\":\"[ app: generic:property:mutator ] [ class: epipe.Site ] [ instance: epipe.Site.1.1.1.1 ] [ descr: property mtu cannot be set to value passed in : -2. Value out of range., {mtu=-2} ]\"},\"objectFullName\":\"\"}"
          }
*/
MediatorFramework.prototype.post = function (targetUrl, payloadObj) {
    let restStartTime = Date.now();
    let result = {};
    this.configRestClient(targetUrl, "POST");
    let self = this;
    restClient.post(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        self.sfLogger.info("[MEDIATOR-FWK][POST] MediatorSvcName: {} URL: {}, Payload: {}", self.mediatorIp, targetUrl, JSON.stringify(payloadObj, null, 2));
        self.sfLogger.info("[MEDIATOR-FWK][POST] Took : {} ms httpStatus {} Response {}", Date.now() - restStartTime, httpStatus, response);
        if (exception) {
            self.sfLogger.error("[MEDIATOR-FWK][POST] Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorName + ", got response " + response + ", exception " + exception;
        } else if (httpStatus != 200 && httpStatus != 201) {
            result.msg = "Failed deployment to " + this.mediatorName + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorName + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};

/*
   function: patch
    since: NSP 21.11
    short_description: Performs HTTP PATCH
    input:
        targetUrl:
          description: URL for PATCH
          type: String
          mandatory: True
        payloadObj:
          description: Payload for PATCH
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http PATCH response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to MDC, got response {"ietf-yang-patch:yang-patch-status":{"patch-id":"unknown","ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"invalid-value","error-path":"nokia-conf:/configure/service","error-message":null}]}}}",
            response: "{\"ietf-yang-patch:yang-patch-status\":{\"patch-id\":\"unknown\",\"ietf-restconf:errors\":{\"error\":[{\"error-type\":\"application\",\"error-tag\":\"invalid-value\",\"error-path\":\"nokia-conf:/configure/service\",\"error-message\":null}]}}}"
          }
*/
MediatorFramework.prototype.patch = function (targetUrl, payloadObj) {
    let restStartTime = Date.now();
    if (this.mediatorName === "NSP") {
        targetUrl = "patch/" + targetUrl;
    }
    let result = {};
    this.configRestClient(targetUrl, "PATCH");
    let self = this;
    restClient.patch(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        self.sfLogger.info("[MEDIATOR-FWK][PATCH] MediatorSvcName: {}, URL: {}, Payload: {}", self.mediatorIp, targetUrl, JSON.stringify(payloadObj, null, 2));
        self.sfLogger.info("[MEDIATOR-FWK][PATCH]  Took : {} ms httpStatus {} response : {}", Date.now() - restStartTime, httpStatus, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception) {
            self.sfLogger.error("[MEDIATOR-FWK][PATCH] Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorName + ", got response " + response + ", exception " + exception;
        } else if (httpStatus != 200 && httpStatus != 201) {
            result.msg = "Failed deployment to " + this.mediatorName + "got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorName + " was successful, got response " + response;
            result.response = response
        }
    });
    return result;
};

/*
   function: put
    since: NSP 21.11
    short_description: Performs HTTP PUT
    input:
        targetUrl:
          description: URL for PUT
          type: String
          mandatory: True
        payloadObj:
          description: Payload for PUT
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http PUT response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to MDC, got response {"ietf-yang-patch:yang-patch-status":{"patch-id":"unknown","ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"invalid-value","error-path":"nokia-conf:/configure/service","error-message":null}]}}}",
            response: "{\"ietf-yang-patch:yang-patch-status\":{\"patch-id\":\"unknown\",\"ietf-restconf:errors\":{\"error\":[{\"error-type\":\"application\",\"error-tag\":\"invalid-value\",\"error-path\":\"nokia-conf:/configure/service\",\"error-message\":null}]}}}"
          }
*/
MediatorFramework.prototype.put = function (targetUrl, payloadObj) {
    let restStartTime = Date.now();
    let result = {};
    this.configRestClient(targetUrl, "PUT");
    let self = this;
    restClient.put(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        self.sfLogger.info("[MEDIATOR-FWK][PUT] MediatorSvcName:{}, URL: {}, Payload: {}", self.mediatorIp, targetUrl, JSON.stringify(payloadObj, null, 2));
        self.sfLogger.info("[MEDIATOR-FWK][PUT] Took : {} ms httpStatus {} response :{}", Date.now() - restStartTime, httpStatus, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception) {
            self.sfLogger.error("[MEDIATOR-FWK][PUT] Exception Found {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorName + ", got response " + response + ", exception " + exception;
        } else if (httpStatus != 200 && httpStatus != 201) {
            result.msg = "Failed deployment to " + this.mediatorName + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorName + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};

/*
   function: delete
    since: NSP 21.11
    short_description: Performs HTTP DELETE
    input:
        deleteUrl:
          description: URL for DELETE
          type: String
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http DELETE response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to MDC, got response {"ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"invalid-value","error-path":"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/fasdfasdf","error-message":"java.lang.IllegalArgumentException: Path not part of module : nokia-conf:/configure/fasdfasdf"}]}}",
            response: "{\"ietf-restconf:errors\":{\"error\":[{\"error-type\":\"application\",\"error-tag\":\"invalid-value\",\"error-path\":\"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/fasdfasdf\",\"error-message\":\"java.lang.IllegalArgumentException: Path not part of module : nokia-conf:/configure/fasdfasdf\"}]}}"
          }
*/
MediatorFramework.prototype.delete = function (deleteUrl) {
    let restStartTime = Date.now();
    let result = {};
    this.configRestClient(deleteUrl, "DELETE");
    let self = this;
    restClient.delete(deleteUrl, "application/json", function (exception, httpStatus, response) {
        self.sfLogger.info("[MEDIATOR-FWK][DELETE] MediatorSvcName:{}  deleteUrl: {} DELETE took : {} ms httpStatus {} response : {}", self.mediatorIp, deleteUrl, Date.now() - restStartTime, httpStatus, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception) {
            self.sfLogger.error("[MEDIATOR-FWK][DELETE] Delete Exception Found {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorName + ", got response " + response + ", exception " + exception;
        } else if (httpStatus != 200 && httpStatus != 201 && httpStatus != 204) {
            result.msg = "Failed deployment to " + this.mediatorName + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorName + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};
