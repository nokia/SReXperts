load({script: resourceProvider.getResource('sr-svc-fwk.js'), name: 'sr-svc-fwk'});

function NfmpMapper(sfLogger) {
    if (sfLogger){
        this.sfLogger = sfLogger;
        this.srSvcUtils = new SrSvcFwk(sfLogger);
        this.sfUtils = new ServiceFulfillmentIntentUtils(sfLogger);
    }
}

NfmpMapper.prototype.srSvcUtils = new SrSvcFwk();
NfmpMapper.prototype.sfLogger = new ServiceFulfillmentLogger();
NfmpMapper.prototype.sfUtils = new ServiceFulfillmentIntentUtils();

/*
   function: mapToNfmpSite
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model - Site
    input:
        deviceId:
          type: String
          description: NE system address
          mandatory: True
        siteObjMap:
          type: Object
          description: Intent Site object
          mandatory: True
        svcObjMap:
          type: Object
          description: Intent Service object
          mandatory: True
        preServiceDeployResponse:
          type: Object
          description: Response of pre-deployment
          mandatory: False
    output:
      nfmpSitePayload:
        type: Object
        description: NFMP site level payload
 */
NfmpMapper.prototype.mapToNfmpSite = function (deviceId, siteObjMap, svcObjMap, preServiceDeployResponse, svcTopo, isAudit, requestContext) {
    this.sfLogger.info("NFMP Mapper  mapToNfmpSite siteObjMap" + JSON.stringify(siteObjMap));
    let payload = {
        "epipe.Site": [{
            "displayedName": siteObjMap["site-name"],
            "siteId": deviceId,
            "mtu": siteObjMap["mtu"],
            "description": siteObjMap["description"] ? siteObjMap["description"] : (svcObjMap["description"] ? svcObjMap["description"] : "N/A"),
            "children-Set": {
                "epipe.BgpEvpn": {
                    "bgpEvpnEvi": siteObjMap["evi"]
                },
                "vll.L2AccessInterface": []
            }
        }]
    };


    let bgpEvpn = payload["epipe.Site"][0]["children-Set"]["epipe.BgpEvpn"];
    let isSar = this.sfUtils.is7705Node(deviceId);

    if (siteObjMap["remote-ac"] && siteObjMap["local-ac"]){
        let lDeviceInfo = this.sfUtils.getTypeVersionMediation(deviceId);
        if (lDeviceInfo["version"]){
            let lMajorVersion = lDeviceInfo["version"].split(".")[0];
            if (!isSar && lMajorVersion && parseInt(lMajorVersion) && parseInt(lMajorVersion)>20){
                if (!bgpEvpn["children-Set"])
                    bgpEvpn["children-Set"] = {};
                bgpEvpn["children-Set"]["epipe.LocalAttachmentCircuit"] =  {
                    "ethernetTag" : siteObjMap["local-ac"]["eth-tag"],
                    "attachmentCircuit" : siteObjMap["local-ac"]["name"]
                };
                bgpEvpn["children-Set"]["epipe.RemoteAttachmentCircuit"] =  {
                    "ethernetTag" : siteObjMap["remote-ac"]["eth-tag"],
                    "attachmentCircuit" : siteObjMap["remote-ac"]["name"]
                };
            } else {
                bgpEvpn["localAcEthernetTag"] = siteObjMap["local-ac"]["eth-tag"];
                bgpEvpn["localAcName"] = siteObjMap["local-ac"]["name"];
                bgpEvpn["remoteAcEthernetTag"] = siteObjMap["remote-ac"]["eth-tag"];
                bgpEvpn["remoteAcName"] = siteObjMap["remote-ac"]["name"];
            }
        }
    }

    if (svcObjMap["evpn-type"] === "vxlan") {
        payload["epipe.Site"][0]["children-Set"]["epipe.EpipeVxlanVni"] = {};
        let bgpEvpnVxlan = payload["epipe.Site"][0]["children-Set"]["epipe.EpipeVxlanVni"];
        bgpEvpnVxlan["vni"] = siteObjMap.vxlan["vni"];

        if (siteObjMap.vxlan["bgp-instance"]) {
            payload["epipe.Site"][0]["children-Set"]["epipe.BgpCfg"] = {};
            let bgpCfgDevice = payload["epipe.Site"][0]["children-Set"]["epipe.BgpCfg"];
            bgpCfgDevice["routeDistinguisher"] = siteObjMap.vxlan["bgp-instance"]["route-distinguisher"];
            if (siteObjMap.vxlan["bgp-instance"]["route-target"]) {
                siteObjMap.vxlan["bgp-instance"]["route-target"].forEach(function(intentRt) {
                    if (intentRt["target-type"] === "import-export") {
                        bgpCfgDevice["importRouteTarget"] = "target:" + intentRt["target-value"];
                        bgpCfgDevice["exportRouteTarget"] = "target:" + intentRt["target-value"];
                    } else if (intentRt["target-type"] === "imp") {
                        bgpCfgDevice["importRouteTarget"] = "target:" + intentRt["target-value"];
                    } else if (intentRt["target-type"] === "exp") {
                        bgpCfgDevice["exportRouteTarget"] = "target:" + intentRt["target-value"];
                    }
                })
            }
        }

        if (!bgpEvpn["children-Set"])
            bgpEvpn["children-Set"] = {};
        bgpEvpn["children-Set"]["epipe.BgpEvpnVxlan"] = {};
        let bgpEvpnVxlan1 = bgpEvpn["children-Set"]["epipe.BgpEvpnVxlan"];
        bgpEvpnVxlan1["bgpEvpnVxlanInstanceId"] = 1;
        if (siteObjMap.vxlan["bgp-instance"]["bgp-instance-id"])
            bgpEvpnVxlan1["bgpInstanceId"] = siteObjMap.vxlan["bgp-instance"]["bgp-instance-id"];
        else
            bgpEvpnVxlan1["bgpInstanceId"] = 1;
        bgpEvpnVxlan1["bgpEvpnInstanceType"] = "vxlan";
        bgpEvpnVxlan1["bgpEvpnAdminStatus"] = "up";
        if (siteObjMap["ecmp"])
            bgpEvpnVxlan1["vxlanMaxEcmpRoutes"] = siteObjMap["ecmp"];
    }

    if (svcObjMap["evpn-type"] === "mpls") {
        let bgpEvpnMpls
        let isSar22Dot10R2AndUp=false;
        if(isSar){
            let lDeviceInfo = this.sfUtils.getTypeVersionMediation(deviceId);
            if (lDeviceInfo["version"]){
                let lMajorVersion = lDeviceInfo["version"].split(".")[0];
                let lMinorVersion = lDeviceInfo["version"].split(".")[1];
                let lRVersion = lDeviceInfo["version"].split(".")[2];
                if (lMajorVersion && parseInt(lMajorVersion) ){
                    if(parseInt(lMajorVersion)>22) {
                        isSar22Dot10R2AndUp = true;
                    }else if(parseInt(lMajorVersion)===22 && lMinorVersion && parseInt(lMinorVersion)){
                        if(parseInt(lMinorVersion)>10) {
                          isSar22Dot10R2AndUp = true;
                        }else if(parseInt(lMinorVersion)===10 && lRVersion){
                           if(lRVersion!== "R1")
                               isSar22Dot10R2AndUp = true;
                        }
                    }
                }
            }
        }
        
        if (!bgpEvpn["children-Set"])
            bgpEvpn["children-Set"] = {};
        if (!isSar || isSar22Dot10R2AndUp) {
            bgpEvpn["children-Set"]["epipe.BgpEvpnMpls"] = {
                "bgpEvpnInstanceType": "mpls",
                "bgpEvpnAdminStatus": "up",
                "bgpInstanceId": 1
            };
            bgpEvpnMpls = bgpEvpn["children-Set"]["epipe.BgpEvpnMpls"];

            if (siteObjMap["ecmp"])
                bgpEvpnMpls["mplsMaxEcmpRoutes"] = siteObjMap["ecmp"];

            if (siteObjMap.mpls["force-vc-forwarding"] === "vlan")
                bgpEvpnMpls["mplsForceVlanVcForwarding"] = true;
            else if (siteObjMap.mpls["force-vc-forwarding"] === "qinq-c-tag-c-tag")
                bgpEvpnMpls["mplsForceQinqVcFwding"] = "ctagCtag";
            else if (siteObjMap.mpls["force-vc-forwarding"] === "qinq-s-tag-c-tag")
                bgpEvpnMpls["mplsForceQinqVcFwding"] = "stagCtag";
        }

        if (siteObjMap.mpls["bgp-instance"]) {
            payload["epipe.Site"][0]["children-Set"]["epipe.BgpCfg"] = {
                "routeDistinguisher": siteObjMap.mpls["bgp-instance"]["route-distinguisher"]
            };
            let bgpCfgDevice = payload["epipe.Site"][0]["children-Set"]["epipe.BgpCfg"];
            if (siteObjMap.mpls["bgp-instance"]["route-target"]) {
                siteObjMap.mpls["bgp-instance"]["route-target"].forEach(function(intentRt) {
                    if (intentRt["target-type"] === "import-export") {
                        bgpCfgDevice["importRouteTarget"] = "target:" + intentRt["target-value"];
                        bgpCfgDevice["exportRouteTarget"] = "target:" + intentRt["target-value"];
                    } else if (intentRt["target-type"] === "imp") {
                        bgpCfgDevice["importRouteTarget"] = "target:" + intentRt["target-value"];
                    } else if (intentRt["target-type"] === "exp") {
                        bgpCfgDevice["exportRouteTarget"] = "target:" + intentRt["target-value"];
                    }
                })
            }
            if (!isSar) {
                bgpCfgDevice["children-Set"] = {
                    "epipe.BgpVsiImportPolicy": {},
                    "epipe.BgpVsiExportPolicy": {}
                }
                this.srSvcUtils.IntentToNFMPMapperBgpVsiPlcy(bgpCfgDevice["children-Set"]["epipe.BgpVsiImportPolicy"],
                    siteObjMap.mpls["bgp-instance"]["vsi-import"]);

                this.srSvcUtils.IntentToNFMPMapperBgpVsiPlcy(bgpCfgDevice["children-Set"]["epipe.BgpVsiExportPolicy"],
                    siteObjMap.mpls["bgp-instance"]["vsi-export"]);
            }
        }

        if ((!isSar|| isSar22Dot10R2AndUp)&& siteObjMap.mpls && siteObjMap.mpls["auto-bind-tunnel"]) {
            if (siteObjMap.mpls["auto-bind-tunnel"]["resolution"] === "none")
                bgpEvpnMpls["autoBindTunnelStatus"] = "disabled";
            else
                bgpEvpnMpls["autoBindTunnelStatus"] = siteObjMap.mpls["auto-bind-tunnel"]["resolution"]

            siteObjMap.mpls["auto-bind-tunnel"]["resolution-filter"]["bgp"] ? bgpEvpnMpls["autoBindTunnelBgp"] = true : bgpEvpnMpls["autoBindTunnelBgp"] = false;
            siteObjMap.mpls["auto-bind-tunnel"]["resolution-filter"]["ldp"] ? bgpEvpnMpls["autoBindTunnelLdp"] = true : bgpEvpnMpls["autoBindTunnelLdp"] = false;
            siteObjMap.mpls["auto-bind-tunnel"]["resolution-filter"]["rsvp"] ? bgpEvpnMpls["autoBindTunnelRsvpTe"] = true : bgpEvpnMpls["autoBindTunnelRsvpTe"] = false;
            siteObjMap.mpls["auto-bind-tunnel"]["resolution-filter"]["sr-isis"] ? bgpEvpnMpls["autoBindTunnelSrIsis"] = true : bgpEvpnMpls["autoBindTunnelSrIsis"] = false;
            siteObjMap.mpls["auto-bind-tunnel"]["resolution-filter"]["sr-ospf"] ? bgpEvpnMpls["autoBindTunnelSrOspf"] = true : bgpEvpnMpls["autoBindTunnelSrOspf"] = false;
            siteObjMap.mpls["auto-bind-tunnel"]["resolution-filter"]["sr-te"] ? bgpEvpnMpls["autoBindTunnelSrTe"] = true : bgpEvpnMpls["autoBindTunnelSrTe"] = false;

            siteObjMap.mpls["auto-bind-tunnel"]["enforce-strict-tunnel-tagging"] ? bgpEvpnMpls["autoBindStrictTunnelTag"] = true : bgpEvpnMpls["autoBindStrictTunnelTag"] = false;
        }
    }

    if (siteObjMap["sap-details"] && siteObjMap["sap-details"]["sap"]) {
        for (let  j = 0; j < siteObjMap["sap-details"]["sap"].length; j++) {
            let epPayload = this.srSvcUtils.sapToNFMPMapper(svcObjMap, siteObjMap["sap-details"]["sap"][j], deviceId, "epipe", siteObjMap["@"]["typeAndVersionMap"]["alienMediatorName"], requestContext);
            payload["epipe.Site"][0]["children-Set"]["vll.L2AccessInterface"].push(epPayload)
        }
    }

    return payload;
};

/*
   function: mapToNfmpSvc
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model - Service
    input:
        svcObjMap:
          type: Object
          description: Intent Service object
          mandatory: True
        siteObjArr:
          type: Object
          description: NFMP site level payload
          mandatory: True
        preServiceDeployResponse:
          type: Object
          description: Response of pre-deployment
          mandatory: False
    output:
      nfmpServicePayload:
        type: Object
        description: NFMP Service level payload
 */
NfmpMapper.prototype.mapToNfmpSvc = function (svcObj, siteObjArr) {
    this.sfLogger.info("NFMP Mapper  mapToNfmpSvc svcObj" + JSON.stringify(svcObj));
    return {
        "distinguishedName": "svc-mgr",
        "childConfigInfo": {
            "epipe.Epipe": this.srSvcUtils.svcToNFMPMapper(svcObj, siteObjArr)
        }
    };
};

/*
   function: populateSources
    since: NSP 21.6
    short_description: Populate device specific sources (nsp-model:sources) for resync app
    description:
        - prior deployment set NFMP device source to nsp site object
    input:
        svcObj:
          type: Object
          description: Intent Service object
          mandatory: True
        siteObj:
          type: Object
          description: Intent Site object
          mandatory: True
        preServiceDeployResponse:
          type: Object
          description: Response of pre-deployment
          mandatory: False
*/
NfmpMapper.prototype.populateSources = function (svcObj, siteObj, device, preServiceDeployResponse) {
    this.sfLogger.info("NFMP Mapper  populateSources svcObj" + JSON.stringify(svcObj));
    this.sfLogger.info("NFMP Mapper  populateSources siteObj" + JSON.stringify(siteObj));


    let fdnPrefix = "fdn:realm:sam:";
    if (!svcObj["serviceMgrId"])
        throw new RuntimeException("Property serviceMgrId not found!");

    if (!svcObj["@"]) svcObj["@"] = {};
    if (!svcObj["@"]["nsp-model:sources"]) svcObj["@"]["nsp-model:sources"] = [];
    if (typeof svcObj["serviceMgrId"] === "object" && svcObj["serviceMgrId"]["NFMP"]){
        svcObj["@"]["nsp-model:sources"].push(fdnPrefix + svcObj["serviceMgrId"]["NFMP"]);
    } else {
        svcObj["@"]["nsp-model:sources"].push(fdnPrefix + svcObj["serviceMgrId"]);
    }


    if (!siteObj["@"]) siteObj["@"] = {};
    if (siteObj["@"] && siteObj["@"]["typeAndVersionMap"] && siteObj["@"]["typeAndVersionMap"]["mediation"] === "nfmp" ) {
        siteObj["@"]["svcSource"] = [];
        if (typeof svcObj["serviceMgrId"] === "object" && svcObj["serviceMgrId"][device]){
            siteObj["@"]["svcSource"].push(fdnPrefix + svcObj["serviceMgrId"][device]);
        } else {
            siteObj["@"]["svcSource"].push(fdnPrefix + svcObj["serviceMgrId"] + ":" + device.replaceAll(":","_"));
        }
    }
};

/*
   function: mapToIntentModelService
    since: NSP 23.4
    short_description: Reverse mapping - Service model to intent model
    input:
        operModel:
          type: Object
          description: Operational model entry
          mandatory: True
    output:
      intentModel:
        type: Object
        description: intent model after translation
 */
NfmpMapper.prototype.mapToIntentModelService = function (operModel) {
    let intentModel = {
        "service" : {}
    };
    let lServiceObj = this.sfUtils.findNFMPByObjectFullName("epipe.Epipe", "svc-mgr:service-" + operModel["id"], []);
    if (lServiceObj) {
        this.srSvcUtils.NFMPtoSvcMapper(intentModel["service"], lServiceObj["epipe.Epipe"], "epipe.Epipe", operModel);
    }
    return intentModel;
}

function returnNfmpClasses() {
    return [
        {
            "class": "vll.L2AccessInterface",
            "children": [
                {"resultFilter": {"class": "service.IngressSchedulerPolicyEntryOverride", "children": {}}},
                {"resultFilter": {"class": "service.EgressSchedulerPolicyEntryOverride", "children": {}}},
                {"resultFilter": {"class": "service.EgressAccessPolicyQueueOverride", "children": {}}},
                {"resultFilter": {"class": "service.IngressAccessPolicyQueueOverride", "children": {}}},
                {"resultFilter": {"class": "service.SapIngressPolicerOverride", "children": {}}},
                {"resultFilter": {"class": "service.SapEgressPolicerOverride", "children": {}}},
                {"resultFilter": {"class": "service.SapIngPolicerCtlOverride", "children": [
                            {"resultFilter": {"class": "service.SapIngressPolicerLevelOverride", "children": {}}}
                        ]}},
                {"resultFilter": {"class": "service.SapEgrPolicerCtlOverride", "children": [
                            {"resultFilter": {"class": "service.SapEgressPolicerLevelOverride", "children": {}}}
                        ]}}
            ]
        },
        {
            "class": "epipe.BgpEvpn",
            "children": [{"resultFilter": {"class": "epipe.BgpEvpnMpls", "children": {}}},
                {"resultFilter": {"class": "epipe.BgpEvpnVxlan", "children": {}}}
            ]
        },
        {"class": "epipe.EpipeVxlanVni", "children": {}},
        {"class": "epipe.BgpCfg",
            "children": [{"resultFilter": {"class": "epipe.BgpVsiImportPolicy", "children": {}}},
                {"resultFilter": {"class": "epipe.BgpVsiExportPolicy", "children": {}}}
            ]
        }
    ];
}

/*
   function: mapToIntentModelSite
    since: NSP 21.6
    short_description: Reverse mapping - Map device model to intent model
    input:
        operModel:
          type: Object
          description: Operational model entry
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
    output:
      intentModel:
        type: Object
        description: intent model after translation
*/
NfmpMapper.prototype.mapToIntentModelSite = function (operModel, siteId) {
    this.sfLogger.info("NFMP mapToIntentModelSite operModel" + JSON.stringify(operModel));
    let intentModel = {};
    intentModel["service"] = {};
    intentModel["site"] = {};
    intentModel["sdp"] = [];

    //site
    let typeAndVersionMap = this.sfUtils.getTypeVersionMediation(siteId);
    let lSiteObj = this.sfUtils.findNFMPByObjectFullName("epipe.Site", operModel["nfmpSiteFdn"], returnNfmpClasses(), typeAndVersionMap["alienMediatorName"]);
    if (lSiteObj) {
        lSiteObj = lSiteObj["epipe.Site"];

        intentModel["site"]["mtu"] = lSiteObj["mtu"];
        if (lSiteObj["description"] && lSiteObj["description"] !== "N/A")
            intentModel["site"]["description"] = lSiteObj["description"];
        intentModel["site"]["site-name"] = this.sfUtils.convertToString(lSiteObj["displayedName"]);
        intentModel["site"]["device-id"] = siteId;

        if (lSiteObj["children-Set"]) {
            for (let  childClass in lSiteObj["children-Set"]) {
                let childClassVal = lSiteObj["children-Set"][childClass];
                if (childClass === "vll.L2AccessInterface") {
                    if (!intentModel["site"]["sap-details"])
                        intentModel["site"]["sap-details"] = {};
                    if (!intentModel["site"]["sap-details"]["sap"])
                        intentModel["site"]["sap-details"]["sap"] = [];
                    if (Array.isArray(childClassVal)) {
                        for (let  j = 0; j < childClassVal.length; j++) {
                            let lSap = this.srSvcUtils.NFMPtoSapMapper(childClassVal[j], siteId);

                            intentModel["site"]["sap-details"]["sap"].push(lSap);
                        }
                    } else {
                        let lSap = this.srSvcUtils.NFMPtoSapMapper(childClassVal, siteId);
                        intentModel["site"]["sap-details"]["sap"].push(lSap);
                    }
                } else if (childClass === "epipe.BgpEvpn") {
                    if (childClassVal["bgpEvpnEvi"] != 0)
                        intentModel["site"]["evi"] = childClassVal["bgpEvpnEvi"];
                    intentModel["site"]["local-ac"] = {
                        "eth-tag" : childClassVal["localAcEthernetTag"],
                        "name": childClassVal["localAcName"]
                    };
                    intentModel["site"]["remote-ac"] = {
                        "eth-tag" : childClassVal["remoteAcEthernetTag"],
                        "name": childClassVal["remoteAcName"]
                    };
                    if (childClassVal["children-Set"]){
                        if (childClassVal["children-Set"]["epipe.BgpEvpnVxlan"]){
                            intentModel["service"]["evpn-type"] = "vxlan";
                            if (!intentModel["site"]["vxlan"])
                                intentModel["site"]["vxlan"] = {};
                            if (childClassVal["children-Set"]["epipe.BgpEvpnVxlan"]["bgpEvpnVxlanInstanceId"]){
                                if (!intentModel["site"]["vxlan"]["bgp-instance"])
                                    intentModel["site"]["vxlan"]["bgp-instance"] = {}
                                intentModel["site"]["vxlan"]["bgp-instance"]["bgp-instance-id"] =
                                    childClassVal["children-Set"]["epipe.BgpEvpnVxlan"]["bgpEvpnVxlanInstanceId"];
                            }
                            if (childClassVal["children-Set"]["epipe.BgpEvpnVxlan"]["vxlanMaxEcmpRoutes"] !== ""){
                                intentModel["site"]["ecmp"] = childClassVal["children-Set"]["epipe.BgpEvpnVxlan"]["vxlanMaxEcmpRoutes"]
                            }
                        } else  if (childClassVal["children-Set"]["epipe.BgpEvpnMpls"]) {
                            intentModel["service"]["evpn-type"] = "mpls";
                            if (!intentModel["site"]["mpls"])
                                intentModel["site"]["mpls"] = {};
                            if (childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["mplsMaxEcmpRoutes"] !== ""){
                                intentModel["site"]["ecmp"] = childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["mplsMaxEcmpRoutes"]
                            }
                            if (childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["mplsForceVlanVcForwarding"] == "true"){
                                intentModel["site"]["mpls"]["force-vc-forwarding"] = "vlan";
                            } else if (childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["mplsForceQinqVcFwding"] === "ctagCtag"){
                                intentModel["site"]["mpls"]["force-vc-forwarding"] = "qinq-c-tag-c-tag";
                            } else if (childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["mplsForceQinqVcFwding"] === "stagCtag") {
                                intentModel["site"]["mpls"]["force-vc-forwarding"] = "qinq-s-tag-c-tag";
                            }

                            //autobind
                            intentModel["site"]["mpls"]["auto-bind-tunnel"] = {
                                "resolution": childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelStatus"],
                                "enforce-strict-tunnel-tagging": childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindStrictTunnelTag"]
                            };

                            if (childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelStatus"] === "disabled")
                                intentModel["site"]["mpls"]["auto-bind-tunnel"]["resolution"] = "none";

                            intentModel["site"]["mpls"]["auto-bind-tunnel"]["resolution-filter"] = {
                                "bgp" : childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelBgp"],
                                "ldp" : childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelLdp"],
                                "rsvp" : childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelRsvpTe"],
                                "sr-isis" : childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelSrIsis"],
                                "sr-ospf" : childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelSrOspf"],
                                "sr-te" : childClassVal["children-Set"]["epipe.BgpEvpnMpls"]["autoBindTunnelSrTe"]
                            };
                        }
                    }
                } else if (childClass === "epipe.EpipeVxlanVni") {
                    if (!intentModel["site"]["vxlan"])
                        intentModel["site"]["vxlan"] = {};
                    intentModel["site"]["vxlan"]["vni"] = childClassVal["vni"]
                } else if (childClass === "epipe.BgpCfg") {
                    //Eline evpn it can be either mpls or vxlan .. not both
                    let lEvpnType = "mpls";
                    if (lSiteObj["children-Set"]["epipe.EpipeVxlanVni"]){ //vxlan
                        lEvpnType = "vxlan"
                    }
                    if (!intentModel["site"][lEvpnType])
                        intentModel["site"][lEvpnType] = {};
                    intentModel["site"][lEvpnType]["bgp-instance"] = {
                        "route-distinguisher" : childClassVal["routeDistinguisher"],
                        "route-target":[],
                        "vsi-import": [],
                        "vsi-export": []
                    };
                    if (childClassVal["importRouteTarget"] !== "" && childClassVal["exportRouteTarget"] !== ""){
                        if (childClassVal["importRouteTarget"] === childClassVal["exportRouteTarget"]){
                            intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                                "target-type" : "import-export",
                                "target-value": childClassVal["importRouteTarget"].replace("target:", "")
                            })
                        } else {
                            intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                                "target-type" : "imp",
                                "target-value": childClassVal["importRouteTarget"].replace("target:", "")
                            },{
                                "target-type" : "exp",
                                "target-value": childClassVal["exportRouteTarget"].replace("target:", "")
                            })
                        }
                    } else if (childClassVal["importRouteTarget"] !== ""){
                        intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                            "target-type" : "imp",
                            "target-value": childClassVal["importRouteTarget"].replace("target:", "")
                        })
                    } else if (childClassVal["exportRouteTarget"] !== ""){
                        intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                            "target-type" : "exp",
                            "target-value": childClassVal["exportRouteTarget"].replace("target:", "")
                        })
                    }
                    if (childClassVal["children-Set"] && ("epipe.BgpVsiImportPolicy" in childClassVal["children-Set"])) {
                        this.srSvcUtils.NFMPToIntentMapperBgpVsiPlcy(intentModel["site"][lEvpnType]["bgp-instance"]["vsi-import"],
                            childClassVal["children-Set"]["epipe.BgpVsiImportPolicy"]);
                    }
                    if (childClassVal["children-Set"] && ("epipe.BgpVsiExportPolicy" in childClassVal["children-Set"])){
                        this.srSvcUtils.NFMPToIntentMapperBgpVsiPlcy(intentModel["site"][lEvpnType]["bgp-instance"]["vsi-export"],
                            childClassVal["children-Set"]["epipe.BgpVsiExportPolicy"]);
                    }
                }
            }
        }
    }
    return intentModel;
};
