load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk'});
load({script: resourceProvider.getResource('rest-auth-fwk.js'), name: 'rest-auth-fwk'});
load({script: resourceProvider.getResource('sf-utils.js'), name: 'util-fwk'});

function NspRestconfFwk(sflogger) {
    if (sflogger) {
        this.sfLogger = sflogger;
        this.mediatorFwk = new MediatorFramework("NSP", sflogger);
        this.sfUtils = new ServiceFulfillmentIntentUtils(sflogger);
    }
}

NspRestconfFwk.prototype.sfLogger = new ServiceFulfillmentLogger();
NspRestconfFwk.prototype.RESTCONF_HOST = "restconf-gateway";
NspRestconfFwk.prototype.RESTCONF_PORT = "443";
NspRestconfFwk.prototype.mediatorFwk = new MediatorFramework("NSP");
NspRestconfFwk.prototype.restAuthFwk = new RestAuthFwk();
NspRestconfFwk.prototype.sfUtils = new ServiceFulfillmentIntentUtils();
NspRestconfFwk.prototype.operServiceType = null;

NspRestconfFwk.prototype.SVC_CREATION_URL = "/restconf/data/nsp-service:services/service-layer?ignoreReadOnly=true";
NspRestconfFwk.prototype.SVC_UPDATE_URL = "/restconf/data/nsp-service:services/service-layer/{serviceType}={serviceId}?ignoreReadOnly=true";
NspRestconfFwk.prototype.SVC_DELETE_URL = "/restconf/data/nsp-service:services/service-layer/{serviceType}={serviceId}?ignoreReadOnly=true";
NspRestconfFwk.prototype.SVC_GET_URL = "/restconf/data/nsp-service:services/service-layer/{serviceType}={serviceId}";
NspRestconfFwk.prototype.SVC_FIND_URL = "/nsp-service:services/service-layer/{serviceType}[service-id='{serviceId}']";
NspRestconfFwk.prototype.TUNNEL_CREATION_URL = "/restconf/data/nsp-service:services/tunnel-layer?ignoreReadOnly=true";
NspRestconfFwk.prototype.TUNNEL_EXTCREATION_URL = "/restconf/data/nsp-service:services/tunnel-layer/{serviceType}={serviceId},{sourceNeId}/service-extension:{serviceType}-ext?ignoreReadOnly=true";
NspRestconfFwk.prototype.TUNNEL_EXTUPDATE_URL = "/restconf/data/nsp-service:services/tunnel-layer/{serviceType}={serviceId},{sourceNeId}/service-extension:{serviceType}-ext?ignoreReadOnly=true";
NspRestconfFwk.prototype.TUNNEL_UPDATE_URL = "/restconf/data/nsp-service:services/tunnel-layer/{serviceType}={serviceId},{sourceNeId}?ignoreReadOnly=true";
NspRestconfFwk.prototype.TUNNEL_GET_URL = "/restconf/data/nsp-service:services/tunnel-layer/{serviceType}={serviceId},{sourceNeId}";
NspRestconfFwk.prototype.TUNNEL_FIND_URL = "/nsp-service:services/tunnel-layer/mpls-tunnel[id='{serviceId}'][source-ne-id='{sourceNeId}']|/nsp-service:services/tunnel-layer/gre-tunnel[id='{serviceId}'][source-ne-id='{sourceNeId}']";
NspRestconfFwk.prototype.TUNNEL_DELETE_URL = "/restconf/data/nsp-service:services/tunnel-layer/{serviceType}={serviceId},{sourceNeId}?ignoreReadOnly=true";
NspRestconfFwk.prototype.TUNNEL_IDNEID_XPATH = "/nsp-service:services/tunnel-layer/mpls-tunnel[id='{id}'][source-ne-id='{neId}']|/nsp-service:services/tunnel-layer/gre-tunnel[id='{id}'][source-ne-id='{neId}']";
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_BY_SOURCE_URL = "/restconf/operations/nsp-inventory:find-by-source";
NspRestconfFwk.prototype.NE_FILTER = "/nsp-equipment:network/network-element";
NspRestconfFwk.prototype.CUSTOMER_GET_ALL = "/nsp-customer:customers/customer";
NspRestconfFwk.prototype.MPLSGRE_TUNNEL_XPATH_FILTER = "/nsp-service:services/tunnel-layer/mpls-tunnel[name='{tunnelName}']|/nsp-service:services/tunnel-layer/gre-tunnel[name='{tunnelName}']";
NspRestconfFwk.prototype.MPLS_TUNNEL_SOURCEDESTINATION_XPATH_FILTER = "/nsp-service:services/tunnel-layer/mpls-tunnel[source-ne-id='{source}'][destination-ne-id='{destination}']";
NspRestconfFwk.prototype.GRE_TUNNEL_SOURCEDESTINATION_XPATH_FILTER = "/nsp-service:services/tunnel-layer/gre-tunnel[source-ne-id='{source}'][destination-ne-id='{destination}']";
NspRestconfFwk.prototype.FIND_PORT_BY_NAME_XPATH_FILTER = "/nsp-equipment:network/network-element[ne-id='{neId}']/hardware-component/port[name='{portName}']";
NspRestconfFwk.prototype.FIND_LAG_BY_NAME_XPATH_FILTER = "/nsp-equipment:network/network-element[ne-id='{neId}']/lag[name='{portName}']";
NspRestconfFwk.prototype.ServiceSteeringParam = "/restconf/data/steering-parameters:parameters";
NspRestconfFwk.prototype.MdcAdminGroup = "/restconf/data/network-device-mgr:network-devices/network-device={deviceId}/root/nokia-conf:/configure/service/sdp-group/group-name?depth=1";
NspRestconfFwk.prototype.MdcLsps = "/restconf/data/network-device-mgr:network-devices/network-device={deviceId}/root/nokia-conf:/configure/router=Base/mpls/lsp?depth=1";
NspRestconfFwk.prototype.MdcAccountingPolicies = "/restconf/data/network-device-mgr:network-devices/network-device={deviceId}/root/nokia-conf:/configure/log/accounting-policy";
NspRestconfFwk.prototype.MdcTunnelInterfaces = "/restconf/data/network-device-mgr:network-devices/network-device={deviceId}/root/srl_nokia-tunnel-interfaces:/tunnel-interface?depth=1";
NspRestconfFwk.prototype.MdcIRBInterfaces = "/restconf/data/network-device-mgr:network-devices/network-device={deviceId}/root/srl_nokia-interfaces:/interface?depth=1&fields=name";
NspRestconfFwk.prototype.MdcConnectionProfiles = "/restconf/data/network-device-mgr:network-devices/network-device={deviceId}/root/nokia-conf:/configure/connection-profile/vlan";

/*
   function: constructURL
    since: NSP 21.11
    short_description: Constructs restconf URL
    input:
      path:
        description: restconf path
        type: String
        mandatory: True
      method:
        description: POST/PUT/PATCH/GET
        type: String
        mandatory: True
   output:
      url:
        type: String
        description: Restconf URL
    example_responses:
      Success: |
        url: "http://restconf-gateway:443/nsp-equipment:network/network-element"
*/
NspRestconfFwk.prototype.constructURL = function (path, method) {
    let url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    this.sfLogger.debug("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};

/*
   function: getServiceUrlUpdateSvcType
    since: NSP 21.11
    short_description: Figures out whats the path based on serviceType (service/Tunnel)
    input:
      operation:
        description: CREATION/UPDATE/EXTUPDATE/FIND/DELETE/GET
        type: String
        mandatory: True
      serviceType:
        description: Eline/Elan/L3vpn/Tunnel
        type: String
        mandatory: True
      id:
        description: target
        type: String
        mandatory: True
      serviceObj:
        description: Service Object
        type: Object
        mandatory: False
    output:
      url:
        type: String
        description: Restconf URL path
*/
NspRestconfFwk.prototype.getServiceUrlUpdateSvcType = function (operation, serviceType, id, serviceObj) {
    this.sfLogger.debug("[RestconfFwk][getServiceUrlUpdateSvcType] serviceObj = {}", JSON.stringify(serviceObj));
    let prefix = 'SVC';
    if (serviceType === 'mpls-tunnel' || serviceType === 'gre-tunnel' || serviceType === 'tunnel') {
        prefix = 'TUNNEL';
    }
    let templatedUrl = prefix + '_' + operation + '_URL';
    if (!(templatedUrl in NspRestconfFwk.prototype)) {
        throw new RuntimeException('[RestconfFwk] templated url not found for: ' + templatedUrl);
    }
    let url = NspRestconfFwk.prototype[templatedUrl];
    if (serviceType === 'tunnel' && serviceObj) {
        this.operServiceType = (serviceObj['transport-type'] && serviceObj['transport-type'] === 'gre') ? "gre-tunnel" : "mpls-tunnel";
    } else {
        this.operServiceType = serviceType;
    }
    if (serviceType === 'mpls-tunnel' || serviceType === 'gre-tunnel' || serviceType === 'tunnel') {
        if (!serviceObj) {
            id = id.replace('%23', '#'); //Sometimes id is encoded
            serviceObj = {'source-ne-id': id.split('#')[0], 'id': id.split('#')[1]}
        }
        url = url.replace(/{sourceNeId}/g, serviceObj['source-ne-id']);
        id = serviceObj['id'];
        delete serviceObj['transport-type']; //Chris not sure why we do this
    } else {
        this.operServiceType = serviceType;
    }
    if (this.operServiceType) {
        url = url.replace(/{serviceType}/g, this.operServiceType)
    }
    if (id) {
        url = url.replace(/{serviceId}/g, id);
    }
    this.sfLogger.info('URL: ' + url);
    return url;
};

/*
   function: getByXpath
    since: NSP 21.11
    short_description: Read Restconf URL using GET - turns all depth
    input:
      xPath:
        description: Restconf path
        type: String
        mandatory: True
      alienMediator:
        description: HCO - Alien mediator name
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Restconf payload
*/
NspRestconfFwk.prototype.getByXpath = function (xPath, alienMediator) {
    let url = this.constructURL("/restconf/data" + xPath, "GET");
    let response;
    if(alienMediator) {
        response = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger).fetch(url);
    } else
        response = this.mediatorFwk.fetch(url);
    this.sfLogger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200) {
        return response["response"];
    } else {
        return null;
    }
};

/*
   function: findByXpath
    since: NSP 21.11
    short_description: Read Restconf URL using Inventory Find
    input:
      xPath:
        description: Restconf path
        type: String
        mandatory: True
      depth:
        description: depth of the return Query
        type: Integer
        mandatory: False
     fields:
        description: Fields to return
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Restconf payload
*/
NspRestconfFwk.prototype.findByXpath = function (xPath, depth, fields, includeMeta) {
    if (!depth) {
        depth = 3;
    }
    if (includeMeta === undefined) includeMeta = true;
    let url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    let input = {};
    let ret = null;
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    if (includeMeta === false)
        input["include-meta"] = false;
    let requestBody = {};
    requestBody["input"] = input;

    let response = this.mediatorFwk.post(url, requestBody);
    this.sfLogger.debug("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        let lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"]) {
            let data = JSON.parse(response["response"])["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};

/*
   function: findByXpathPaginated
    since: NSP 21.11
    short_description: Read Restconf URL using Inventory Find
    input:
      xPath:
        description: Restconf path
        type: String
        mandatory: True
      depth:
        description: depth of the return Query
        type: Integer
        mandatory: False
      fields:
        description: Fields to return
        type: String
        mandatory: False
      offset:
        description: start index
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Restconf payload
*/
NspRestconfFwk.prototype.findByXpathPaginated = function (xPath, depth, fields, offset, includeMeta,token) {
    if (!depth) depth = 3;
    if (!offset) offset = 0;
    if (includeMeta === undefined) includeMeta = true;
    let limit = 300;
    let input = {};
    let ret = [];
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    if(includeMeta === false)
        input["include-meta"] = false;
    input["offset"] = offset;
    input["limit"] = limit;
    let requestBody = {};
    requestBody["input"] = input;
    let response;
    if (token) {
        let url = this.NSP_RESTCONF_INVENTORY_FIND_URL;
        response = this.restAuthFwk.post(url, requestBody, token);
    } else {
        let url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
        response = this.mediatorFwk.post(url, requestBody);
    }
    this.sfLogger.debug("[RestconfFwk][findByXpathPaginated] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        let lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"]) {
            let data = lRes["nsp-inventory:output"]["data"];
            if (data.length !== 0){
                ret = ret.concat(data);
            }
            if ((lRes["nsp-inventory:output"]["end-index"]+1) !== lRes["nsp-inventory:output"]["total-count"]){
                if (token) {
                    ret = ret.concat(this.findByXpathPaginated(xPath, depth, fields, lRes["nsp-inventory:output"]["end-index"]+1, includeMeta,token));
                } else {
                    ret = ret.concat(this.findByXpathPaginated(xPath, depth, fields, lRes["nsp-inventory:output"]["end-index"]+1, includeMeta));
                }
            }
        }
    }
    return ret;
};


/*
   function: findBySourcePaginated
    since: NSP 21.11
    short_description: Read Restconf URL using Inventory Find by source
    input:
      schemaNodeId:
        description: Restconf path
        type: String
        mandatory: True
      sources:
        description: source filter
        type: String
        mandatory: True
      depth:
        description: depth of the return Query
        type: Integer
        mandatory: False
      fields:
        description: Fields to return
        type: String
        mandatory: False

    output:
      response:
        type: Object
        description: Restconf payload
*/
NspRestconfFwk.prototype.findBySourcePaginated = function (schemaNodeId,sources, depth, fields) {
    if (!depth) depth = 3;
    let url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_BY_SOURCE_URL, "POST");
    let input = {};
    let ret = [];
    input["schema-nodeid"] = schemaNodeId;
    input["depth"] = depth;
    input["sources"] = sources;

    if (fields !== undefined)
        input["fields"] = fields;
    let requestBody = {};
    requestBody["input"] = input;

    let response = this.mediatorFwk.post(url, requestBody);
    this.sfLogger.debug("[RestconfFwk][findBySourcePaginated] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        let lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"]) {
            let data = lRes["nsp-inventory:output"]["data"];
            if (data.length !== 0){
                ret = ret.concat(data);
            }
        }
    }
    return ret;
};

/*
   function: createService
    since: NSP 21.11
    short_description: Create Operational service Model
    input:
      serviceObj:
        description: Service payload
        type: String
        mandatory: True
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: Integer
        mandatory: False
    output:
      response:
        type: Object
        description: Response Object
*/
NspRestconfFwk.prototype.createService = function (serviceObj, serviceType) {
    this.sfLogger.info("serviceType = {}, serviceObj = {}", serviceType, JSON.stringify(serviceObj));

    let preurl = this.getServiceUrlUpdateSvcType('CREATION', serviceType, null, serviceObj);
    let url = this.constructURL(preurl, "POST");
    let requestBody = {};
    requestBody[this.operServiceType] = [serviceObj];
    let response = this.mediatorFwk.post(url, requestBody);
    if (response.httpStatus !== 201) {
        this.sfLogger.error("[RestconfFwk][createService] Failed to create service : {}", JSON.stringify(response));
    } else {
        this.sfLogger.debug("[RestconfFwk][createService] Successfully created service : {}", JSON.stringify(requestBody));
    }
    return response;
};

/*
   function: updateService
    since: NSP 21.11
    short_description: Update Operational service Model
    input:
      serviceObj:
        description: Service payload
        type: String
        mandatory: True
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: Integer
        mandatory: False
      alienMediator:
        description: HCO - Alien mediator name
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Response Object
*/
NspRestconfFwk.prototype.updateService = function (serviceObj, serviceType, alienMediator) {
    this.sfLogger.info("[RestconfFwk][updateService][PUT] serviceType : {}  serviceObj: {} ", serviceType, JSON.stringify(serviceObj));
    let lServiceId = encodeURIComponent(serviceObj["service-id"]);
    if (alienMediator) {
        this.mediatorFwk = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger);
        lServiceId = encodeURIComponent(lServiceId);
    }
    let preurl = this.getServiceUrlUpdateSvcType('UPDATE', serviceType, lServiceId, serviceObj);
    let url = this.constructURL(preurl, "PUT");

    let requestBody = {};
    requestBody[this.operServiceType] = [serviceObj];

    let response = this.mediatorFwk.put(url, requestBody);
    if (response.httpStatus !== 200 && response.httpStatus !== 204) {
        this.sfLogger.error("[RestconfFwk][updateService] Failed to update service : {}", JSON.stringify(response));
    } else {
        this.sfLogger.debug("[RestconfFwk][updateService] Successfully updated service : {}", JSON.stringify(requestBody));
    }
    return response;
};

/*
   function: patchService
    since: NSP 21.11
    short_description: Patch Operational service Model
    input:
      serviceObj:
        description: Service payload
        type: String
        mandatory: True
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: Integer
        mandatory: False
      alienMediator:
        description: HCO - Alien mediator name
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Response Object
*/
NspRestconfFwk.prototype.patchService = function (serviceObj, serviceType, alienMediator) {
    let lServiceId = encodeURIComponent(serviceObj["service-id"]);
    if (alienMediator) {
        this.mediatorFwk = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger);
        lServiceId = encodeURIComponent(lServiceId);
    }
    this.sfLogger.info("[RestconfFwk][updateService][PATCH] serviceType : {}  serviceObj: {} ", serviceType, JSON.stringify(serviceObj));
    let preurl = this.getServiceUrlUpdateSvcType('UPDATE', serviceType, lServiceId, serviceObj);
    let url = this.constructURL(preurl, "PATCH");
    let requestBody = {};
    requestBody[this.operServiceType] = [serviceObj];

    let response = this.mediatorFwk.patch(url, requestBody);
    if (response.httpStatus !== 200 && response.httpStatus !== 204) {
        this.sfLogger.error("[RestconfFwk][patchService] Failed to update service : {}", JSON.stringify(response));
    } else {
        this.sfLogger.debug("[RestconfFwk][patchService] Successfully updated service : {}", JSON.stringify(requestBody));
    }
    return response;
};

/*
   function: getNe
    since: NSP 21.11
    short_description: Returns NE object from NSP model
    input:
      neIdFilter:
        description: NE System Ip address
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: NE Response Object
*/
NspRestconfFwk.prototype.getNe = function (neIdFilter,token) {
    let xPath = null;
    if (neIdFilter) {
        xPath = this.NE_FILTER + "[contains('ne-id', '" + neIdFilter + "')]";
    } else {
        xPath = this.NE_FILTER;
    }
    let result = {};
    let data = this.findByXpathPaginated(xPath, 2, 'ne-id;ne-name;type;version;product', 0, false,token);
    if (data) {
        let ret = data.map(function (ne) {
            let obj = {};
            obj["deviceId"] = ne["ne-id"];
            obj["deviceName"] = ne['ne-name'];
            obj["deviceType"] = ne["type"];
            obj["deviceVersion"] = ne['version'];
            obj["product"] = ne["product"];
            return obj;
        });
        result["data"] = JSON.stringify(ret);
    }
    return result;
};

/*
   function: getNeWithFilter
    since: NSP 21.11
    short_description: Returns NE object from NSP model
    input:
      Filter:
        description: Filter  (example : [type='5gClassicalBTS' or type='lteBTS']"
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: NE Response Object
*/
NspRestconfFwk.prototype.getNeWithFilter = function (filter) {
    let xPath = null;

    xPath = this.NE_FILTER+filter;

    let result = {};
    let data = this.findByXpathPaginated(xPath, 2, 'ne-id;ne-name;type;version;product');
    if (data) {
        let ret = data.map(function (ne) {
            let obj = {};
            obj["deviceId"] = ne["ne-id"];
            obj["deviceName"] = ne['ne-name'];
            obj["deviceType"] = ne["type"];
            obj["deviceVersion"] = ne['version'];
            obj["product"] = ne["product"];
            return obj;
        });
        result["data"] = JSON.stringify(ret);
    }
    return result;
};

/*
   function: getCustomer
    since: NSP 21.11
    short_description: Returns Customer object from SF
    output:
      response:
        type: Object
        description: Customer Response Object
*/
NspRestconfFwk.prototype.getCustomer = function () {
    let result = {};
    let data = this.findByXpathPaginated(this.CUSTOMER_GET_ALL, 2, undefined, 0, false);
    if (data) {
        result["data"] = JSON.stringify(data)
    }
    this.sfLogger.info("[RestconfFwk][getCustomer] result = {}", JSON.stringify(result));
    return result;
};

/*
   function: getServiceRootElements
    since: NSP 21.11
    short_description: Returns objects on service parent level  - depth 2
    input:
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: String
        mandatory: True
      serviceId:
        description: Service id
        type: String
        mandatory: True
      fields:
        description: restConf query fields option
        type: String
        mandatory: False
      depth:
        description: restConf depth fields option
        type: String
        mandatory: False
      alienMediator:
        description: HCO - Alien mediator name
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Service Response Object
*/
NspRestconfFwk.prototype.getServiceRootElements = function (serviceType, serviceId, fields, depth, alienMediator) {
    if (alienMediator)
        this.mediatorFwk = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger);
    let xPathFilter = this.getServiceUrlUpdateSvcType('FIND', serviceType, serviceId);
    let data;
    if (!fields)
        fields = "id;name;origin;oper-state;description;admin-state;ne-service-id;tenant";
    if (!depth)
        depth = 2
    data = this.findByXpath(xPathFilter, depth, fields);
    if (data) {
        return data[0];
    } else
        return null;
};

/*
   function: getServiceSite
    since: NSP 21.11
    short_description: Returns objects on Service Site Parent level  - depth 2
    input:
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: String
        mandatory: True
      serviceId:
        description: Service id
        type: String
        mandatory: True
      siteKeys:
        description: Service Site id
        type: String
        mandatory: False
    output:
      response:
        type: Array
        description: Service Site Response Object
*/
NspRestconfFwk.prototype.getServiceSite = function (serviceType, serviceId, siteKeys) {
    if (serviceType === 'mpls-tunnel' || serviceType === 'gre-tunnel' || serviceType === 'tunnel') {
        return [];
    }
    else{
        let xPathFilter = this.getServiceUrlUpdateSvcType('FIND', serviceType, serviceId) + "/site";
        if (siteKeys) xPathFilter += siteKeys;
        let data = this.findByXpathPaginated(xPathFilter, 2, "site-id;name");
        if (data) {
            return data;
        } else
            return [];
    }
};

/*
   function: deleteService
    since: NSP 21.11
    short_description: Delete operational service model entry
    input:
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: String
        mandatory: True
      serviceId:
        description: Service id
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: Service delete Response Object
*/
NspRestconfFwk.prototype.deleteService = function (serviceType, serviceId) {
    let preurl = this.getServiceUrlUpdateSvcType('DELETE', serviceType, encodeURIComponent(serviceId));
    let url = this.constructURL(preurl, "DELETE");

    let response = this.mediatorFwk.delete(url);
    this.sfLogger.debug("[RestconfFwk][deleteService] response = {}", JSON.stringify(response));
    return response;
};


/*
   function: getTunnel
    since: NSP 21.11
    short_description: Retrieve operational tunnel model entry
    input:
      serviceType:
        description: eline/elan/l3VPN/ies/tunnel
        type: String
        mandatory: True
      targets:
        description: Tunnel ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: Tunnel Response Object
*/
NspRestconfFwk.prototype.getTunnel = function (serviceType, targets) {
    let preurl = this.getServiceUrlUpdateSvcType('GET', serviceType, targets);
    let url = this.constructURL(preurl, "GET");

    let response = this.mediatorFwk.fetch(url);
    this.sfLogger.debug("[RestconfFwk][deleteService] response = {}", JSON.stringify(response));
    return response;
};

/*
   function: getPortByName
    since: NSP 21.11
    short_description: Retrieve NSP port model entry
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
      portName:
        description: Port Name
        type: String
        mandatory: True
      depth:
        description: depth of response
        type: Integer
        mandatory: False
    output:
      response:
        type: Object
        description: Port Response Object
*/
NspRestconfFwk.prototype.getPortByName = function (neId, portName, depth) {
    let xPathFilter;
    if (portName && portName.toLowerCase().indexOf("lag") !== -1) {
        xPathFilter = this.FIND_LAG_BY_NAME_XPATH_FILTER
            .replace("{neId}", neId)
            .replace("{portName}", portName);
    } else {
        xPathFilter = this.FIND_PORT_BY_NAME_XPATH_FILTER
            .replace("{neId}", neId)
            .replace("{portName}", portName);
    }


    let data = this.findByXpath(xPathFilter, depth);
    if (data) {
        return data[0];
    } else
        return null;
};

/*
   function: getPortByNeCommon
    since: NSP 24.8
    short_description: Retrieve NSP port that can be used to deploy service
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
      searchText:
        description: Port Name to search
        type: String
        mandatory: False
      includeLags:
        description: return lags along with ports (default true)
        type: String
        mandatory: False
      excludeLagMembers:
        description: Don't return ports that are members of lags
        type: String
        mandatory: False
      portMode:
        description: types of ports to return (all,access,hybrid,trunk,AccessOrHybrid) defaults to all
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Port Response Object
*/
NspRestconfFwk.prototype.getPortByNeCommon = function (neId, searchText, includeLags, excludeLagMembers, portMode) {
    if (!neId) {
        return [];
    } else {
        let portDetailsFilter='';
        let lagFilter='';
        let findLags = (includeLags!==undefined && includeLags===false) ? false : true;
        if(portMode==undefined || portMode==='' ||  portMode==='all') {
            portDetailsFilter='';
            lagFilter='';
        }
        else if (portMode==='AccessOrHybrid') {
            portDetailsFilter="[boolean(port-details[port-mode='access' or port-mode='hybrid'])]";
            lagFilter="lag-mode='access' or lag-mode='hybrid'";
        }
        else {
            portDetailsFilter="[boolean(port-details[port-mode='"+portMode+"'])]";
            lagFilter="lag-mode='"+portMode+"'";
        }

        let lagFilterNoSearch=(lagFilter==='') ? '' : '['+lagFilter+']';
        let lagFilterSearch=(lagFilter==='') ? '' : ' and ('+lagFilter+')';


        let portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port"+portDetailsFilter;
        if (searchText) {
            portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[contains('name','" + searchText + "')]"+portDetailsFilter;
        }
        let ret = this.findByXpathPaginated(portXPath, 3, "name;description;port-details(port-mode;encap-type);lag-member-details/lag-id", 0, false);
        if (findLags && ret) {
            let lagXpath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag" + lagFilterNoSearch;
            if (searchText) {
                lagXpath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag[contains('name','" + searchText + "')"+lagFilterSearch+"]"
            }
            let lagData = this.findByXpathPaginated(lagXpath, 2, "name;description;encap-type;lag-mode", 0, false);
            if (lagData) {
                ret = ret.concat(lagData);
            }
        }
        let result = {};
        if (ret) {
            let data = ret.map(function (port) {
                let obj = {};
                obj["port-id"] = port["name"];
                obj["description"] = port["description"];
                if (port["port-details"]) {
                    obj["encapType"] = port["port-details"][0]["encap-type"]
                    obj["port-mode"] = port["port-details"][0]["port-mode"]
                }
                if (port["encap-type"]) {
                    obj["encapType"] = port["encap-type"];
                }
                if (port["lag-mode"]) {
                    obj["port-mode"] = port["lag-mode"];
                }
                if (port["lag-member-details"]) {
                    obj["lag-member-details"] = port["lag-member-details"];
                }
                return obj;
            }).filter(function (obj) {
                //remove public ipSec tunnel
                if (obj["port-id"].indexOf(".public") !== -1){}
                else if(excludeLagMembers===true && 'lag-member-details' in obj){}
                else
                    return obj
            });
            result["data"] = JSON.stringify(data);
        }
        return result
    }
};

/*
   function: getAccessHybridPortByNe
    since: NSP 21.11
    short_description: Retrieve NSP port that can be used to deploy service
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
      searchText:
        description: Port Name to search
        type: String
        mandatory: False
      includeLags:
        description: return lags along with ports (default true)
        type: String
        mandatory: False
        since: 24.8
      excludeLagMembers:
        description: Don't return ports that are members of lags
        type: String
        mandatory: False
        since: 24.8
    output:
      response:
        type: Object
        description: Port Response Object
*/
NspRestconfFwk.prototype.getAccessHybridPortByNe = function (neId, searchText, includeLags, excludeLagMembers) {
    return this.getPortByNeCommon(neId, searchText, includeLags, excludeLagMembers, 'AccessOrHybrid');
};


/*
   function: getTrunkPortByNe
    since: NSP 24.8
    short_description: Retrieve NSP port that are trunk mode
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
      searchText:
        description: Port Name to search
        type: String
        mandatory: False
      includeLags:
        description: return lags along with ports (default true)
        type: String
        mandatory: False
        since: 24.8
      excludeLagMembers:
        description: Don't return ports that are members of lags
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Port Response Object
*/
NspRestconfFwk.prototype.getTrunkPortByNe = function (neId, searchText, includeLags, excludeLagMembers) {
    return this.getPortByNeCommon(neId, searchText, includeLags, excludeLagMembers, 'trunk');
};

/*
function: getWavencePortByNe
 since: NSP 22.3
 short_description: Retrieve NSP Wavence Port that can be used to deploy service
 input:
   neId:
     description: NE system ID
     type: String
     mandatory: True
   searchText:
     description: Port Name to search
     type: String
     mandatory: False
 output:
   response:
     type: Object
     description: Port Response Object
*/
NspRestconfFwk.prototype.getWavencePortByNe = function (neId, searchText, isVlan) {
    if (!neId) {
        return [];
    } else {
        let portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[boolean(port-details[port-mode='access' or port-mode='trunk'])][not(contains('name','Channel'))][not(boolean(port-details[encap-type='unknown']))][not(boolean(port-details[port-type='todio-port']))][not(boolean(lag-member-details[lag-id != 'n/a']))]";
        if (searchText) {
            portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[contains('name','" + searchText + "')][boolean(port-details[port-mode='access' or port-mode='trunk'])][not(contains('name','Channel'))][not(boolean(port-details[encap-type='unknown']))][not(boolean(port-details[port-type='todio-port']))][not(boolean(lag-member-details[lag-id != 'n/a']))]"
        }
        if(isVlan)
        {
            portXPath = portXPath +"[not(boolean(port-details[port-type='tdm-port']))][not(boolean(port-details[port-type='sonet']))]";
        }
        else {
            portXPath = portXPath +"[admin-state='unlocked']";
        }
        let ret = this.findByXpath(portXPath, 3);
        if (ret) {
            let lagXpath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag[lag-mode='access' or lag-mode='trunk']";
            if (searchText) {
                lagXpath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag[lag-mode='access' or lag-mode='trunk']/lag[contains('name','" + searchText + "')]"
            }
            let lagData = this.findByXpath(lagXpath, 2, "name");
            if (lagData) {
                ret = ret.concat(lagData);
            }
        }
        let result = {};
        if (ret) {
            let data = ret.map(function (port) {
                let obj = {};
                obj["port-id"] = port["name"];
                obj["description"] = port["description"];
                if (port["port-details"]) {
                    obj["encapType"] = port["port-details"][0]["encap-type"]
                }
                if (port["encap-type"]) {
                    obj["encapType"] = port["encap-type"];
                }
                return obj;
            });
            result["data"] = JSON.stringify(data);
        }
        return result
    }
};


/*
function: getPortByNE
 since: NSP 23.11
 short_description: Retrieve NSP Port that can be used to deploy service
 input:
   neId:
     description: NE system ID
     type: String
     mandatory: True
   searchText:
     description: Port Name to search
     type: String
     mandatory: False
   includeLags:
     description: return lags along with ports (default true)
     type: String
     mandatory: False
     since: 24.8
   excludeLagMembers:
     description: Don't return ports that are members of lags
     type: String
     mandatory: False
     since: 24.8
 output:
   response:
     type: Object
     description: Port Response Object
*/
NspRestconfFwk.prototype.getPortByNE = function (neId, searchText, includeLags, excludeLagMembers) {
    return this.getPortByNeCommon(neId, searchText, includeLags, excludeLagMembers, 'all');
};


/*
   function: getServiceTunnelBySourceDestination
    since: NSP 21.11
    short_description: Retrieve Tunnel using source and destination
    input:
      source:
        description: Source NE system ID
        type: String
        mandatory: True
      destination:
        description: Destination NE system ID
        type: String
        mandatory: True
      steeringParam:
        description: NSP Steering parameter if any
        type: String
        mandatory: False
    output:
      response:
        type: Array
        description: Tunnel Response Object
*/
NspRestconfFwk.prototype.getServiceTunnelBySourceDestination = function (source, destination, steeringParam) {
    let xPathFilter = (this.MPLS_TUNNEL_SOURCEDESTINATION_XPATH_FILTER + "|" + this.GRE_TUNNEL_SOURCEDESTINATION_XPATH_FILTER)
        .replace(/\{source\}/g, source)
        .replace(/\{destination\}/g, destination);

    let tunnelData = this.findByXpathPaginated(xPathFilter, 5);
    if (tunnelData && !steeringParam) {
        let ret = [];
        tunnelData.forEach(function (tunnel) {
            if (tunnel["id"]) {
                ret.push({
                    "id": tunnel["id"],
                    "name": tunnel["name"],
                    "oper-state": tunnel["oper-state"],
                    "admin-state": tunnel["admin-state"]
                });
            }
        });
        this.sfLogger.info("[RestconfFwk][getServiceTunnelObjBySourceDestination] ret = {}", JSON.stringify(ret));
        return ret;
    } else if (tunnelData && steeringParam) {
        let ret = [];
        tunnelData.forEach(function (tunnel) {
            if (tunnel["id"]) {
                if (tunnel["service-extension:mpls-tunnel-ext"] || tunnel["service-extension:gre-tunnel-ext"]) {
                    let extensionObj;
                    if (tunnel["service-extension:mpls-tunnel-ext"]) {
                        extensionObj = tunnel["service-extension:mpls-tunnel-ext"];
                    } else {
                        extensionObj = tunnel["service-extension:gre-tunnel-ext"];
                    }

                    if (extensionObj && extensionObj["steering-parameter"]) {
                        let labels = extensionObj["steering-parameter"]["labels"];
                        labels.forEach(function (label) {
                            if (label.label && label.label === steeringParam) {
                                ret.push({
                                    "id": tunnel["id"],
                                    "name": tunnel["name"],
                                    "oper-state": tunnel["oper-state"],
                                    "admin-state": tunnel["admin-state"]
                                });
                            }
                        })
                    }

                }
            }
        });
        this.sfLogger.info("[RestconfFwk][getServiceTunnelObjBySourceDestination] ret = {}", JSON.stringify(ret));
        return ret;
    } else {
        return [];
    }
};



/*
   function: getAdminGroup
    since: NSP 21.11
    short_description: Retrieve Tunnel using admin group
    input:
      srcNeId:
        description: Source NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: Tunnel Response Object
*/
NspRestconfFwk.prototype.getAdminGroup = function (srcNeId) {
    let preurl = this.MdcAdminGroup.replace('{deviceId}', srcNeId);
    let url = this.constructURL(preurl, "GET");

    let ret = [];
    if (srcNeId === '') {
        return ret;
    }
    let response = this.mediatorFwk.fetch(url)["response"];
    if (response["nokia-conf:group-name"]) {
        response["nokia-conf:group-name"].forEach(function (param) {
            ret.push(param['group-name']);
        });
    }
    this.sfLogger.info("[RestconfFwk][getAdminGroup] response = {}", JSON.stringify(ret));
    return ret;
};

/*
   function: getSteeringParam
    since: NSP 21.11
    short_description: Retrieve All NSP Steering parameters
    output:
      response:
        type: Object
        description: NSP Steering parameters response Object
*/
NspRestconfFwk.prototype.getSteeringParam = function () {
    let preurl = this.ServiceSteeringParam;
    let url = this.constructURL(preurl, "GET");
    let ret = [];
    let response = this.mediatorFwk.fetch(url)["response"];
    if (response["steering-parameters:parameters"]["parameter"]) {
        response["steering-parameters:parameters"]["parameter"].forEach(function (param) {
            ret.push(param.label);
        });
    }
    this.sfLogger.info("[RestconfFwk][getSteeringParam] response = {}", JSON.stringify(ret));
    return ret;
};

/*
   function: getLsps
    since: NSP 21.11
    short_description: Retrieve LSP object based on source and destination
    input:
      srcNeId:
        description: Source NE system ID
        type: String
        mandatory: True
      destNeid:
        description: Destination NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: LSP Response Object
*/
NspRestconfFwk.prototype.getLsps = function (srcNeId, destNeid) {
    destNeid = this.sfUtils.getIpv4System(destNeid);
    let preurl = this.MdcLsps.replace('{deviceId}', srcNeId);
    let url = this.constructURL(preurl, "GET");

    let ret = [];
    if (srcNeId === '' || destNeid === '') {
        return ret;
    }
    let response = this.mediatorFwk.fetch(url)["response"];
    if (response["nokia-conf:lsp"]) {
        response["nokia-conf:lsp"].forEach(function (param) {
            if (param.to === destNeid) {
                ret.push(param['lsp-name']);
            }
        });
    }
    this.sfLogger.info("[RestconfFwk][getLsps] response = {}", JSON.stringify(ret));
    return ret;
};

/*
   function: getNextSvcMgrId
    since: NSP 21.11
    short_description: Obtain next serviceMgrID from resourceManager and verify its still available in NFMP
    output:
      response:
        type: String
        description: Free NFMP serviceMgrID
*/
NspRestconfFwk.prototype.getNextSvcMgrId = function () {
    let url = this.constructURL("/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools=ibsf-global-svc-id-pool,global/obtain-value-from-pool", "POST");
    let requestBody = {
        "nsp-resource-pool:input": {
            "total-number-of-resources": 1,
            "all-or-nothing": true,
            "owner": "svcmgrglobalid",
            "confirmed": true
        }
    };

    let svcMgrId = null;
    let count = 0;
    while (!svcMgrId) {
        let response = this.mediatorFwk.post(url, requestBody);
        if (!response.success || count == 25) {
            this.sfLogger.error("[RestconfFwk][createService] Failed to get svcMgrId : {}", JSON.stringify(response));
            throw new RuntimeException("Failed to populate svcMgrId");
        } else {
            this.sfLogger.debug("[RestconfFwk][createService] Successfully got svcMgrId : {}", JSON.stringify(requestBody));
        }
        if (response["response"]) {
            response = JSON.parse(response["response"]);
            svcMgrId = response["nsp-resource-pool:output"]["num-consumed-resources"][0]["value"];
            let nfmpPayload = {
                "fullClassName": "service.Service",
                "filter": {
                    "equal": {
                        "name": "objectFullName",
                        "value": "svc-mgr:service-" + svcMgrId
                    }
                },
                "resultFilter": {
                    "attribute": [
                        "objectFullName"
                    ],
                    "children": {}
                }
            };
            let mediators = mds.getAllManagersOfType("REST");
            let self = this;
            mediators.forEach(function (lMeditor) {
                if (lMeditor.indexOf("NFM-P") !== -1){
                    let nfmpFwk = new MediatorFramework(lMeditor);
                    let serviceFetch = nfmpFwk.post( "/v3/search", nfmpPayload);
                    if (serviceFetch.success && !(serviceFetch.response === "{}" || serviceFetch.response.indexOf("does not exist") !== -1)) {
                        self.sfLogger.error("[RestconfFwk][createService] svcMgrId : svc-mgr:service-{} is already in use. Fetching next number", svcMgrId);
                        svcMgrId = null;
                        count++;
                    }
                }
            })
        }
    }

    return svcMgrId;
};
/*
function: getWavenceVPRNNodes
 since: NSP 22.3
 short_description: Retrieves Wavence(CorEvo) and SR 7750 nodes supported for L3 Service
 output:
   response:
     type: Object
     description: Supported Nodes List Object
*/
NspRestconfFwk.prototype.getWavenceVPRNNodes = function(){
    let supportedNodesList = [];
    let nfmpPayload = {
        "fullClassName": "netw.NetworkElement",
        "filter": {
            "or": {
                "equal" : [{"name": "productType","value": 1}], //7750 SR Nodes
                "and": {
                    "equal" : [{"name": "productType","value": 18}], //Wavence nodes
                    "or": {
                        "equal": [
                            {"name": "chassisPortIdScheme", "value" : 2}, //List Only CoreEvo Nodes
                            {"name": "chassisPortIdScheme", "value" : 3}
                        ]}
                }
            }
        },
        "resultFilter": {
            "attribute": [
                "siteId",
                "siteName"
            ],
            "children": {}
        }
    };
    let nfmpFwk = new MediatorFramework("NFMP");
    let networkElementFetch = nfmpFwk.post("/v3/search", nfmpPayload);
    if (!networkElementFetch.success && !networkElementFetch["response"])
        return supportedNodesList;
    networkElementFetch = JSON.parse(networkElementFetch["response"]);
    if(networkElementFetch["netw.NetworkElement"])
    {
        if (Array.isArray(networkElementFetch["netw.NetworkElement"])){
            for (var  j = 0; j < networkElementFetch["netw.NetworkElement"].length; j++) {
                let obj = {};
                obj["ne-id"] = networkElementFetch["netw.NetworkElement"][j]["siteId"]
                obj["ne-name"] = networkElementFetch["netw.NetworkElement"][j]["siteName"]
                supportedNodesList.push(obj);
            }
        } else {
            supportedNodesList.push(networkElementFetch["netw.NetworkElement"]["siteId"]);
        }
    }
    return supportedNodesList;
};

/*
function: getWavenceBackhaulNodes
 since: NSP 22.6
 short_description: Retrieves Wavence Backhaul nodes supported for L2 Service
 output:
   response:
     type: Object
     description: Supported Nodes List Object
*/
NspRestconfFwk.prototype.getWavenceBackhaulNodes = function(){
    let supportedNodesList = [];
    let nfmpPayload = {
        "fullClassName": "netw.NetworkElement",
        "filter": {
            "equal" : [{"name": "productType","value": 18}] //Wavence Nodes
        },
        "resultFilter": {
            "attribute": [
                "siteId",
                "siteName",
                "chassisType"
            ],
            "children": {}
        }
    };
    let nfmpFwk = new MediatorFramework("NFMP");
    let networkElementFetch = nfmpFwk.post("/v3/search", nfmpPayload);
    if (!networkElementFetch.success && !networkElementFetch["response"])
        return supportedNodesList;
    networkElementFetch = JSON.parse(networkElementFetch["response"]);
    if(networkElementFetch["netw.NetworkElement"])
    {
        if (Array.isArray(networkElementFetch["netw.NetworkElement"])){
            for (var  j = 0; j < networkElementFetch["netw.NetworkElement"].length; j++) {
                let obj = {};
                obj["ne-id"] = networkElementFetch["netw.NetworkElement"][j]["siteId"]
                obj["ne-name"] = networkElementFetch["netw.NetworkElement"][j]["siteName"]
                supportedNodesList.push(obj);
            }
        } else {
            supportedNodesList.push(networkElementFetch["netw.NetworkElement"]["siteId"]);
        }
    }
    return supportedNodesList;
};

/*
   function: getAccountingPoliciesMdc
    since: NSP 23.4
    short_description: Retrieve Accounting Polices from Mdc
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: Accounting Policy IDs
*/
NspRestconfFwk.prototype.getAccountingPoliciesMdc = function (neId, alienMediator) {
    let preurl = this.MdcAccountingPolicies.replace('{deviceId}', neId);
    let url = this.constructURL(preurl, "GET");

    let returnObj = {};
    if (neId === '') {
        return ret;
    }
    let response;
    if (alienMediator){
        response = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger).fetch(url)["response"];
    } else
        response = this.mediatorFwk.fetch(url)["response"];
    if (response["nokia-conf:accounting-policy"]) {
        let accPolicies = response["nokia-conf:accounting-policy"];
        let ret = accPolicies.map(function (policy) {
            let obj = {};
            obj["accountingPolicyId"] = policy["policy-id"];
            obj["accountingPolicyName"] = "N/A";
            return obj;
        });
        returnObj["data"] = JSON.stringify(ret);
    }
    this.sfLogger.info("[RestconfFwk][accounting-policy] response = {}", JSON.stringify(returnObj));
    return returnObj;
};

/*
   function: getAccountingPoliciesNfmp
    since: NSP 23.4
    short_description: Retrieve Accounting Polices from Nfmp
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
      alienMediator:
        description: HCO - NFMP Alien mediator
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Accounting Policy IDs
*/
NspRestconfFwk.prototype.getAccountingPoliciesNfmp = function (neId, alienMediator) {
    let payload = {
        "fullClassName": "accounting.Policy",
        "filter": {
            "and": {
                "equal": [
                    {"name": "siteId", "value": neId},
                    {"name": "isLocal", "value": true},
                ]
            }
        },
        "resultFilter": {
            "attribute": [
                "id",
                "displayedName"
            ],
            "children": {}
        }
    };
    let results = null;
    if (alienMediator)
        results = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger).post("/v3/search", payload);
    else
        results = new MediatorFramework("NFMP", this.sfLogger).post("/v3/search", payload);
    if (!results || !results.success) {
        throw new RuntimeException(results.msg);
    }
    let res=JSON.parse(results.response);
    let returnObj = {};

    if("accounting.Policy" in res && typeof(res["accounting.Policy"])==='object' && res["accounting.Policy"]!==null) {

        if(Array.isArray(res["accounting.Policy"])===false){
            res["accounting.Policy"]=[res["accounting.Policy"]];
        }

        let ret = res["accounting.Policy"].map(function (policy) {
            let obj = {};
            obj["accountingPolicyId"] = policy["id"];
            obj["accountingPolicyName"] = policy['displayedName'];
            return obj;
        });
        returnObj["data"] = JSON.stringify(ret);
    }
    return returnObj;
};

/*
   function: findBySourcePaginated
    since: NSP 23.11
    short_description: Read Restconf URL using Inventory Find by source
    input:
      schemaNodeId:
        description: Restconf path
        type: String
        mandatory: True
      sources:
        description: source filter
        type: String
        mandatory: True
      depth:
        description: depth of the return Query
        type: Integer
        mandatory: False
      fields:
        description: Fields to return
        type: String
        mandatory: False

    output:
      response:
        type: Object
        description: Restconf payload
*/
NspRestconfFwk.prototype.findBySource = function (schemaNodeId,sources, depth, fields) {
    if (!depth) depth = 2;
    let url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_BY_SOURCE_URL, "POST");
    let input = {};
    let ret = [];
    input["schema-nodeid"] = [schemaNodeId];
    input["depth"] = depth;
    input["sources"] = sources;

    if (fields !== undefined)
        input["fields"] = fields;
    let requestBody = {};
    requestBody["input"] = input;

    let response = this.mediatorFwk.post(url, requestBody);
    this.sfLogger.debug("[RestconfFwk][findBySourcePaginated] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        let lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"]) {
            let data = lRes["nsp-inventory:output"]["data"];
            if (data.length !== 0){
                ret = ret.concat(data);
            }
        }
    }
    return ret;
};

/*
   function: getTunnelInterface
    since: NSP 23.11
    short_description: Retrieve tunnel-interfaces  from Mdc
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: tunnel Interfaces
*/
NspRestconfFwk.prototype.getTunnelInterfacesMdc = function (neId) {
    let preurl = this.MdcTunnelInterfaces.replace('{deviceId}', neId);
    let url = this.constructURL(preurl, "GET");

    let returnObj = {};
    if (neId === '') {
        return ret;
    }
    let response = this.mediatorFwk.fetch(url)["response"];
    if (response["srl_nokia-tunnel-interfaces:tunnel-interface"]) {
        let tunnelInterfaces = response["srl_nokia-tunnel-interfaces:tunnel-interface"];
        let ret = tunnelInterfaces.map(function (tunnelInterface) {
            let obj = {};
            obj["tunnel-interface"] = tunnelInterface["name"];
            return obj;
        });
        returnObj["data"] = JSON.stringify(ret);
    }
    this.sfLogger.info("[RestconfFwk][tunnel-interface] response = {}", JSON.stringify(returnObj));
    return returnObj;
};

/*
   function: getIRBInterfaceFromMdc
    since: NSP 24.8
    short_description: Retrieve IRB interfaces from Mdc
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: IRB interfaces
*/
NspRestconfFwk.prototype.getIRBInterfaceFromMdc = function (neId) {
  let preurl = this.MdcIRBInterfaces.replace('{deviceId}', neId);
  let url = this.constructURL(preurl, "GET");

  let returnObj = [];
  if (neId === '') {
      return returnObj;
  }
  let response = this.mediatorFwk.fetch(url)["response"];
  let irbInterfaces = response["srl_nokia-interfaces:interface"];
  if (irbInterfaces) {
      if(Array.isArray(irbInterfaces)){
        for (var index in irbInterfaces) {
          if(irbInterfaces[index]["name"].indexOf("irb") === 0){
          logger.debug("irbName " + irbInterfaces[index]["name"]);
          returnObj.push(irbInterfaces[index]["name"]);
          }
        }
      }
    }
      returnObj = returnObj.filter(function (value) {
        return value != null;
    });

  this.sfLogger.info("[RestconfFwk][IRB-Interface] response = {}", JSON.stringify(returnObj));
  return returnObj;
};

/*
   function: getConnectionProfilesMdc
    since: NSP 24.8
    short_description: Retrieve Connection Profiles from Mdc
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: Object
        description: Connection Profile IDs
*/
NspRestconfFwk.prototype.getConnectionProfilesMdc = function (neId, alienMediator) {
  let preurl = this.MdcConnectionProfiles.replace('{deviceId}', neId);
  let url = this.constructURL(preurl, "GET");

  let returnObj = {};
  if (neId === '') {
      return ret;
  }
  let response;
  if (alienMediator){
      response = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger).fetch(url)["response"];
  } else
      response = this.mediatorFwk.fetch(url)["response"];
  if (response["nokia-conf:vlan"]) {
      let conPolicies = response["nokia-conf:vlan"];
      let ret = conPolicies.map(function (policy) {
          let obj = {};
          obj["connectionProfileId"] = policy["connection-profile-id"];
          obj["connectionProfileName"] = "N/A";
          return obj;
      });
      returnObj["data"] = JSON.stringify(ret);
  }
  this.sfLogger.info("[RestconfFwk][connection-profile] response = {}", JSON.stringify(returnObj));
  return returnObj;
};

/*
   function: getConnectionProfilesNfmp
    since: NSP 24.8
    short_description: Retrieve Connection Profiles from Nfmp
    input:
      neId:
        description: NE system ID
        type: String
        mandatory: True
      alienMediator:
        description: HCO - NFMP Alien mediator
        type: String
        mandatory: False
    output:
      response:
        type: Object
        description: Connection Profile IDs
*/
NspRestconfFwk.prototype.getConnectionProfilesNfmp = function (neId, alienMediator) {
  let payload = {
      "fullClassName": "connprof.VlanConnProfPolicy",
      "filter": {
          "and": {
              "equal": [
                  {"name": "siteId", "value": neId},
                  {"name": "isLocal", "value": true},
              ]
          }
      },
      "resultFilter": {
          "attribute": [
              "id"
          ],
          "children": {}
      }
  };
  let results = null;
  if (alienMediator)
      results = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger).post("/v3/search", payload);
  else
      results = new MediatorFramework("NFMP", this.sfLogger).post("/v3/search", payload);
  if (!results || !results.success) {
      throw new RuntimeException(results.msg);
  }
  let res=JSON.parse(results.response);
  let returnObj = {};

  if("connprof.VlanConnProfPolicy" in res && typeof(res["connprof.VlanConnProfPolicy"])==='object' && res["connprof.VlanConnProfPolicy"]!==null) {

      if(Array.isArray(res["connprof.VlanConnProfPolicy"])===false){
          res["connprof.VlanConnProfPolicy"]=[res["connprof.VlanConnProfPolicy"]];
      }

      let ret = res["connprof.VlanConnProfPolicy"].map(function (policy) {
          let obj = {};
          obj["connectionProfileId"] = policy["id"];
          obj["connectionProfileName"] = "N/A";
          return obj;
      });
      returnObj["data"] = JSON.stringify(ret);
  }
  return returnObj;
};
