// creating a new javascript class for handling oam functionality

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk'});


function oamFWK(sfLogger) {
    if (sfLogger)
        this.sfLogger = sfLogger;
}
oamFWK.prototype.target = null;
oamFWK.prototype.intentTypeName = null;
oamFWK.prototype.intentTypeVersion = null;
oamFWK.prototype.nspRestconfFwk = new NspRestconfFwk();
oamFWK.prototype.sfLogger = new ServiceFulfillmentLogger();
oamFWK.prototype.mediatorFwk = new MediatorFramework("NSP");


// Creating a function to collect data

oamFWK.prototype.extractSiteDetails = function (payload,target) {
   
    let sites = ['site-a', 'site-b'];
    let transformedData = [];
  
    sites.forEach((siteKey) => {
      let site = payload['evpn-epipe:evpn-epipe'][siteKey];
      let neServiceId = payload['evpn-epipe:evpn-epipe']["ne-service-id"];
      let deviceId = site['device-id'];
      let oamTestSrc = site['oam-test-src'];
      let siteName = site['site-name'];
      let outerVlan = site['sap-details']['sap'][0]['outer-vlan-tag'];
      let identifier = site['local-ac']['name']; // Assuming identifier is derived from local-ac name
      let portId = site['sap-details']['sap'][0]['port-id']; // Maps to 'resource'
      
      
      let sapInfo = this.nspRestconfFwk.findByXpath("/nsp-service:services/service-layer/eline[service-id='"+target+"']/endpoint[endpoint-id='" + deviceId  + "-"+portId+":"+outerVlan+"']/port-bindings", 4);
    

      let sapResource = sapInfo[0]['resource'];

      let portInfo = this.nspRestconfFwk.findByXpath(sapResource , 4,"hw-mac-address");
      
      let hwMacAddress = portInfo[0]['hw-mac-address'];
      




      transformedData.push({
        'site-id': deviceId,
        'neServiceId': neServiceId,
        'oamTestSrc': oamTestSrc,
        'endpoint-id': site['local-ac']['name'],
        'outer-tag': outerVlan,
        'nsp-model:identifier': identifier,
        'site-name': siteName,
        'macAddress': hwMacAddress,
        'resource': "/nsp-service:services/service-layer/eline[service-id='"+target+"']/endpoint[endpoint-id='" + deviceId + "-"+portId+":"+outerVlan+"']"
        
      });


    });
  
    return transformedData;
};


oamFWK.prototype.createTest = function (data) {
   
  
    let src = null;
    let dest = null;
    let neServiceId= null;
    let src_dev  = null;
    let dest_mac  = null;
    let rbody = {}

    for (let i = 0; i < data.length; i++) {
    if (data[i]["oamTestSrc"] === true) {
        src = data[i]["resource"];
        neServiceId = data[i]["neServiceId"];
        src_dev = data[i]["site-id"];
    } else if (data[i]["oamTestSrc"] === false) {
        dest = data[i]["resource"];
        dest_mac = data[i]["macAddress"];
     }
    }

    rBody = {
        "cfm-dmm": [
          {
            "admin-state": "disable",
            "app-id": "NSP",
            "association": { "string": "srv:${service-id}" },
            "bin-group": 1,
            "binding-mep-direction": "down",
            "bulk-result": false,
            "create-and-execute": false,
            "data-tlv-size": 0,
            "deployment-asynchronous": false,
            "domain": { "name": "TEMP_CFM" },
            "entities": [
              {
                "entity-type": "source",
                "entity-reference": "/nsp-service:services/service-layer/eline[service-id='sr_exp_test']/endpoint[endpoint-id='10.10.10.3-1/1/c4/1:300']"
              },
              {
                "entity-type": "destination",
                "entity-reference": "/nsp-service:services/service-layer/eline[service-id='sr_exp_test']/endpoint[endpoint-id='10.10.10.8-1/1/c3/1:300']"
              }
            ],
            "execute-type": "on-demand",
            "interval": 100,
            "level": 6,
            "ma-name": "srv:${service-id}",
            "md-name": "TEMP_CFM",
            "measurement-interval": 5,
            "name": "Test",
            "notify-target-ne": "never",
            "priority": 0,
            "reuse-existing-mep": true,
            "sap-mep-direction": "up",
            "source-mep-id": 1,
            "streaming-template": "default",
            "test-duration": 10,
            "test-id": neServiceId,
            "name": neServiceId +"_dmm",
            "dest-mac-address": dest_mac,
            "template": "/nsp-oam:templates/oam-test:templates/cfm-dmm[name='Delay Streaming (on-demand)']"
          }
        ]
      };


    // add logic to do the api calls to create the test
        
     rBody = {
          "input": {
            "test-type": "/nsp-oam:tests/oam-test:tests/cfm-dmm",
            "tests": [
              "/nsp-oam:tests/oam-test:tests/cfm-dmm[ne-id='"+src_dev+"'][name='"+neServiceId+"_dmm']"
            ],
            "limit": 100,
            "start": 0
          }
        }
     
    // Sleep function using busy-wait (blocks CPU) --- care no other option nashorn limitation
    function sleep(ms) {
        var start = new Date().getTime();
        while (new Date().getTime() - start < ms) {
            // do nothing
        }
    }

    // Polling loop
    var maxRetries = 10;
    var intervalMs = 3000;
    var attempt = 0;

    while (attempt < maxRetries) {
        var response = this.CRUD("https://restconf-gateway/restconf/operations/nsp-oam:list-executing-tests", rbody, "post");


        var tests = response["nsp-oam:output"]["tests"];

        var check = "/nsp-oam:tests/oam-test:tests/cfm-dmm[ne-id='" + src_dev + "'][name='" + neServiceId + "_dmm']";

        if (tests.indexOf(check) === -1) {
            break;
        }

        sleep(intervalMs);  // busy wait for 3 seconds
        attempt++;
        
        if (attempt === maxRetries) {
            break;
        }
    }

            
    rBody = {
        "input": {
          "start": "2025-04-09T01:33:53.662Z",
          "limit": 100,
          "sort-by": ["-time-captured", "-direction"],
          "result-class": "telemetry:/base/oam-pm/eth-cfm-delay-streaming",
          "depth": 1
        }
      }
      

    let response_res = this.CRUD("https://restconf-gateway/restconf/data/nsp-oam:tests/oam-test:tests/cfm-dmm="+src_dev+","+neServiceId+"_dmm/get-results", rBody,"post");
      


  
    return response_res;
};


oamFWK.prototype.CRUD = function (url,body,type) {
   
    let ret = {};
    let response = {}
    if (type === "post"){
        response = this.mediatorFwk.post(url, rBody);
    }else if(type === "delete"){
        response = this.mediatorFwk.delete(url);
    }else if(type === "get"){
        response = this.mediatorFwk.fetch(url);
    };
    
    this.sfLogger.debug("[RestconfFwk][OAMPost] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        if (type === "get"){
            ret  = response;
        }else{
            ret  = JSON.parse(response["response"]);
        }
    }
  
    return ret;
};
