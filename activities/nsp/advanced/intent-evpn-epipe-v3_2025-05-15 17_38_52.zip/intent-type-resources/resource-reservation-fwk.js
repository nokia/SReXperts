function ResourceReservationFwk(neId, siteObj, svcType) {
    this.siteId = neId;
    this.siteObj = siteObj;
    this.svcType = svcType;
}

ResourceReservationFwk.prototype.siteId = null;
ResourceReservationFwk.prototype.siteObj = null;
ResourceReservationFwk.prototype.payload = {"vlan":[], "rd":[], "vcid":[]};
ResourceReservationFwk.prototype.svcType = null;
ResourceReservationFwk.prototype.sfLogger = new ServiceFulfillmentLogger();

ResourceReservationFwk.prototype.populateVlan = function () {
    if (this.siteObj["sap-details"] && this.siteObj["sap-details"]["sap"]) {
        for (let  j = 0; j < this.siteObj["sap-details"]["sap"].length; j++) {
            let endpointAmi = this.siteObj["sap-details"]["sap"][j];
            if (endpointAmi["port-id"] && (!endpointAmi["connection-profile-id"] || endpointAmi["connection-profile-id"] == null)) {
                let endpointDevice = {};
                endpointDevice["inner"] = endpointAmi["inner-vlan-tag"];
                endpointDevice["outer"] = endpointAmi["outer-vlan-tag"];
                endpointDevice["portName"] = endpointAmi["port-id"];

                this.payload["vlan"].push(endpointDevice);
            }
        }
    }
};

ResourceReservationFwk.prototype.populateRd = function () {
    if (this.siteObj["mpls"] && this.siteObj["mpls"]["bgp-instance"] && this.siteObj["mpls"]["bgp-instance"]["route-distinguisher"])
        this.payload["rd"].push({"rd": this.siteObj["mpls"]["bgp-instance"]["route-distinguisher"]});
};

ResourceReservationFwk.prototype.rtPayload = function (requestContext) {
    if (!requestContext) requestContext = requestScope.get();
    this.sfLogger = requestContext.get("sfLogger");

    let ret = [];
    if (this.siteObj["mpls"] && this.siteObj["mpls"]["bgp-instance"] && this.siteObj["mpls"]["bgp-instance"]["route-target"]) {
        for (let  j = 0; j < this.siteObj["mpls"]["bgp-instance"]["route-target"].length; j++) {
            let rtAmi = this.siteObj["mpls"]["bgp-instance"]["route-target"][j];
            let rtDevice = {};
            if (rtAmi["target-type"] === "imp")
                rtDevice["rttype"] = "import";
            else if (rtAmi["target-type"] === "exp")
                rtDevice["rttype"] = "export";
            else
                rtDevice["rttype"] = rtAmi["target-type"];
            rtDevice["asnumber"] = rtAmi["target-value"];

            ret.push(rtDevice);
        }
    }
    return ret;
};

ResourceReservationFwk.prototype.nePayload = function (requestContext) {
    if(!requestContext) requestContext = requestScope.get();
    this.payload  = {"vlan":[], "rd":[], "vcid":[]};
    this.sfLogger = requestContext.get("sfLogger");

    this.sfLogger.debug("[ResourceReservationFwk] site model " + JSON.stringify(this.siteObj));
    if (!this.siteObj)
        throw new RuntimeException("[ResourceReservationFwk]  Service Site level object is null");
    this.populateVlan();
    this.populateRd();
    this.payload["ne-id"] = this.siteId;
    return this.payload;
};

