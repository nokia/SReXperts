load({script: resourceProvider.getResource('sf-logger.js'), name: 'ServiceFulfillmentLogger'});

function RestAuthFwk(name, sflogger) {
    this.mediatorName = name;
    if (sflogger)
        this.sfLogger = sflogger;
    else
        this.sfLogger = new ServiceFulfillmentLogger();

    this.mediatorIp = "restconf-gateway";
    this.mediatorPort = "443";
    this.mediatorProtocol = "https";
}

RestAuthFwk.prototype.mediatorIp = "";
RestAuthFwk.prototype.mediatorPort = "";
RestAuthFwk.prototype.mediatorProtocol = "";
RestAuthFwk.prototype.mediatorName = "";
RestAuthFwk.prototype.contentType = "application/json";
RestAuthFwk.prototype.acceptType = "application/json";
RestAuthFwk.prototype.sfLogger = new ServiceFulfillmentLogger();

/*
   function: configRestClient
    since: NSP 24.11
    short_description: Set Restclient ip address port and token
    input:
        url:
          description: URL where payload needs to be sent
          type: String
          mandatory: True
        httpMethod:
          description: POST
          type: String
          mandatory: True
*/
RestAuthFwk.prototype.configRestClient = function (url, httpMethod, token) {
    this.sfLogger.info("[REST-AUTH-FWK] Mediator-type: {} protocol: {} ip: {} port: {} URL :{} mediatorHttpMethod :{} token:{}", this.mediatorName, this.mediatorProtocol, this.mediatorIp, this.mediatorPort, url, httpMethod,token);
    restClient.setIp(this.mediatorIp);
    restClient.setPort(this.mediatorPort);
    restClient.setProtocol(this.mediatorProtocol);
    if(token) {
        restClient.setBearerToken(token.substring(7));
    }
};

/*
   function: post
    since: NSP 24.11
    short_description: Performs HTTP POST
    input:
        targetUrl:
          description: URL for POST
          type: String
          mandatory: True
        payloadObj:
          description: Payload for POST
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http POST response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to NFMP, got response {"generic.GenericObject.configureChildInstanceException":{"description":"[ app: generic:property:mutator ] [ class: epipe.Site ] [ instance: epipe.Site.1.1.1.1 ] [ descr: property mtu cannot be set to value passed in : -2. Value out of range., {mtu=-2} ]"},"objectFullName":""}",
            response: "{\"generic.GenericObject.configureChildInstanceException\":{\"description\":\"[ app: generic:property:mutator ] [ class: epipe.Site ] [ instance: epipe.Site.1.1.1.1 ] [ descr: property mtu cannot be set to value passed in : -2. Value out of range., {mtu=-2} ]\"},\"objectFullName\":\"\"}"
          }
*/
RestAuthFwk.prototype.post = function (targetUrl, payloadObj, token) {
    let restStartTime = Date.now();
    let result = {};
    this.configRestClient(targetUrl, "POST",token);
    let self = this;
    restClient.post(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        self.sfLogger.info("[REST-AUTH-FWK][POST] MediatorSvcName: {} URL: {}, Payload: {}", self.mediatorIp, targetUrl, JSON.stringify(payloadObj, null, 2));
        self.sfLogger.info("[REST-AUTH-FWK][POST] Took : {} ms httpStatus {} Response {}", Date.now() - restStartTime, httpStatus, response);
        if (exception) {
            self.sfLogger.error("[REST-AUTH-FWK][POST] Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorName + ", got response " + response + ", exception " + exception;
        } else if (httpStatus != 200 && httpStatus != 201) {
            result.msg = "Failed deployment to " + this.mediatorName + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorName + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};


