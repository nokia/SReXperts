var ThreadLocal = Java.type('java.lang.ThreadLocal');
var HashMap = Java.type('java.util.HashMap');
var HashSet = Java.type('java.util.HashSet');
var requestScope = new ThreadLocal();

load({script: resourceProvider.getResource('sf-logger.js'), name: 'ServiceFulfillmentLogger'});
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk'});
load({script: resourceProvider.getResource('nfmp-mapper.js'), name: 'nfmp-mapper'});
load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
load({script: resourceProvider.getResource('sf-utils.js'), name: 'util-fwk'});
load({script: resourceProvider.getResource('svc-oper-model-fwk.js'), name: 'oper-model-fwk'});
load({script: resourceProvider.getResource('resource-reservation-fwk.js'), name: 'resource-reservation-fwk'});
load({script: resourceProvider.getResource('job-manager-fwk.js'), name: 'nsp-job-manager-fwk'});
load({script: resourceProvider.getResource('approved-misalignment.js'), name: 'ApprovedMisAlignmentFWK'});

var approvedMisAlignmentFWK = new ApprovedMisAlignmentFWK();

function IBSFIntentHelper() {
    this.extensionConfig = null;
}

IBSFIntentHelper.prototype.extensionConfig = null;
IBSFIntentHelper.prototype.sfLogger = new ServiceFulfillmentLogger();
IBSFIntentHelper.prototype.nspRestconfFwk = new NspRestconfFwk();
IBSFIntentHelper.prototype.nfmpMapper = new NfmpMapper();
IBSFIntentHelper.prototype.sfUtils = new ServiceFulfillmentIntentUtils();
IBSFIntentHelper.prototype.amiMapper = null;
IBSFIntentHelper.prototype.svcOperModelFwk = new ServiceOperationModelFwk();
IBSFIntentHelper.prototype.input = null;

/*
   function: getServiceId
    since: NSP 22.6
    short_description: get serviceID from requestContext
    input:
        requestContext:
          description: Thread local attribute map for each intent instance.
          type: HashMap
          mandatory: True
    output:
      serviceId:
        type: Integer
        description: service ID that is used by NSP Operational Service Model.
 */
IBSFIntentHelper.prototype.getServiceId = function (requestContext) {
    return requestContext.get("target");
};

/*
   function: setRequestContext
    since: NSP 22.6
    short_description: get serviceID from requestContext
    input:
        input:
          description: This object contains information about action input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: SynchronizeInput/AuditInput/ActionInput
          mandatory: True
    output:
      requestContext:
        type: HashMap
        description: Thread local attribute map for each intent instance.
    examples:
      "getServiceId": |
        let lServiceId = svcIntentHelperFwk.getServiceId(requestContext);
 */
IBSFIntentHelper.prototype.setRequestContext = function (input) {
    let requestContext = new HashMap();
    requestScope.set(requestContext);

    requestContext.put("sync-input", input);
    requestContext.put("target", input.getTarget());
    requestContext.put("networkState", input.getNetworkState().name());

    let topo = input.getCurrentTopology();
    if (topo === null) {
        logger.info("Creating topology");
        topo = topologyFactory.createServiceTopology();
        requestContext.put("isCreate", true);
    } else {
        requestContext.put("isCreate", false);
    }
    requestContext.put("currentTopology", topo);

    let deviceIdList = [];
    let topoList = topo.getTopologyObjects();
    for (let index = 0; index < topoList.length; index++) {
        let deviceId = topoList[index].getObjectDeviceName();
        if (deviceIdList.indexOf(deviceId) === -1) {
            deviceIdList.push(deviceId);
        }
    }
    logger.info("topologyDeviceList - {}", JSON.stringify(deviceIdList));
    requestContext.put("topologyDeviceList", deviceIdList);
    try {
        let lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        let lJson = lConfig[Object.keys(lConfig)[0]];
        requestContext.put("intentConfigJson", lJson);
    } catch (e) {
        requestContext.put("intentConfigJson", {});
        logger.error(e);
    }

    requestContext.put("intentConfigXml", input.getIntentConfiguration());

    this.extensionConfig.setIntentTypeVariable(requestContext);
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    requestContext.put("sfLogger", sfLogger);

    return requestContext;

};

/*
   function: rpcAction
    since: NSP 21.11
    short_description: execute execute-lifecycle-state-change RPC defined in reference-action-intent.yang
    input:
        input:
          description: This object contains information about action input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: ActionInput
          mandatory: True
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: False
    output:
      rpcResults:
        type: String
        description: Always <ok/> or use utilityService.buildOkActionResponse() to generate success string
    output_on_error:
      rpcResults:
        type: String
        description: on error utilityService.buildErrorActionResponse("someString") is used to generate error.
     examples:
      "rpcAction": |
        return svcIntentHelperFwk.rpcAction(input);
 */
IBSFIntentHelper.prototype.rpcAction = function (input, requestContext) {
    this.input = input;
    let startTime = Date.now();
    if (!requestContext){
        requestScope = new ThreadLocal();
        requestContext = this.setRequestContext(input);
        this.extensionConfig.setSiteAndServiceObj(requestContext);
    }
    this.rpcSetStatesAndTemplate(input, requestContext);
    let actionResult = utilityService.buildOkActionResponse();
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));

    sfLogger.debug("[rpcAction] requestContext {}", requestContext);

    if (requestContext.get("rpcToState") === "saved") {
        if (requestContext.get("rpcFromState") === "planned" || requestContext.get("rpcFromState") === "planned-failed" || requestContext.get("rpcFromState") === "removed") {
            let nspFwk = new MediatorFramework("NSP");
            let unbookresponse = nspFwk.delete(this.nspRestconfFwk.constructURL("/restconf/data/nsp-service:unreserve-resource/" + requestContext.get("intentType")
                + "_" + encodeURIComponent(requestContext.get("target")), "DELETE"));
            if (unbookresponse.httpStatus !== 201 && unbookresponse.httpStatus !== 204 && unbookresponse.httpStatus !== 200) {
                return utilityService.buildErrorActionResponse(this.sfUtils.parseError(JSON.parse(unbookresponse["response"])));
            }
            if (requestContext.get("isAssociatedWithComposite")) {
                if (typeof this.patchSlcState === "function") {
                    this.patchSlcState(requestContext);
                }
            }
        } else
            this.svcOperModelFwk.create(requestContext);
    } else if ((requestContext.get("rpcToState") === "planned" || requestContext.get("rpcToState") === "deployed-modified") && requestContext.get("svcType").indexOf("tunnel") === -1) {
        let nspFwk = new MediatorFramework("NSP");
        let resourceReservationPayload = {
            "ne-rsrc-type": [],
            "rt": [],
            "svc-type": requestContext.get("svcType"),
            "owner": requestContext.get("intentType") + "_" + requestContext.get("target"),
            "bf-svc": requestContext.get("rpcBfSvc")
        };

        if (requestContext.get("rpcBfSvc") && typeof this.nfmpMapper.updateVcType === "function") {
            this.nfmpMapper.updateVcType(requestContext.get("svcType"), requestContext.get("target"), requestContext.get("svcObjMap")["vc-type"])
        }
        for (var device in requestContext.get("siteObjMap")) {
            let neResource = null;
            for (var j = 0; j < requestContext.get("siteObjMap")[device].length; j++) {
                let lNeSvcId = requestContext.get("svcObjMap")["ne-service-id"];
                if (!lNeSvcId && requestContext.get("siteObjMap")[device][j]["ne-service-id"])
                    lNeSvcId = requestContext.get("siteObjMap")[device][j]["ne-service-id"];
                requestContext.put("resourceReservationFwk", new ResourceReservationFwk(device, requestContext.get("siteObjMap")[device][j], requestContext.get("svcType"), lNeSvcId));
                let lNePayload = JSON.parse(JSON.stringify(requestContext.get("resourceReservationFwk").nePayload(requestContext)));
                if (!neResource){
                    //first site on that NE
                    neResource = lNePayload;
                    if (typeof requestContext.get("resourceReservationFwk").rtPayload === "function")
                        resourceReservationPayload["rt"] = resourceReservationPayload["rt"].concat(requestContext.get("resourceReservationFwk").rtPayload(requestContext));
                }
                else { //Multiple sites on same NE
                    neResource["vlan"] = neResource["vlan"].concat(lNePayload["vlan"]);
                    neResource["rd"] = neResource["rd"].concat(lNePayload["rd"]);
                    neResource["vcid"] = neResource["vcid"].concat(lNePayload["vcid"]);
                    if (typeof requestContext.get("resourceReservationFwk").rtPayload === "function")
                        resourceReservationPayload["rt"] = resourceReservationPayload["rt"].concat(requestContext.get("resourceReservationFwk").rtPayload(requestContext));
                }
            }
            resourceReservationPayload["ne-rsrc-type"].push(neResource);
        }
        resourceReservationPayload["rt"] = resourceReservationPayload["rt"].reduce(function (accumulator, current) {
            if (checkIfAlreadyExist(current)) {
                return accumulator
            } else {
                return accumulator.concat([current]);
            }

            function checkIfAlreadyExist(currentVal) {
                return accumulator.some(function (item) {
                    return (item.asnumber === currentVal.asnumber &&
                        item.rttype === currentVal.rttype);
                });
            }
        }, []);
        let response = nspFwk.post(this.nspRestconfFwk.constructURL("/restconf/data/nsp-service:reserve-resource/", "POST"), {"input": resourceReservationPayload});
        if (response.httpStatus !== 201 && response.httpStatus !== 204 && response.httpStatus !== 200) {
            if (typeof this.svcOperModelFwk.planned === "function"){
                requestContext.put("rpcToState", "planned-failed");
                this.svcOperModelFwk.planned(requestContext)
            }
            if (requestContext.get("isAssociatedWithComposite")) {
                if (typeof this.patchSlcState === "function") {
                    requestContext.put("rpcToState", "planned-failed");
                    this.patchSlcState(requestContext);
                }
            }
            return utilityService.buildErrorActionResponse(this.sfUtils.parseError(JSON.parse(response["response"])));
        }
        if (requestContext.get("isAssociatedWithComposite")) {
            if (typeof this.patchSlcState === "function") {
                this.patchSlcState(requestContext);
            }
        }
        if (typeof this.svcOperModelFwk.planned === "function")
            this.svcOperModelFwk.planned(requestContext)

    } else if (requestContext.get("rpcToState") === "deleted") {
        if (requestContext.get("svcType").indexOf("tunnel") === -1) { //tunnel not currently reserving resources
            let nspFwk = new MediatorFramework("NSP");
            let unbookresponse = nspFwk.delete(this.nspRestconfFwk.constructURL("/restconf/data/nsp-service:unreserve-resource/" + requestContext.get("intentType")
                + "_" + encodeURIComponent(requestContext.get("target")), "DELETE"));
            if (unbookresponse.httpStatus !== 201 && unbookresponse.httpStatus !== 204 && unbookresponse.httpStatus !== 200) {
                return utilityService.buildErrorActionResponse(this.sfUtils.parseError(JSON.parse(unbookresponse["response"])));
            }
        }
        let lDelete = this.svcOperModelFwk.deleteSvc(requestContext);
        if (lDelete)
            return utilityService.buildErrorActionResponse(this.sfUtils.parseError(lDelete));

    } else if (requestContext.get("rpcToState") === "deployed" && requestContext.get("rpcFromState") === "deployed") {

        let mdcMapper = requestContext.get("mdcMapper");
        if (!requestContext.get("srServiceType"))
            requestContext.put("srServiceType", "");
        this.populateMediationAndFdn(mdcMapper, "", true, true,{classicSvcType: requestContext.get("srServiceType")} ,requestContext);

        if (typeof this.nfmpMapper.nfmpPostServiceDeploy === "function") {
            this.populateServiceMgrId(requestContext)
            requestContext.put("populateServiceMgrIdSite", this.populateServiceMgrIdSite);
            let postSvcPayload = this.nfmpMapper.nfmpPostServiceDeploy(requestContext.get("siteObjMap"), requestContext.get("svcObjMap"), requestContext.get("svcObjMap")["serviceMgrId"],requestContext);
            if (postSvcPayload && Array.isArray(postSvcPayload)) {
                let self = this;
                postSvcPayload.forEach(function (lMediatorObj) {
                    let mediator = new MediatorFramework(lMediatorObj["name"], sfLogger);

                    if(!requestContext.get("isCreate")) {//resolve site level payload for nfmp (e.g. ospf, isis payload for vprn)
                        sfLogger.debug("Unresolved RPC Deployed to Deployed State payload: {}", JSON.stringify(lMediatorObj["payload"], null, 4));
                        const unresolvedConfig = lMediatorObj["payload"];
                        let resolvedConfig = approvedMisAlignmentFWK.nfmpResolveSynchronize(requestContext.get("intentType"), requestContext.get("target"), device, requestContext.get("svcObjMap")["serviceMgrId"], unresolvedConfig);
                        lMediatorObj["payload"] = resolvedConfig;
                        sfLogger.debug("Resolved RPC Deployed to Deployed State payload: {}", JSON.stringify(lMediatorObj["payload"], null, 4));
                    }

                    let results = mediator.post("/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true", lMediatorObj["payload"]);
                    if (!results.success) {
                        throw new RuntimeException( "NFMP Secondary deployment Failed - " +results["response"]);
                    }
                })

            } else if (postSvcPayload) {

                if(!requestContext.get("isCreate")) {
                    sfLogger.debug("Unresolved RPC Deployed to Deployed State payload: {}", JSON.stringify(postSvcPayload, null, 4));
                    const unresolvedConfig = postSvcPayload;
                    let resolvedConfig = approvedMisAlignmentFWK.nfmpResolveSynchronize(requestContext.get("intentType"), requestContext.get("target"), device, requestContext.get("svcObjMap")["serviceMgrId"], unresolvedConfig);
                    postSvcPayload = resolvedConfig;
                    sfLogger.debug("Resolved RPC Deployed to Deployed State payload: {}", JSON.stringify(postSvcPayload, null, 4));
                } 

                let results = new MediatorFramework("NFMP", sfLogger).post("/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true", postSvcPayload);
                if (!results.success) {
                    return utilityService.buildErrorActionResponse(results["response"]);
                }
            }
        }

        let resyncPayload = {"nsp-admin-resync:input": {"plugin-id": "mdm","network-element": []}};
        let mediatorList = {};
        mediatorList["NSP"] = JSON.parse(JSON.stringify(resyncPayload));
        for (var device in requestContext.get("siteObjMap")) {
            for (var siteArrObj in requestContext.get("siteObjMap")[device]) {
                let templateArgs = {};

                templateArgs = this.sfUtils.objectAssign(templateArgs, requestContext.get("svcObjMap"));
                templateArgs = this.sfUtils.objectAssign(templateArgs, requestContext.get("siteObjMap")[device][siteArrObj]);
                if (requestContext.get("svcObjMap")["@"] && requestContext.get("siteObjMap")[device][siteArrObj]["@"])
                    templateArgs["@"] = this.sfUtils.objectAssign(requestContext.get("svcObjMap")["@"], requestContext.get("siteObjMap")[device][siteArrObj]["@"]);
                
                if (!templateArgs["description"] || (templateArgs["description"] && templateArgs["description"] === "") && requestContext.get("svcObjMap")["description"]) {
                    templateArgs["description"] = requestContext.get("svcObjMap")["description"];
                }
                if (!templateArgs["site-name"] || templateArgs["site-name"] === "") {
                    templateArgs["site-name"] = requestContext.get("target");
                }
                if ((!requestContext.get("svcObjMap")["ne-service-id"]) && templateArgs["ne-service-id"]) {
                    requestContext.get("svcObjMap")["ne-service-id"] = templateArgs["ne-service-id"];
                }

                if (templateArgs["@"] && templateArgs["@"]["typeAndVersionMap"] && templateArgs["@"]["typeAndVersionMap"]["mediation"] === "mdc") {
                    let adjecentDeviceList = JSON.parse(JSON.stringify(Object.keys(requestContext.get("siteObjMap"))));
                    let lDeviceIndex = adjecentDeviceList.indexOf(device);
                    if (lDeviceIndex > -1) {
                        adjecentDeviceList.splice(lDeviceIndex, 1);
                    }
                    templateArgs["@"]["neighborName"] = adjecentDeviceList;
                    let templateMeta = this.sfUtils.getTemplateMappings(device, encodeURIComponent(templateArgs["site-name"]), requestContext.get("intentType"), requestContext.get("intentTypeVersion"), templateArgs["@"]["typeAndVersionMap"]['type'],
                        templateArgs["@"]["typeAndVersionMap"]['version'], {neighborName: adjecentDeviceList[0], classicSvcType: requestContext.get("srServiceType")});
                    if (templateMeta && templateMeta["deviceMapper"] && mdcMapper[templateMeta["deviceMapper"]]) {
                        mdcMapper[templateMeta["deviceMapper"]].sfLogger = sfLogger;
                        if (typeof mdcMapper[templateMeta["deviceMapper"]].postDeploymentResync === "function") {
                            if (templateArgs["@"]["typeAndVersionMap"]['alienMediatorName']){
                                if (!mediatorList[templateArgs["@"]["typeAndVersionMap"]['alienMediatorName']])
                                    mediatorList[templateArgs["@"]["typeAndVersionMap"]['alienMediatorName']] = JSON.parse(JSON.stringify(resyncPayload));
                                mediatorList[templateArgs["@"]["typeAndVersionMap"]['alienMediatorName']]["nsp-admin-resync:input"]["network-element"].push({"ne-id": device, "system-retry":true, "sbi-classes": mdcMapper[templateMeta["deviceMapper"]].
                                    postDeploymentResync(templateArgs, requestContext, device, templateMeta)})
                            } else {
                                mediatorList["NSP"]["nsp-admin-resync:input"]["network-element"].push({"ne-id": device, "system-retry":true, "sbi-classes": mdcMapper[templateMeta["deviceMapper"]].
                                    postDeploymentResync(templateArgs, requestContext, device, templateMeta)})
                            }
                        }
                    }
                }
            }
        }

        Object.keys(mediatorList).forEach(function (mediatorName) {
            if (mediatorList[mediatorName]["nsp-admin-resync:input"]["network-element"].length > 0) {
                let resyncRes = new MediatorFramework(mediatorName.replace("MDC", "NSP"), sfLogger).post(this.nspRestconfFwk.constructURL("/restconf/operations/nsp-admin-resync:trigger-resync"), mediatorList[mediatorName]);
                if (!resyncRes.success)
                    throw new RuntimeException("Post Deployment resync failed : " + resyncRes.response);
            }
        });

        if (resyncPayload["nsp-admin-resync:input"]["network-element"].length > 0) {
            let resyncRes = new MediatorFramework("NSP", sfLogger).post(this.nspRestconfFwk.constructURL("/restconf/operations/nsp-admin-resync:trigger-resync"), resyncPayload);
            if (!resyncRes.success)
                throw new RuntimeException("Post Deployment resync failed : " + resyncRes.response);
        }
    }

    sfLogger.info("RPC From - {} To = {} took {} ms", requestContext.get("rpcFromState"), requestContext.get("rpcToState"), Date.now() - startTime);

    requestScope.remove();
    return actionResult;
};

IBSFIntentHelper.prototype.populateServiceMgrIdSite = function (requestContext, device) {
    let tmpOper = {};
    let operModelSite;
    if (!requestContext.get("operModelSite")) {
        operModelSite = this.nspRestconfFwk.getServiceSite(requestContext.get("svcType"), requestContext.get("target"));
        requestContext.put("operModelSite", operModelSite);
    } else
        operModelSite = requestContext.get("operModelSite");


    operModelSite.forEach(function (lSite) {
        if (lSite["@"] && lSite["@"]["nsp-model:sources"] && lSite["site-id"] && lSite["site-id"] === device) {
            lSite["@"]["nsp-model:sources"].forEach(function (lSource) {
                if (lSource.indexOf("fdn:realm:sam:svc-mgr:service") !== -1) {
                    let lTemSource = lSource.replace("fdn:realm:sam:", "").split(":");
                    if (lTemSource.length >= 3 && lTemSource[2].indexOf("@") === -1) {
                        tmpOper[lSite["site-id"]] = lTemSource[0] + ":" + lTemSource[1] + ":" + lTemSource[2]
                    }
                }
            })
            if (!tmpOper[lSite["site-id"]] && !requestContext.get("audit"))
                throw new RuntimeException("Failed to resolve NFMP site source - " + JSON.stringify(lSite["@"]["nsp-model:sources"]));
        }
    })
    if (!tmpOper[device] && !requestContext.get("audit") && requestContext.get("networkState") !== "delete")
        throw new RuntimeException("Failed to resolve NFMP site serviceMgrId for device " + device);

    return tmpOper[device];
}

IBSFIntentHelper.prototype.populateServiceMgrId = function (requestContext) {
    if (requestContext.get("svcType") !== "composite:composite") {
        let operationalModel = this.nspRestconfFwk.getServiceRootElements(requestContext.get("svcType"), this.getServiceId(requestContext));
        if (operationalModel && operationalModel["id"] && operationalModel["id"] !== "0") {
            if (requestContext.get("intentType") === "tunnel") {
                let lMediation = this.sfUtils.getTypeVersionMediation(requestContext.get("target").split('#')[0]);
                if (lMediation && lMediation["mediation"] && lMediation["mediation"] === "nfmp")
                    requestContext.get("svcObjMap")["serviceMgrId"] = 'serviceTunnel:from-' + requestContext.get("target").split('#')[0] + '-id-' + requestContext.get("target").split('#')[1];
            } else {
                requestContext.get("svcObjMap")["serviceMgrId"] = "svc-mgr:service-" + operationalModel["id"];
            }
        }
    } else {
        let compositeOperationalModel = this.nspRestconfFwk.getServiceRootElements(requestContext.get("svcType"), requestContext.get("target"), "name;services");
        requestContext.get("svcObjMap")["serviceMgrId"] = {};
        if (compositeOperationalModel && compositeOperationalModel["services"]) {
            requestContext.put("compositeChilds", JSON.stringify(compositeOperationalModel["services"]));
            compositeOperationalModel["services"].forEach(function (lChildService) {
                let operationalChild = this.nspRestconfFwk.findByXpath(lChildService, 2);
                if (operationalChild && operationalChild[0] && operationalChild[0]["@"] && operationalChild[0]["@"]["nsp-model:sources"]
                    && operationalChild[0]["@"]["nsp-model:sources"][0] && operationalChild[0]["@"]["nsp-model:sources"][0].indexOf("fdn:realm:sam:svc-mgr") !== -1) {
                    let lServiceTypeFound = operationalChild[0]["@"]["nsp-model:schema-nodeid"].replace("/nsp-service:services/service-layer/", "");
                    requestContext.get("svcObjMap")["serviceMgrId"][lServiceTypeFound+operationalChild[0]["service-id"].replace(compositeOperationalModel["name"],"")] = operationalChild[0]["@"]["nsp-model:sources"][0].replace("fdn:realm:sam:", "");
                }
            })
        }
    }
}

/*
   function: synchronize
    since: NSP 21.11
    short_description: handler to execute synchronize()
    input:
        synchronizeInput:
          description: This object contains information about synchronize input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: SynchronizeInput
          mandatory: True
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: False
    output:
      SynchronizeResult:
        type: SynchronizeResult
        description: This object stores synchronization operation result.
     examples:
      "synchronize": |
        return svcIntentHelperFwk.synchronize(input);
 */
IBSFIntentHelper.prototype.synchronize = function (synchronizeInput, requestContext) {
    this.input = synchronizeInput;
    let startTime = Date.now();
    let deviceIdsCreatedModified = [];
    if (!requestContext){
        requestScope = new ThreadLocal();
        requestContext = this.setRequestContext(synchronizeInput);
        this.extensionConfig.setSiteAndServiceObj(requestContext);
    }
    let preServiceDeployResponse = null;
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    let result = synchronizeResultFactory.createSynchronizeResult();
    result.setSuccess(true)
    
    if(synchronizeInput.getNetworkState().name() === "delete"){
        approvedMisAlignmentFWK.deleteApprovedChanges(requestContext.get("intentType"), requestContext.get("target"));
    }

    let mdcMapper = requestContext.get("mdcMapper");

    // Get Service Manager ID
    this.populateServiceMgrId(requestContext);
    sfLogger.info("isCreate:{} serviceMgrId:{}", requestContext.get("isCreate"),  JSON.stringify(requestContext.get("svcObjMap")["serviceMgrId"]));

    if (requestContext.get("svcObjMap")["customer-id"] && synchronizeInput.getNetworkState().name() !== "delete"){
        let lCustomerNspObj = new NspRestconfFwk(requestContext.get("sfLogger")).findByXpath("/nsp-customer:customers/customer[id='"+requestContext.get("svcObjMap")["customer-id"]+"']",2);
        if (lCustomerNspObj && lCustomerNspObj[0] && lCustomerNspObj[0]["name"]) {
            if (!requestContext.get("svcObjMap")["@"]) requestContext.get("svcObjMap")["@"] = {}
            requestContext.get("svcObjMap")["@"]["customerInfo"] = lCustomerNspObj[0];
        }
    }
    let jobManager = new JobManagerFwk(requestContext, sfLogger, this.nfmpMapper);

    //NFMP Pre Service Deployment - cpipe
    if (typeof this.nfmpMapper.nfmpPreServiceDeploy === "function" && synchronizeInput.getNetworkState().name() !== "delete") {
        let preSvcPayload = this.nfmpMapper.nfmpPreServiceDeploy(requestContext.get("intentType"), requestContext.get("svcType"), requestContext.get("svcObjMap"), requestContext.get("siteObjMap"), requestContext.get("currentTopology"));
        if (preSvcPayload && Object.keys(preSvcPayload).length !== 0) {
            let results = new MediatorFramework("NFMP", sfLogger).post("/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true", preSvcPayload);
            if (results.success) {
                preServiceDeployResponse = JSON.parse(results.response);
            } else
                preServiceDeployResponse = null;
        }
    }
    //Populate fdn and add sites to operational model
    if (!requestContext.get("srServiceType"))
        requestContext.put("srServiceType", "");
    if (synchronizeInput.getNetworkState().name() !== "delete") {
        this.populateMediationAndFdn(mdcMapper, preServiceDeployResponse,false, false, {classicSvcType: requestContext.get("srServiceType")}, requestContext);
        sfLogger.debug("[ServiceFulfillmentIntentHelper] updated  siteObjMap {}", JSON.stringify(requestContext.get("siteObjMap")));
        //this.svcOperModelFwk.updateIntentSiteSvc(requestContext.get("svcObjMap"), requestContext.get("siteObjMap"));
        this.svcOperModelFwk.deployed(requestContext);
    } else {
        this.populateMediationAndFdn(mdcMapper, preServiceDeployResponse, true, false, {classicSvcType: requestContext.get("srServiceType")}, requestContext, true);
    }

    let deviceList = Object.keys(requestContext.get("siteObjMap"));
    for (var device in requestContext.get("siteObjMap")) {
        for (var siteArrObj in requestContext.get("siteObjMap")[device]) {
            let templateArgs = {};

            templateArgs = this.sfUtils.objectAssign(templateArgs, requestContext.get("svcObjMap"));
            templateArgs = this.sfUtils.objectAssign(templateArgs, requestContext.get("siteObjMap")[device][siteArrObj]);
            if (requestContext.get("svcObjMap")["@"] && requestContext.get("siteObjMap")[device][siteArrObj]["@"])
                templateArgs["@"] = this.sfUtils.objectAssign(requestContext.get("svcObjMap")["@"], requestContext.get("siteObjMap")[device][siteArrObj]["@"]);

            if (!templateArgs["description"] || (templateArgs["description"] && templateArgs["description"] === "") && requestContext.get("svcObjMap")["description"]) {
                templateArgs["description"] = requestContext.get("svcObjMap")["description"];
            }

            if (!requestContext.get("siteObjMap")[device][siteArrObj]["mtu"] && requestContext.get("svcObjMap")["mtu"]) {
                requestContext.get("siteObjMap")[device][siteArrObj]["mtu"]  = requestContext.get("svcObjMap")["mtu"];
            }

            if (!templateArgs["site-name"] || (templateArgs["site-name"] && templateArgs["site-name"] === "")) {
                templateArgs["site-name"] = requestContext.get("target");
                requestContext.get("siteObjMap")[device][siteArrObj]["site-name"] = requestContext.get("target");
            }
            if ((!requestContext.get("svcObjMap")["ne-service-id"]) && templateArgs["ne-service-id"]){
                requestContext.get("svcObjMap")["ne-service-id"] = templateArgs["ne-service-id"];
            }

            sfLogger.info("templateArgs : {} ", JSON.stringify(templateArgs));
            if (synchronizeInput.getNetworkState().name() !== "delete" && deviceIdsCreatedModified.indexOf(device) === -1) deviceIdsCreatedModified.push(device);

            if (templateArgs["@"] && templateArgs["@"]["typeAndVersionMap"] && templateArgs["@"]["typeAndVersionMap"]["mediation"] === "nfmp") {
                if (synchronizeInput.getNetworkState().name() !== "delete") {
                    sfLogger.info("NFMP Site deployment starts - " + device);
                    let nfmpSitePayload = this.nfmpMapper.mapToNfmpSite(device, requestContext.get("siteObjMap")[device][siteArrObj], requestContext.get("svcObjMap"), preServiceDeployResponse, requestContext.get("currentTopology"), false, requestContext);
                    let lSvcMgrId = requestContext.get("svcObjMap")["serviceMgrId"];
                    if (templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"])
                        lSvcMgrId = this.populateServiceMgrIdSite(requestContext, device);
                    if (typeof lSvcMgrId === "object" && requestContext.get("svcType") === "composite:composite"){
                        let lIndex = templateArgs["@"]["serviceType"] + "_" + templateArgs["site-name"];
                        lSvcMgrId = lSvcMgrId[lIndex]
                    }
                    sfLogger.info("NFMP Site lSvcMgrId : {}", JSON.stringify(lSvcMgrId));

                    if(!requestContext.get("isCreate")){//resolve site level payload for nfmp
                        sfLogger.debug("nfmpSitePayload: {}", JSON.stringify(nfmpSitePayload, null, 4));
                        const unresolvedConfig = nfmpSitePayload;
                        let resolvedConfig = approvedMisAlignmentFWK.nfmpResolveSynchronize(requestContext.get("intentType"), requestContext.get("target"), device, lSvcMgrId, unresolvedConfig);
                        nfmpSitePayload = resolvedConfig;
                        sfLogger.debug("resolved nfmpSitePayload: {}", JSON.stringify(nfmpSitePayload, null, 4));
                    }
                    if (templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"]) { //HCO
                        if (!requestContext.get("svcObjMap")["nfmpAlienMediatorList"]){
                            requestContext.get("svcObjMap")["nfmpAlienMediatorList"] = [];
                        }
                        requestContext.get("svcObjMap")["nfmpAlienMediatorList"].push(templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"])
                    }

                    jobManager.appendNFMPSitePayload(nfmpSitePayload, lSvcMgrId, device, templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"], requestContext);
                } else if (templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"]) { //HCO - delete alien NSP sites
                    let lSvcMgrId = this.populateServiceMgrIdSite(requestContext, device);
                    if (lSvcMgrId)
                        jobManager.nfmpDeleteTask(null, lSvcMgrId, templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"]);
                }
            } else if (templateArgs["@"] && templateArgs["@"]["typeAndVersionMap"]
                && (templateArgs["@"]["typeAndVersionMap"]["mediation"] === "mdc" || templateArgs["@"]["typeAndVersionMap"]["mediation"] === "mdm-ami")) {
                if (typeof  AmiMapper === "function")
                    this.amiMapper = new AmiMapper(sfLogger);
                let adjecentDeviceList = JSON.parse(JSON.stringify(deviceList));
                let lDeviceIndex = adjecentDeviceList.indexOf(device);
                if (lDeviceIndex > -1) {
                    adjecentDeviceList.splice(lDeviceIndex, 1);
                }
                templateArgs["@"]["neighborName"] = adjecentDeviceList;

                let templateMeta = this.sfUtils.getTemplateMappings(device, requestContext.get("target"), requestContext.get("intentType"), requestContext.get("intentTypeVersion"), templateArgs["@"]["typeAndVersionMap"]['type'],
                    templateArgs["@"]["typeAndVersionMap"]['version'], {neighborName: adjecentDeviceList[0], classicSvcType: requestContext.get("srServiceType")});
                if (templateMeta && templateMeta["deviceMapper"] && mdcMapper[templateMeta["deviceMapper"]]) {
                    mdcMapper[templateMeta["deviceMapper"]].sfLogger = sfLogger; //Cut through/MDC Adp Deployment
                    let targetUrl = templateMeta['serviceRoot'];
                    let yangPatchJson = {};
                    let removeEmpty = null;
                    if (typeof mdcMapper[templateMeta["deviceMapper"]].removeEmpty === "function") {
                        removeEmpty = mdcMapper[templateMeta["deviceMapper"]].removeEmpty();
                    }
                    if (synchronizeInput.getNetworkState().name() === "delete") {
                        yangPatchJson = mdcMapper[templateMeta["deviceMapper"]].yangPatchDelete(this.sfUtils.cleanEmtyObjects(templateArgs), encodeURIComponent(templateArgs["site-name"]), {neighborName: adjecentDeviceList}, device, requestContext, templateMeta);
                    } else {
                        yangPatchJson = mdcMapper[templateMeta["deviceMapper"]].yangPatchPayload(this.sfUtils.cleanEmtyObjects(templateArgs, removeEmpty), encodeURIComponent(templateArgs["site-name"]), {neighborName: adjecentDeviceList}, device, requestContext, templateMeta);
                    }

                    if(!requestContext.get("isCreate") && !templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"]){
                        const rootXPath = targetUrl.replace("https://restconf-gateway:443/restconf/data/nsp-network:network/node="+device+"/node-root", "").split("?")[0];
                        for (let i = 0; i < yangPatchJson["ietf-yang-patch:yang-patch"]["edit"].length; i++) {
                            if(yangPatchJson["ietf-yang-patch:yang-patch"]["edit"][i].hasOwnProperty("value")) {
                                const unresolvedConfig = yangPatchJson["ietf-yang-patch:yang-patch"]["edit"][i]["value"]
                                const unresolvedConfigTarget = yangPatchJson["ietf-yang-patch:yang-patch"]["edit"][i]["target"]
                                let resolvedConfig = approvedMisAlignmentFWK.resolveSynchronize(requestContext.get("intentType"), requestContext.get("target"), device, rootXPath+unresolvedConfigTarget, unresolvedConfig);
                                yangPatchJson["ietf-yang-patch:yang-patch"]["edit"][i]["value"] = resolvedConfig;
                            }
                        }
                    }
                
                    jobManager.mdmYangPatchTask(device, targetUrl, yangPatchJson, null, templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"]);
                } else if (!this.amiMapper) {
                    throw new RuntimeException("Did not find any MDC device mapping or AMI mapping for  " + device);
                } else { //AMI Deployment
                    if (synchronizeInput.getNetworkState().name() === "delete") {
                        if (typeof this.amiMapper.getDeleteUrl === "function")
                        {
                            let ldelUrl = this.amiMapper.getDeleteUrl(device, requestContext.get("target"), requestContext.get("intentType"), requestContext.get("intentTypeVersion"));
                            if (ldelUrl !== null && ldelUrl !== "undefined") {
                                jobManager.mdmDeleteTask(device, ldelUrl);
                            }
                        }
                    } else {
                        if (typeof this.amiMapper.mapToAmiModel === "function") {
                            let amiPayload = this.amiMapper.mapToAmiModel(templateArgs, device);
                            jobManager.mdmPostTask(device, this.amiMapper.getDeployUrl(device, requestContext.get("target"), requestContext.get("intentType"), requestContext.get("intentTypeVersion")), amiPayload);
                        }
                    }
                }
            } else if (synchronizeInput.getNetworkState().name() !== "delete") {
                throw new RuntimeException("Did not figure-out mediation - Something went wrong");
            }
        }
    }


    if (synchronizeInput.getNetworkState().name() === "delete"){
        //delete NFMP service
        let deleteNfmpDeploy = {
            "preDeleteFdn": [],
            "postDeleteFdn": []
        };
        if(requestContext.get("svcObjMap")["serviceMgrId"] && requestContext.get("svcObjMap")["serviceMgrId"] !== "undefined" && requestContext.get("svcObjMap")["serviceMgrId"]  != "-1"){
            if (typeof this.nfmpMapper.prePostServiceDeleteFdn === "function") {
                this.nfmpMapper.prePostServiceDeleteFdn(requestContext.get("siteObjMap"), requestContext.get("svcObjMap"), deleteNfmpDeploy, requestContext.get("currentTopology"), requestContext.get("svcObjMap")["serviceMgrId"]);
            }
            //pre service delete
            sfLogger.info("deleteNfmpDeploy:{}", JSON.stringify(deleteNfmpDeploy));

            if (typeof this.nfmpMapper.preServiceDelete === "function") {
                this.nfmpMapper.preServiceDelete(requestContext, new MediatorFramework("NFMP", sfLogger));
            }

            if (typeof requestContext.get("svcObjMap")["serviceMgrId"] === "object"){ //composite
                jobManager.nfmpDeleteTask(deleteNfmpDeploy, null)
            } else {
                jobManager.nfmpDeleteTask(deleteNfmpDeploy, requestContext.get("svcObjMap")["serviceMgrId"])
            }
        }
    } else {
        //Generate create/modify service payload
        jobManager.nfmpTask(preServiceDeployResponse, requestContext);

        if(!requestContext.get("isCreate")) {
            for(let i = 0; i < jobManager.managedTasks.length; i++) {
                let managedTask = jobManager.managedTasks[i];

                if (managedTask.hasOwnProperty("meta")) {
                    let meta = JSON.parse(managedTask["meta"]);

                    if(meta["mediation"] == "NFMP" && managedTask["order"] == 1) {//resolve service level payload for nfmp
                        let resolvedSvcPayload = approvedMisAlignmentFWK.nfmpResolveSynchronize(requestContext.get("intentType"), requestContext.get("target"), undefined, undefined, managedTask["payload"]);
                        managedTask["payload"] = JSON.stringify(resolvedSvcPayload);
                        jobManager.managedTasks[i] = managedTask;
                    }  
                }
            }
        }

        if (this.nfmpMapper.nfmpSecondaryDeploy && typeof this.nfmpMapper.nfmpSecondaryDeploy === "function"){
            let nfmpSecPayload = this.nfmpMapper.nfmpSecondaryDeploy(requestContext.get("intentType"), requestContext.get("svcType"), requestContext.get("svcObjMap"), requestContext.get("siteObjMap"));
            if (nfmpSecPayload && Object.keys(nfmpSecPayload).length !== 0)
                jobManager.nfmpSecondaryTask(nfmpSecPayload)
        }
    }

    if (synchronizeInput.getNetworkState().name() !== "delete") {
        this.checkSitesOnSync(requestContext, jobManager, JSON.parse(JSON.stringify(deviceIdsCreatedModified)));
    }

    if (!requestContext.get("ignoreSend"))
        jobManager.send();
    else
        requestContext.put("jobManager", jobManager);

    if (synchronizeInput.getNetworkState().name() === "delete") {
        //Update the SLC state of composite child services
        if (requestContext.get("isAssociatedWithComposite")) {
            if (typeof this.patchSlcState === "function") {
                this.patchSlcState(requestContext, "removed");
            }
        }
        if (typeof this.svcOperModelFwk.removed === "function")
            this.svcOperModelFwk.removed(requestContext)
    }

    //update cPipe Channel info to Topo
    if (typeof this.nfmpMapper.nfmpChannelInfoInTopo === "function" && synchronizeInput.getNetworkState().name() !== "delete") {
        let postSvcPayload = this.nfmpMapper.nfmpChannelInfoInTopo(requestContext.get("intentType"), requestContext.get("svcType"), requestContext.get("svcObjMap"), requestContext.get("siteObjMap"), requestContext.get("currentTopology"));
        if (postSvcPayload && Object.keys(postSvcPayload).length !== 0) {
            let results = new MediatorFramework("NFMP", sfLogger).post("/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true", postSvcPayload);
            if (!results.success) {
                return utilityService.buildErrorActionResponse(results["response"]);
            }
        }
    }

    result.setTopology(this.copyTopoObjects(deviceIdsCreatedModified, requestContext));
    requestScope.remove();
    sfLogger.info("synchronize took {} ms", Date.now() - startTime);
    return result;
};

/*
   function: setExtensionConfig
    since: NSP 22.6
    short_description: Set function for extensionConfig.
    input:
        inputConfig:
          description: this object should contain setIntentTypeVariable and setSiteAndServiceObj functions
          type: Object
          mandatory: True
    examples:
      "setExtensionConfig": |
        let extensionConfigObject = {
            setIntentTypeVariable: function (requestContext) {
                requestContext.put("intentType", intentTypeName);
                requestContext.put("intentTypeVersion", sfUtils.getIntentTypeVersion(intentTypeName, requestContext.get("target")));
                requestContext.put("svcType", svcType);
                requestContext.put("mdcMapper", {
                    "srDeviceMapper": new SrDeviceMapper(svcIntentHelperFwk.sfLogger)
                });
                requestScope.set(requestContext);
            },

            setSiteAndServiceObj: function (requestContext) {
                svcIntentHelperFwk.transformSvcObj({"site-details": ""}, requestContext);
                svcIntentHelperFwk.transformSiteObj("", requestContext);
                svcIntentHelperFwk.populateSdpSite(null, requestContext);
            }
        };
        svcIntentHelperFwk.setExtensionConfig(extensionConfigObject);
 */
IBSFIntentHelper.prototype.setExtensionConfig = function (inputConfig) {
    this.extensionConfig = inputConfig;
};

/*
   function: rpcSetStatesAndTemplate
    since: NSP 22.6
    short_description: Extract values passed in from RPC and store in requestContext
    input:
        input:
          description: This object contains information about action input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: ActionInput
          mandatory: True
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: True
    examples:
      "rpcSetStatesAndTemplate": |
         this.rpcSetStatesAndTemplate(input, requestContext);
 */
IBSFIntentHelper.prototype.rpcSetStatesAndTemplate = function (input, requestContext) {
    if (!requestContext)
        requestContext = requestScope.get();
    let rootChildren = input.getActionTreeElement().getChildNodes();
    for (var i = 0; i < rootChildren.getLength(); i++) {
        let child = rootChildren.item(i);
        if (child.getLocalName() == "to-state")
            requestContext.put("rpcToState", child.getTextContent());
        if (child.getLocalName() == "from-state")
            requestContext.put("rpcFromState", child.getTextContent());
        if (child.getLocalName() == "template-name")
            requestContext.put("rpcTemplateName", child.getTextContent());
        if (child.getLocalName() == "bf-svc")
            requestContext.put("rpcBfSvc", child.getTextContent());
    }
    requestContext.get("sfLogger").info("executeStateAction toState : " + requestContext.get("rpcToState") + "  fromState: " + requestContext.get("rpcFromState") + " templateName: "
        + requestContext.get("rpcTemplateName") + "bfSvc: " + requestContext.get("rpcBfSvc"));
};

/*
   function: transformSvcObj
    since: NSP 22.6
    short_description: Extract service level property.
    description:
        - Ignore list will contain intent site definition
        - Extract all other properties not in ignore list and store as service objects.
        - this function can be called from extensionConfigObject(script-content.js) setSiteAndServiceObj function
    input:
        ignoreList:
          description: Properties to be ignored. Site level properties can be passed in here.
          type: Object
          mandatory: True
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
    examples:
      "transformSvcObj": |
         setSiteAndServiceObj: function (requestContext) {
            svcIntentHelperFwk.transformSvcObj({"site-details": ""}, requestContext);
            svcIntentHelperFwk.transformSiteObj("", requestContext);
            svcIntentHelperFwk.populateSdpSite(null, requestContext);
         }
 */
IBSFIntentHelper.prototype.transformSvcObj = function transformSvcObj(ignoreList, requestContext) {
    if (!requestContext)
        requestContext = requestScope.get();
    let lSvcObjMap;
    let sfLogger = requestContext.get("sfLogger");
    try {
        lSvcObjMap = JSON.parse(JSON.stringify(requestContext.get("intentConfigJson")));
        for (var key in lSvcObjMap) {
            if (ignoreList.hasOwnProperty(key)) {
                sfLogger.debug("[MDT-SVC-FWK] transformSvcObj ignoring {}", key);
                delete lSvcObjMap[key];
            }
        }
    } catch (e) {
        sfLogger.error("[SvcFwk] transformSvcObj {}", e.message);
        throw new RuntimeException(e.message);
    }

    if (!lSvcObjMap["service-name"]) lSvcObjMap["service-name"] = requestContext.get("target");

    requestContext.put("svcObjMap", lSvcObjMap);
    sfLogger.info("[MDT-SVC-FWK] transformSvcObj post svcItem = {}", JSON.stringify(requestContext.get("svcObjMap")));
};

/*
   function: transformSiteObj
    since: NSP 22.6
    short_description: Extract site level property.
    description:
        - Extract all properties passed in siteKey and store as site level properties.
        - this function can be called from extensionConfigObject(script-content.js) setSiteAndServiceObj function
    input:
        siteKey:
          description: parent object for Site level property
          type: Object
          mandatory: True
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
        appendToSite:
          type: Object
          description: Additional objects appended to siteMap.
          mandatory: True
    examples:
      "transformSiteObj": |
        setSiteAndServiceObj: function (requestContext) {
            svcIntentHelperFwk.transformSvcObj({"site-details": ""}, requestContext);
            svcIntentHelperFwk.transformSiteObj("", requestContext);
            svcIntentHelperFwk.populateSdpSite(null, requestContext);
        }
 */
IBSFIntentHelper.prototype.transformSiteObj = function (siteKey, requestContext, appendToSite) {
    if (!requestContext)
        requestContext = requestScope.get();
    if (siteKey === undefined || siteKey === null || siteKey === "") {
        siteKey = "site-details"
    }
    let lSiteObjMap = {};
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    if (requestContext.get("siteObjMap") && Object.keys(requestContext.get("siteObjMap")).length !== 0) {
        lSiteObjMap = requestContext.get("siteObjMap");
    }
    try {
        let svcItem = JSON.parse(JSON.stringify(requestContext.get("intentConfigJson")));
        for (var key in svcItem) {
            if (key === siteKey) {
                if (svcItem[key]["site"] && Array.isArray(svcItem[key]["site"])) {
                    let self = this;
                    svcItem[key]["site"].forEach(function (site) {
                        if (!lSiteObjMap[site["device-id"]]) {
                            lSiteObjMap[site["device-id"]] = [];
                        }
                        if (appendToSite)
                            site = self.sfUtils.objectAssign(appendToSite, site);
                        lSiteObjMap[site["device-id"]].push(JSON.parse(JSON.stringify(site)));
                    })
                } else if (svcItem[siteKey] && svcItem[siteKey]["device-id"]) {
                    if (!lSiteObjMap[svcItem[siteKey]["device-id"]]) {
                        lSiteObjMap[svcItem[siteKey]["device-id"]] = [];
                    }
                    if (appendToSite)
                        svcItem[siteKey] = self.sfUtils.objectAssign(appendToSite, svcItem[siteKey]);
                    lSiteObjMap[svcItem[siteKey]["device-id"]].push(svcItem[siteKey]);
                }
            }
        }
    } catch (e) {
        sfLogger.error("[SvcFwk] transformSiteObj " + e.message);
        throw new RuntimeException(e.message);
    }
    requestContext.put("siteObjMap", lSiteObjMap);
    sfLogger.info("[MDT-SVC-FWK] transformSiteObj nodalArgsMap = " + JSON.stringify(requestContext.get("siteObjMap")));
};

/*
   function: populateSdpSite
    since: NSP 22.6
    short_description: Extract SDP from service level and append to site config.
    description:
        - Extract SDP properties stored in service level and append to appropriate site
        - this function can be called from extensionConfigObject(script-content.js) setSiteAndServiceObj function
    input:
        serviceId:
          description: Service ID. If explicit vcid is not present, then service id will be used
          type: String
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
    examples:
      "populateSdpSite": |
        setSiteAndServiceObj: function (requestContext) {
            svcIntentHelperFwk.transformSvcObj({"site-details": ""}, requestContext);
            svcIntentHelperFwk.transformSiteObj("", requestContext);
            svcIntentHelperFwk.populateSdpSite(null, requestContext);
        }
 */
IBSFIntentHelper.prototype.populateSdpSite = function (serviceId, requestContext) {
    if (!requestContext) {
        requestContext = requestScope.get();
        if (!requestContext)
            requestContext = this.setRequestContext(this.input);
    }
    if (requestContext.get("svcObjMap") && requestContext.get("svcObjMap")["sdp-details"] && requestContext.get("svcObjMap")["sdp-details"]["sdp"]) {
        let lSiteObjMap = requestContext.get("siteObjMap");
        for (var j = requestContext.get("svcObjMap")["sdp-details"]["sdp"].length - 1; j >= 0; j--) {
            let sdpInfo = requestContext.get("svcObjMap")["sdp-details"]["sdp"][j];
            let sourceSite = sdpInfo["source-device-id"];
            if (!Array.isArray(lSiteObjMap[sourceSite])) {
                lSiteObjMap[sourceSite] = [];
                lSiteObjMap[sourceSite][0] = {};
            }
            if (!Array.isArray(lSiteObjMap[sourceSite][0]["sdp"])) {
                lSiteObjMap[sourceSite][0]["sdp"] = [];
            }

            if (serviceId && !sdpInfo["vc-id"]) {
                sdpInfo["vc-id"] = serviceId;
            }

            lSiteObjMap[sourceSite][0]["sdp"].push(sdpInfo);
        }
        delete lSiteObjMap["sdp-details"];
        requestContext.put("siteObjMap", lSiteObjMap);
        requestContext.get("sfLogger").info("[MDT-SVC-FWK] populateSdpSite siteObjMap = " + JSON.stringify(requestContext.get("siteObjMap")));
    }

};

/*
   function: populateMediationAndFdn
    since: NSP 22.6
    short_description: helper function to generate sources for NFMP and MDM
    input:
        mdcMapper:
          type: Object
          description: List of MDM device class
          mandatory: True
        preServiceDeployResponse:
          type: Object
          description: response of pre deployment if exits
          mandatory: False
        ignoreFdn:
          type: Boolean
          description: Only populate mediation layer for NE
          mandatory: False
        ignoreSvcMgrId:
          type: Boolean
          description: For NFMP managed nodes, ignore generate next free serviceManagerId from resource manager
          mandatory: False
        extraParams:
          type: Object
          description: If any extra objects needs to be passed in
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
    examples:
      "populateMediationAndFdn": |
        this.populateMediationAndFdn(mdcMapper, preServiceDeployResponse,false, false, {classicSvcType: classicServiceType}, requestContext);
 */
IBSFIntentHelper.prototype.populateMediationAndFdn = function (mdcMapper, preServiceDeployResponse, ignoreFdn, ignoreSvcMgrId, extraParams, requestContext, isSvcDelete) {
    if (!requestContext)
        requestContext = requestScope.get();
    let lSiteObjMap = requestContext.get("siteObjMap");
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    for (var device in lSiteObjMap) {
        for (var siteArrObj in lSiteObjMap[device]) {
            if (typeof  AmiMapper === "function")
                this.amiMapper = new AmiMapper(sfLogger);
            let typeVersionMap = null;
            if (isSvcDelete) {
                try {
                    typeVersionMap = this.sfUtils.getTypeVersionMediation(device);
                } catch (e) {
                    sfLogger.error(e);
                }
            } else {
                typeVersionMap = this.sfUtils.getTypeVersionMediation(device);
            }
            if (typeVersionMap) {
                if (!Array.isArray(lSiteObjMap[device])) {
                    throw new RuntimeException('[SVC-FWK] siteObjMap[device] is not array. siteObjMap should be in format {"ne-id":[{}]} siteObjMap: ' + JSON.stringify(lSiteObjMap));
                }
                if (!lSiteObjMap[device][siteArrObj]["@"]) {
                    lSiteObjMap[device][siteArrObj]["@"] = {}
                }
                if (!lSiteObjMap[device][siteArrObj]["site-name"]) {
                    lSiteObjMap[device][siteArrObj]["site-name"] = requestContext.get("target");
                }
                lSiteObjMap[device][siteArrObj]["@"]["typeAndVersionMap"] = typeVersionMap;
                lSiteObjMap[device][siteArrObj]["mediationType"] = typeVersionMap["mediation"];
                sfLogger.info("populateMediationAndFdn typeVersionMap = " + JSON.stringify(typeVersionMap));

                if (typeVersionMap["mediation"] === "nfmp") {
                    if (!ignoreSvcMgrId && Object.keys(requestContext.get("svcObjMap")).length !== 0 && requestContext.get("svcType") === "composite:composite") {
                        let lIndex = lSiteObjMap[device][siteArrObj]["@"]["serviceType"] + "_" + lSiteObjMap[device][siteArrObj]["site-name"];
                        if (typeof requestContext.get("svcObjMap")["serviceMgrId"] === "object" && !requestContext.get("svcObjMap")["serviceMgrId"][lIndex]) {
                            requestContext.get("svcObjMap")["serviceMgrId"][lIndex] = "svc-mgr:service-" + this.nspRestconfFwk.getNextSvcMgrId();
                        }
                    } else if (!ignoreSvcMgrId && Object.keys(requestContext.get("svcObjMap")).length !== 0 && (!requestContext.get("svcObjMap")["serviceMgrId"] || requestContext.get("svcObjMap")["serviceMgrId"] == "-1")) {
                        requestContext.get("svcObjMap")["serviceMgrId"] = "svc-mgr:service-" + this.nspRestconfFwk.getNextSvcMgrId();
                    }
                    if (!ignoreFdn && typeof this.nfmpMapper.populateSources === "function")
                        this.nfmpMapper.populateSources(requestContext.get("svcObjMap"), lSiteObjMap[device][siteArrObj], device, preServiceDeployResponse, requestContext.get("currentTopology"), requestContext.get("target"), requestContext.get("intentType"), requestContext);
                } else { // MDM
                    let lExtraParams = {};
                    if (extraParams !== undefined) {
                        lExtraParams = extraParams;
                    }
                    let templateMeta = this.sfUtils.getTemplateMappings(device, lSiteObjMap[device][siteArrObj]["site-name"], requestContext.get("intentType"), requestContext.get("intentTypeVersion"), typeVersionMap['type'],
                        typeVersionMap['version'], lExtraParams);
                    if (!ignoreFdn) {
                        if (templateMeta && templateMeta["deviceMapper"] && mdcMapper[templateMeta["deviceMapper"]]) {
                            mdcMapper[templateMeta["deviceMapper"]].sfLogger = sfLogger; //MDC
                            mdcMapper[templateMeta["deviceMapper"]].populateSources(requestContext.get("svcObjMap"), device, lSiteObjMap[device][siteArrObj], requestContext.get("currentTopology"), requestContext.get("target"), requestContext.get("intentType"), requestContext, templateMeta);
                        } else if (this.amiMapper)
                            this.amiMapper.populateSources(requestContext.get("svcObjMap"), device, lSiteObjMap[device][siteArrObj], requestContext.get("currentTopology"), requestContext.get("target"), requestContext.get("intentType"), requestContext, templateMeta);
                        else
                            throw new RuntimeException("Cannot resolve intent mapper for device " + device);
                    }

                }
            }
        }
    }
    requestContext.put("siteObjMap", lSiteObjMap);
};

/*
   function: audit
    since: NSP 21.11
    short_description: handler to execute audit()
    input:
        auditInput:
          description: This object contains information about audit input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: AuditInput
          mandatory: True
        auditReport:
           type: AuditReport
           description: Pass audit report if its needs to be appended, instead of new report
           mandatory: False
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: False
    output:
      AuditReport:
        type: AuditReport
        description: This object contains information about misaligned attributes and misaligned objects along with error code and error details.
     examples:
      "audit": |
        return svcIntentHelperFwk.audit(input);
 */
IBSFIntentHelper.prototype.audit = function (input, auditReport, requestContext) {
    this.input = input;
    let startTime = Date.now();
    if (!requestContext){
        requestScope = new ThreadLocal();
        requestContext = this.setRequestContext(input);
        this.extensionConfig.setSiteAndServiceObj(requestContext);
    }
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    if (!auditReport)
        auditReport = auditFactory.createAuditReport(requestContext.get("intentType"), requestContext.get("target"));

    requestContext.put("audit",true);

    let mdcMapper = requestContext.get("mdcMapper");

    let nfmpSitePayload = {};
    let foundAlienNfmp = [];
    let foundLocalNfmp = false;

    this.populateServiceMgrId(requestContext);
    let lSvcMgrId = requestContext.get("svcObjMap")["serviceMgrId"];
    sfLogger.info("Audit serviceMgrId : " + requestContext.get("svcObjMap")["serviceMgrId"]);
    if (!requestContext.get("srServiceType"))
        requestContext.put("srServiceType", "");
    this.populateMediationAndFdn(requestContext.get("mdcMapper"), "", true, true, {classicSvcType: requestContext.get("srServiceType")}, requestContext);
    let deviceList = Object.keys(requestContext.get("siteObjMap"));
    if (requestContext.get("svcObjMap")["customer-id"] && requestContext.get("svcObjMap")["customer-id"]  !== 1){
        let lCustomerNspObj = new NspRestconfFwk(requestContext.get("sfLogger")).findByXpath("/nsp-customer:customers/customer[id='"+requestContext.get("svcObjMap")["customer-id"]+"']",2);
        if (lCustomerNspObj && lCustomerNspObj[0] && lCustomerNspObj[0]["name"]) {
            if (!requestContext.get("svcObjMap")["@"]) requestContext.get("svcObjMap")["@"] = {}
            requestContext.get("svcObjMap")["@"]["customerInfo"] = lCustomerNspObj[0];
        }
    }
    for (var device in requestContext.get("siteObjMap")) {
        for (var siteArrObj in requestContext.get("siteObjMap")[device]) {
            let templateArgs = {};

            templateArgs = this.sfUtils.objectAssign(templateArgs, requestContext.get("svcObjMap"));
            templateArgs = this.sfUtils.objectAssign(templateArgs, requestContext.get("siteObjMap")[device][siteArrObj]);
            if (requestContext.get("svcObjMap")["@"] && requestContext.get("siteObjMap")[device][siteArrObj]["@"])
                templateArgs["@"] = this.sfUtils.objectAssign(requestContext.get("svcObjMap")["@"], requestContext.get("siteObjMap")[device][siteArrObj]["@"]);

            if (!templateArgs["description"] || (templateArgs["description"] && templateArgs["description"] === "") && requestContext.get("svcObjMap")["description"]) {
                templateArgs["description"] = requestContext.get("svcObjMap")["description"];
            }

            if (!requestContext.get("siteObjMap")[device][siteArrObj]["mtu"] && requestContext.get("svcObjMap")["mtu"]) {
                requestContext.get("siteObjMap")[device][siteArrObj]["mtu"]  = requestContext.get("svcObjMap")["mtu"];
            }

            if (!templateArgs["site-name"] || templateArgs["site-name"] === "") {
                templateArgs["site-name"] = requestContext.get("target");
            }
            if ((!requestContext.get("svcObjMap")["ne-service-id"]) && templateArgs["ne-service-id"]){
                requestContext.get("svcObjMap")["ne-service-id"] = templateArgs["ne-service-id"];
            }

            if (templateArgs["@"] && templateArgs["@"]["typeAndVersionMap"] && templateArgs["@"]["typeAndVersionMap"]["mediation"] === "nfmp") {
                let lSitePayload = this.nfmpMapper.mapToNfmpSite(device, requestContext.get("siteObjMap")[device][siteArrObj], requestContext.get("svcObjMap"), null, requestContext.get("currentTopology"), true, requestContext);
                let nfmpSiteClassName = Object.keys(lSitePayload)[0];
                if (requestContext.get("svcType").indexOf("tunnel") !== -1) {
                    this.sfUtils.nfmpAudit(requestContext.get("intentType"), lSitePayload, lSitePayload["objectFullName"], auditReport, requestContext.get("target"),null,
                        templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"],lSitePayload["distinguishedName"]);
                } else if (!templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"]) {
                    if (!(nfmpSiteClassName in nfmpSitePayload)) {
                        nfmpSitePayload[nfmpSiteClassName] = [];
                    }
                    nfmpSitePayload[nfmpSiteClassName] = nfmpSitePayload[nfmpSiteClassName].concat(lSitePayload[nfmpSiteClassName]);
                    foundLocalNfmp = true;
                } else { //HCO
                    let svcMgrIdSite = this.populateServiceMgrIdSite(requestContext, device);
                    let nfmpSiteClassName = Object.keys(lSitePayload)[0];
                    let nfmpSitePayload = {"childConfigInfo": {}};
                    nfmpSitePayload["childConfigInfo"][nfmpSiteClassName] = lSitePayload[nfmpSiteClassName][0];
                    if (!svcMgrIdSite){
                        let misalignedObj = auditFactory.createMisAlignedObject(nfmpSiteClassName, true, device, false);
                        auditReport.addMisAlignedObject(misalignedObj);
                    } else {
                        this.sfUtils.nfmpAudit(requestContext.get("intentType"), nfmpSitePayload, svcMgrIdSite, auditReport, requestContext.get("target"), this.nfmpMapper, templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"], svcMgrIdSite.replace(":" + device, ""));
                        foundAlienNfmp.push(templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"])
                    }
                }
            } else if (templateArgs["@"] && templateArgs["@"]["typeAndVersionMap"] && (templateArgs["@"]["typeAndVersionMap"]["mediation"] === "mdc"|| templateArgs["@"]["typeAndVersionMap"]["mediation"] === "mdm-ami")) {
                let adjecentDeviceList = JSON.parse(JSON.stringify(deviceList));
                let lDeviceIndex = adjecentDeviceList.indexOf(device);
                if (lDeviceIndex > -1) {
                    adjecentDeviceList.splice(lDeviceIndex, 1);
                }
                templateArgs["@"]["neighborName"] = adjecentDeviceList;

                if (typeof  AmiMapper === "function")
                    this.amiMapper = new AmiMapper(sfLogger);

                let templateMeta = this.sfUtils.getTemplateMappings(device, encodeURIComponent(templateArgs["site-name"]), requestContext.get("intentType"), requestContext.get("intentTypeVersion"), templateArgs["@"]["typeAndVersionMap"]['type'],
                    templateArgs["@"]["typeAndVersionMap"]['version'], {neighborName: adjecentDeviceList[0], classicSvcType: requestContext.get("srServiceType")});
                sfLogger.info("Audit templateMeta: {}", JSON.stringify(templateMeta));
                if (templateMeta && templateMeta["deviceMapper"] && mdcMapper[templateMeta["deviceMapper"]]) {
                    mdcMapper[templateMeta["deviceMapper"]].sfLogger = sfLogger;
                    if (typeof mdcMapper[templateMeta["deviceMapper"]].customAudit === "function") {
                        let self = this;
                        let customArr = mdcMapper[templateMeta["deviceMapper"]].customAudit(requestContext, new MediatorFramework("MDC", sfLogger),  templateMeta, device, templateArgs);
                        customArr.forEach(function (customObj) {
                            self.mdcAudit(requestContext, templateMeta, customObj["expectedJson"], customObj["actualJson"], mdcMapper[templateMeta["deviceMapper"]], device, auditReport,false, customObj["deviceRoot"]);
                        })

                    } else {
                        let expectedJson = mdcMapper[templateMeta["deviceMapper"]].mapToDeviceModel(this.sfUtils.cleanEmtyObjects(templateArgs), device, requestContext.get("target"), requestContext);
                        if (requestContext.get("svcType").indexOf("tunnel") === -1) {
                            expectedJson = this.sfUtils.cleanEmtyObjects(expectedJson);
                        }
                        let fetchResult;
                        if (templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"])
                            fetchResult = new MediatorFramework(templateArgs["@"]["typeAndVersionMap"]["alienMediatorName"].replace("MDC","NSP"), sfLogger).fetch(templateMeta['fetchUrl']);
                        else
                            fetchResult = new MediatorFramework("MDC", sfLogger).fetch(templateMeta['fetchUrl']);

                        if (fetchResult && fetchResult.success) {
                            fetchResult["response"] = fetchResult.response[Object.keys(fetchResult.response)[0]][0];
                            let deviceRoot = templateMeta["fetchUrl"].replace("restconf/data/network-device-mgr:network-devices/network-device="+device+"/root","")
                            this.mdcAudit(requestContext, templateMeta, expectedJson, fetchResult["response"], mdcMapper[templateMeta["deviceMapper"]], device, auditReport,false,deviceRoot);
                            if (typeof mdcMapper[templateMeta["deviceMapper"]].cleanAuditAttribute === "function" && auditReport.getMisAlignedAttributes()) {
                                let newAuditReport = auditFactory.createAuditReport(requestContext.get("intentType"), requestContext.get("target"));
                                if (auditReport.getMisAlignedObjects()){
                                    auditReport.getMisAlignedObjects().forEach(function (lObj) {
                                        newAuditReport.addMisAlignedObject(lObj)
                                    })
                                }
                                auditReport = mdcMapper[templateMeta["deviceMapper"]].cleanAuditAttribute(auditReport, newAuditReport);
                            }
                        } else {
                            sfLogger.error("Unable to fetch from device: {}", fetchResult["response"]);
                            auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(requestContext.get("target"), false, device));
                        }
                    }
                }
                else if (!this.amiMapper) {
                    throw new RuntimeException("Did not find any MDC device mapping or AMI mapping for  " + device);
                } else { //AMI Audit

                    if (typeof this.amiMapper.customAudit === "function") {
                        let self = this;
                        let customArr = this.amiMapper.customAudit(requestContext, new MediatorFramework("MDC", sfLogger),  templateMeta, device, templateArgs);
                        customArr.forEach(function (customObj) {
                            self.mdcAudit(requestContext, templateMeta, customObj["expectedJson"], customObj["actualJson"], self.amiMapper, device, auditReport,true, customObj["deviceRoot"]);
                        })

                    }
                }
            } else {
                throw new RuntimeException("Did not figure-out mediation - Something went wrong");
            }
        }
    }

    if (Object.keys(nfmpSitePayload).length> 0 || foundAlienNfmp.length > 0) {
        sfLogger.info("Audit serviceMgrId : " + lSvcMgrId);
        if (requestContext.get("svcObjMap")["serviceMgrId"] && requestContext.get("svcObjMap")["serviceMgrId"] != -1) {
            let jsonRequest = this.nfmpMapper.mapToNfmpSvc(requestContext.get("svcObjMap"), nfmpSitePayload, null, requestContext.get("svcTopo"), null, requestContext);
            if (Array.isArray(jsonRequest)){
                let self = this;
                jsonRequest.forEach(function (lNfmp) {
                    let nfmpSiteClass = Object.keys(lNfmp["childConfigInfo"])[0];
                    if (foundLocalNfmp)
                        self.sfUtils.nfmpAudit(requestContext.get("intentType"), lNfmp, "svc-mgr:service-" + lNfmp["childConfigInfo"][nfmpSiteClass]["id"], auditReport, requestContext.get("target"), self.nfmpMapper);
                    else if (foundAlienNfmp.length > 0)
                        foundAlienNfmp.forEach(function (lMediatorName) {
                            self.sfUtils.nfmpAudit(requestContext.get("intentType"), lNfmp, "svc-mgr:service-" + lNfmp["childConfigInfo"][nfmpSiteClass]["id"], auditReport, requestContext.get("target"), self.nfmpMapper, lMediatorName);
                        })
                })
            } else if (jsonRequest)
                if (foundLocalNfmp)
                    this.sfUtils.nfmpAudit(requestContext.get("intentType"), jsonRequest, lSvcMgrId, auditReport, requestContext.get("target"), this.nfmpMapper);
                else if (foundAlienNfmp.length > 0)
                    foundAlienNfmp.forEach(function (lMediatorName) {
                        this.sfUtils.nfmpAudit(requestContext.get("intentType"), jsonRequest, lSvcMgrId, auditReport, requestContext.get("target"), this.nfmpMapper, lMediatorName);
                    })
        }

        if (typeof this.nfmpMapper.nfmpPostServiceDeploy === "function") {
            requestContext.put("populateServiceMgrIdSite", this.populateServiceMgrIdSite);
            let postSvcPayload = this.nfmpMapper.nfmpPostServiceDeploy(requestContext.get("siteObjMap"), requestContext.get("svcObjMap"), requestContext.get("svcObjMap")["serviceMgrId"],requestContext);
            if (postSvcPayload && Array.isArray(postSvcPayload)){
                let self = this;
                postSvcPayload.forEach(function (lMediatorObj) {
                    self.sfUtils.nfmpAudit(requestContext.get("intentType"), lMediatorObj["payload"], lSvcMgrId, auditReport, requestContext.get("target"), self.nfmpMapper, lMediatorObj["name"], null, false);
                })
            } else if (postSvcPayload) {
                this.sfUtils.nfmpAudit(requestContext.get("intentType"), postSvcPayload, lSvcMgrId, auditReport, requestContext.get("target"), this.nfmpMapper, null, null, false);
            }
        }
    }

    //Find diff sites from operational model
    let operationalModelSites = this.nspRestconfFwk.getServiceSite(requestContext.get("svcType"), requestContext.get("target"));
    for (var j = 0; j < operationalModelSites.length; j++) {
        let lDevice = operationalModelSites[j]["site-id"];
        if (deviceList.indexOf(lDevice) == -1)
        {
            sfLogger.error("Found site {} in operational model which is not in intent config", lDevice);
            auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(operationalModelSites[j]["@"]["nsp-model:identifier"], true, lDevice));
        }

    }

    requestScope.remove();
    sfLogger.info("Audit took {} ms", Date.now() - startTime);

    return auditReport;
};

/*
   function: mdcAudit
    since: NSP 22.6
    short_description: Helper function to call sort and perform MDM managed node audits
    input:
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: True
        templateMeta:
            type: Object
            description: Template mappings based on the device
            mandatory: True
        expectedJson:
           type: HashMap
           description: Expected device configuration
           mandatory: True
        configJson:
           type: Object
           description: Actual NE device configuration
           mandatory: True
        device:
           type: String
           description: Name of the NE
           mandatory: True
        auditReport:
           type: auditReport
           description: IM auditReport object.
           mandatory: True
        ignoreStrictCheck:
           type: Boolean
           description: expectedJson and configJson must be exact match
           mandatory: False
    examples:
      "mdcAudit": |
         self.mdcAudit(requestContext, templateMeta, customObj["expectedJson"], customObj["actualJson"], mdcMapper[templateMeta["deviceMapper"]], device, auditReport,false);
 */
IBSFIntentHelper.prototype.mdcAudit = function (requestContext, templateMeta, expectedJson, configJson, mdcMapper, device, auditReport,ignoreStrictCheck, deviceRoot){
    requestContext.get("sfLogger").info("Audit expectedJson : {}", JSON.stringify(expectedJson));
    requestContext.get("sfLogger").info("Audit configJson : {}", JSON.stringify(configJson));

    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    let defaultJson = null;
    if (templateMeta['auditQueryParams']) {
        let fetchDefaults = new MediatorFramework("MDC", sfLogger).fetch(this.sfUtils.generateUrl(templateMeta['fetchUrl'], templateMeta['auditQueryParams']));
        if (fetchDefaults.success) {
            defaultJson = this.sfUtils.cleanEmtyObjects(fetchDefaults.response[Object.keys(fetchDefaults.response)[0]][0]);
        }
    }

    //Compare with operational model
    this.checkSitesOnAudit(requestContext, auditReport, auditFactory);
    this.auditJson(requestContext, expectedJson, configJson, defaultJson, mdcMapper, device, auditReport, ignoreStrictCheck, null, deviceRoot, false);
};

/*
   function: reconcile
    since: NSP 21.11
    short_description: helper function for RPC
    input:
        actionInput:
          description: This object contains information about action input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: ActionInput
          mandatory: True
     examples:
      "reconcile": |
        return "<intent-model xmlns=\"http://www.nokia.com/management-solutions/reference-action-intent\">" + JSON.stringify(svcIntentHelperFwk.reconcile(input)) + "</intent-model>";
 */
IBSFIntentHelper.prototype.reconcile = function (input) {
    this.input = input;
    requestScope = new ThreadLocal();
    let startTime = Date.now();
    let requestContext =  this.setRequestContext(input);
    this.extensionConfig.setSiteAndServiceObj(requestContext);
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));

    //let operModel = JSON.parse(input.getActionTreeElement().getFirstChild().getTextContent());
    let operModel = this.nspRestconfFwk.getServiceSite(requestContext.get("svcType"),requestContext.get("target"));
    let lOperModelFetch = this.nspRestconfFwk.getServiceRootElements(requestContext.get("svcType"), requestContext.get("target"));
    operModel["operObj"] = JSON.parse(JSON.stringify(lOperModelFetch));
    let mdcMapper = requestContext.get("mdcMapper");
    let deviceIdsCreatedModified = [];
    let foundNfmpSite = false;
    let foundAlienService = null;
    let intentModel = {
        "site-details" : {
            "site" : []
        }
    };
    sfLogger.info("[MDT-SVC-FWK] reconcile operModel - " + JSON.stringify(operModel, null, 2));
    let sdp = [];

    if (operModel["operObj"]["id"] && operModel["operObj"]["id"] != "0") {
        requestContext.put("serviceMgrId", operModel["operObj"]["id"])
    }

    if (operModel && operModel.length > 0) {
        let deviceList = operModel.map(function (el) {
            return el["site-id"];
        });
        for (var j = 0; j < operModel.length; j++) {
            let siteOperAmi = operModel[j];
            deviceIdsCreatedModified.push(siteOperAmi["site-id"])
            let deviceVersion = this.sfUtils.getTypeVersionMediation(siteOperAmi["site-id"]);
            let adjecentDeviceList = JSON.parse(JSON.stringify(deviceList));
            let lDeviceIndex = adjecentDeviceList.indexOf(siteOperAmi["site-id"]);
            if (lDeviceIndex > -1) {
                adjecentDeviceList.splice(lDeviceIndex, 1);
            }

            let siteIntentObj = null;
            if (deviceVersion["mediation"] === "mdc") {
                if (typeof  AmiMapper === "function")
                    this.amiMapper = new AmiMapper(sfLogger);
                if (lOperModelFetch && lOperModelFetch["@"] && lOperModelFetch["@"]["nsp-model:sources"] && lOperModelFetch["@"]["nsp-model:sources"].length > 0) {
                    if (lOperModelFetch["@"]["nsp-model:sources"].indexOf("fdn:yang:nsp-service-intent:/nsp-service-intent:intent-base/intent[service-name='"
                        + requestContext.get("target") + "'][intent-type='" + requestContext.get("intentType") + "']") === -1){
                        this.nspRestconfFwk.patchService({"@":{"nsp-model:sources":["fdn:yang:nsp-service-intent:/nsp-service-intent:intent-base/intent[service-name='"
                                + requestContext.get("target") + "'][intent-type='" + requestContext.get("intentType") + "']"]}, "service-id": requestContext.get("target")}, requestContext.get("svcType"));
                    }
                }
                let neId = lOperModelFetch["ne-service-id"];
                let templateMeta = this.sfUtils.getTemplateMappings(siteOperAmi["site-id"], encodeURIComponent(siteOperAmi["name"]), requestContext.get("intentType"), requestContext.get("intentTypeVersion"),  deviceVersion['type'], deviceVersion['version'],
                    {neighborName: adjecentDeviceList[0], classicSvcType: requestContext.get("srServiceType")});
                if (templateMeta && templateMeta["deviceMapper"] && mdcMapper[templateMeta["deviceMapper"]]) {
                    mdcMapper[templateMeta["deviceMapper"]].sfLogger = sfLogger;
                    if (typeof mdcMapper[templateMeta["deviceMapper"]].mapToIntentModel === "function") {
                        if (typeof mdcMapper[templateMeta["deviceMapper"]].prepopulateUrl === "function") {
                            let fetchUrl = mdcMapper[templateMeta["deviceMapper"]].prepopulateUrl(templateMeta, siteOperAmi["site-id"], {
                                neighborName: adjecentDeviceList[0],
                                siteName: siteOperAmi["name"],
                                neId: neId
                            }, requestContext);
                            if (fetchUrl) templateMeta['fetchUrl'] = fetchUrl
                        }
                        let fetchResult;
                        if (deviceVersion['alienMediatorName']) {
                            fetchResult = new MediatorFramework(deviceVersion['alienMediatorName'].replace("MDC", "NSP"), sfLogger).fetch(templateMeta['fetchUrl']);
                        } else {
                            let fetchUrl = templateMeta['fetchUrl'];
                            if (templateMeta['reconcileQueryParams']) {
                                fetchUrl = this.sfUtils.generateUrl(templateMeta['fetchUrl'], templateMeta['reconcileQueryParams'])
                            }
                            fetchResult = new MediatorFramework("MDC", sfLogger).fetch(fetchUrl);
                        }
                        if (fetchResult.success) {
                            fetchResult.response = fetchResult.response[Object.keys(fetchResult.response)[0]];
                            fetchResult.response[0]["operObj"] = lOperModelFetch;
                            siteIntentObj = mdcMapper[templateMeta["deviceMapper"]].mapToIntentModel(fetchResult.response, siteOperAmi["site-id"], {
                                neighborName: adjecentDeviceList[0],
                                neId: neId,
                                operModel: operModel["operObj"],
                                templateMeta : templateMeta,
                                svcObjMap: requestContext.get("svcObjMap")
                            }, requestContext);
                        } else {
                            throw new RuntimeException("Failed to fetch deviceConfig for  " + siteOperAmi["site-id"]);
                        }
                    }
                } else if (!this.amiMapper) {
                    throw new RuntimeException("Did not find any MDC device mapping or AMI mapping for  " + siteOperAmi["site-id"]);
                } else { //AMI

                    if (typeof this.amiMapper.getDeviceJson === "function") {
                        let deviceJson = this.amiMapper.getDeviceJson(siteOperAmi["site-id"], siteOperAmi["name"]);
                        if(deviceJson)
                        {
                            siteIntentObj = this.amiMapper.mapToIntentModel(deviceJson,siteOperAmi["site-id"])
                        }
                    }
                }
            } else if (deviceVersion["mediation"] === "nfmp") {
                let nfmpSiteFdn = null;
                if (siteOperAmi["@"] && siteOperAmi["@"]["nsp-model:sources"]){
                    siteOperAmi["@"]["nsp-model:sources"].forEach(function (lSource) {
                        if (lSource.indexOf("fdn:realm:sam:svc-mgr:service") !== -1
                            && lSource.indexOf("@ipServiceSiteDetail") === -1 && lSource.indexOf(":routing") === -1)
                            nfmpSiteFdn = lSource;
                    })
                }
                if (!nfmpSiteFdn)
                    throw new RuntimeException("Failed to resolve NFMP site source - " + JSON.stringify(siteOperAmi["@"]["nsp-model:sources"]));
                operModel["operObj"]["nfmpSiteFdn"] = nfmpSiteFdn.replace("fdn:realm:sam:", "");
                foundNfmpSite = true;
                siteIntentObj = this.nfmpMapper.mapToIntentModelSite(operModel["operObj"], siteOperAmi["site-id"]);

                if (deviceVersion['alienMediatorName']){
                    if (!foundAlienService) foundAlienService = {};
                    foundAlienService[deviceVersion['alienMediatorName']] = operModel["operObj"]["nfmpSiteFdn"].replace(":"+siteOperAmi["site-id"], "");
                }
            }

            if (siteIntentObj) {
                if (siteIntentObj["sdp"]) {
                    sdp = sdp.concat(siteIntentObj["sdp"]);
                }
                intentModel["site-details"]["site"].push(siteIntentObj["site"]);

                //copy all service property to top level, override if exists. Assumption all sites have same service level property
                for (var key in siteIntentObj["service"]) {
                    intentModel[key] = siteIntentObj["service"][key];
                }
            }
        }
    }
    if (!foundNfmpSite && operModel["operObj"]["id"] != 0)
        foundNfmpSite = true;
    if (foundNfmpSite && typeof this.nfmpMapper.mapToIntentModelService === "function"){
        let lSvcObj = this.nfmpMapper.mapToIntentModelService(operModel["operObj"], foundAlienService);
        if (lSvcObj["service"] && Object.keys(lSvcObj["service"]).length > 0 ){
            for (var key in lSvcObj["service"]) {
                intentModel[key] = lSvcObj["service"][key];
            }
        }
        if (lSvcObj["site"] && Object.keys(lSvcObj["site"]).length > 0 ){
            for (var key in lSvcObj["site"]) {
                intentModel["site-details"]["site"].forEach(function (lSite) {
                    let deviceVersion = this.sfUtils.getTypeVersionMediation(lSite["device-id"]);
                    if (deviceVersion["mediation"] === "nfmp")
                        lSite[key] = lSvcObj["site"][key];
                })
            }
        }
    }

    if (requestContext.get("intentConfigJson")["job-id"])
        intentModel["job-id"] = requestContext.get("intentConfigJson")["job-id"];

    if (requestContext.get("intentConfigJson")["mtu"])
        intentModel["mtu"] = requestContext.get("intentConfigJson")["mtu"];

    if (sdp.length != 0) {
        intentModel["sdp-details"] = {};
        intentModel["sdp-details"]["sdp"] = sdp;
    }

    requestContext.put("intentModel", intentModel);
    requestContext.put("intentConfigJson", intentModel);
    this.transformSiteObj(null, requestContext);
    this.copyTopoObjects(deviceIdsCreatedModified, requestContext);

    //Auto-audit
    let autoAuditEnabled = false;
    let lables=ibnService.findIntentTypeByName(requestContext.get("intentType"),requestContext.get("intentTypeVersion")).getIntentTypeLabelValues().toString();
    if (lables!==null && lables.indexOf("autoAudit") !== -1) {
        try {
            if (resourceProvider.getResource('auto-audit.json')) {
                autoAuditEnabled = true
            }
        } catch (e) {
            sfLogger.debug("autoAudit file not found - " + e)
        }
    }
    if (autoAuditEnabled){
        requestContext.get("svcObjMap")["serviceMgrId"] = "svc-mgr:service-" + requestContext.get("serviceMgrId");
        this.populateMediationAndFdn(requestContext.get("mdcMapper"), "",false, true, {classicSvcType: requestContext.get("srServiceType")}, requestContext);
        this.svcOperModelFwk.deployed(requestContext, true);
    }

    requestScope.remove();
    sfLogger.info("Reverse mapping took {} ms result {}", Date.now() - startTime , JSON.stringify(intentModel,null,2));
    return requestContext;
};

/*
   function: checkSitesOnSync
    since: NSP 22.6
    short_description: Helper function to delete sites.
    description:
        - When MDM/NFMP sites is deleted on Intent, need to delete that site by comparing topology
     input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
        jobManager:
          type: class
          description: instance of jobManagerFwk class
          mandatory: False
        deviceIdsCreatedModified:
          type: Object
          description: List of sites
          mandatory: True
*/
IBSFIntentHelper.prototype.checkSitesOnSync = function (requestContext, jobManager, deviceIdsCreatedModified) {
    if (!requestContext)
        requestContext = requestScope.get();
    let topologySites = this.getDiffSiteFromTopo(requestContext.get("currentTopology"), JSON.parse(JSON.stringify(requestContext.get("siteObjMap"))), requestContext).toArray();
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    for (var j = 0; j < topologySites.length; j++) {
        let topoSiteObj = topologySites[j].split("|");
        let siteToDel = topoSiteObj[0];
        let siteName = topoSiteObj.splice(1,topoSiteObj.length -1).join("");
        sfLogger.error("[MDT-SVC-FWK] cleanSiteOnSync - Found a site on topology not part of config, siteId = {} siteName = {}", siteToDel, siteName);
        if (deviceIdsCreatedModified.indexOf(siteToDel) !== -1) {
            deviceIdsCreatedModified.splice(deviceIdsCreatedModified.indexOf(siteToDel), 1);
        }
        try {
            let typeVersionMap = this.sfUtils.getTypeVersionMediation(siteToDel);
            if (typeVersionMap["mediation"] === "mdc") {
                if (typeof  AmiMapper === "function")
                    this.amiMapper = new AmiMapper(sfLogger);
                let templateMeta = this.sfUtils.getTemplateMappings(siteToDel, requestContext.get("target"), requestContext.get("intentType"), requestContext.get("intentTypeVersion"),
                    typeVersionMap['type'], typeVersionMap['version'], {classicSvcType: requestContext.get("srServiceType")});
                if (templateMeta) {
                    let mdcMapper = requestContext.get("mdcMapper");
                    let targetUrl = templateMeta['serviceRoot'];
                    let yangPatchJson = null;
                    if (typeof mdcMapper[templateMeta["deviceMapper"]].customDelete === "function") {
                        yangPatchJson = mdcMapper[templateMeta["deviceMapper"]].customDelete(requestContext, templateMeta, siteToDel, siteName);

                    } else {
                        yangPatchJson = requestContext.get("mdcMapper")[templateMeta["deviceMapper"]].yangPatchDelete(this.sfUtils.cleanEmtyObjects(requestContext.get("siteObjMap")), encodeURIComponent(siteName), {}, siteToDel, requestContext, templateMeta);
                    }
                    jobManager.mdmYangPatchTask(siteToDel, targetUrl, yangPatchJson, null, typeVersionMap["alienMediatorName"]);
                } else if (!this.amiMapper) {
                    throw new RuntimeException("Did not find any MDC device mapping or AMI mapping for  " + siteToDel);
                } else { //AMI delete Deployment
                    if (typeof this.amiMapper.getDeleteUrl === "function") {
                        let ldelUrl = this.amiMapper.getDeleteUrl(siteToDel, requestContext.get("target"), requestContext.get("intentType"), requestContext.get("intentTypeVersion"));
                        if (ldelUrl !== null && ldelUrl !== "undefined") {
                            jobManager.mdmDeleteTask(siteToDel, ldelUrl);
                        }
                    }
                }
            } else if (typeVersionMap["mediation"] === "nfmp") {
                let nfmpMgr = requestContext.get("svcObjMap")["serviceMgrId"];
                if (typeof nfmpMgr === "object"){
                    nfmpMgr = requestContext.get("svcObjMap")["serviceMgrId"][siteName]
                }
                jobManager.managedTasks.push(jobManager.nfmpDelete(nfmpMgr + ":" + siteToDel, 4, 4, typeVersionMap["alienMediatorName"]))
            }
        } catch (e) {
            sfLogger.error("[SvcFwk] checkSitesOnSync {}", e.message);
        }
    }
};

/*
   function: getDiffSiteFromTopo
    since: NSP 22.6
    short_description: Compare sites between IM configuration and whats been stored in topology.
     input:
        topology:
          type: Object
          description: IM Topology object
          mandatory: True
        nodalArgsMap:
          type: Object
          description: Configuration object
          mandatory: True
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: True
     output:
      success:
        type: HashSet
        description: list of sites found in topology but not in configuration
*/
IBSFIntentHelper.prototype.getDiffSiteFromTopo = function (topology, nodalArgsMap, requestContext) {
    let topologySites = new HashSet();
    let sfLogger = new ServiceFulfillmentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target"));
    sfLogger.debug("[MDT-SVC-FWK] getDiffSiteFromTopo  Topology  = {}", topology);
    if (topology) {
        let topologyObjectList = topology.getTopologyObjects();
        topologyObjectList.forEach(function (topologyObject) {
            let objectDeviceName = topologyObject.getObjectDeviceName().replaceAll("-", ":") ;
            let objectSiteName = topologyObject.getObjectRelativeObjectID();
            if (requestContext.get("intentType") === "composite" ||requestContext.get("intentType") === "wavencecomposite") {
                let objectSiteNameList = objectSiteName.split("-");
                if( objectSiteNameList[1] == "mpr") objectSiteNameList[1] = "mpr-backhaul";
                if (objectSiteNameList.length > 1 && objectSiteNameList[1] === requestContext.get("svcType"))
                    topologySites.add(objectDeviceName+"|"+objectSiteName);
            } else
                topologySites.add(objectDeviceName+"|"+objectSiteName);
        });
        sfLogger.debug("[MDT-SVC-FWK] getDiffSiteFromTopo topologySites from TOPO  = {}", topologySites.toString());

        for (var device in nodalArgsMap) {
            for (var siteArrObj in nodalArgsMap[device]) {

                if (!nodalArgsMap[device][siteArrObj]["site-name"]) nodalArgsMap[device][siteArrObj]["site-name"] = requestContext.get("target");

                if ((requestContext.get("intentType") === "composite" ||requestContext.get("intentType") === "wavencecomposite")&& topologySites.contains(device + "|" + nodalArgsMap[device][siteArrObj]["site-name"] +
                    "-" + requestContext.get("svcType"))) {
                    topologySites.remove(device + "|" + nodalArgsMap[device][siteArrObj]["site-name"] + "-" + requestContext.get("svcType"));
                } else if (requestContext.get("intentType") !== "composite" && topologySites.contains(device + "|" + nodalArgsMap[device][siteArrObj]["site-name"])) {
                    topologySites.remove(device + "|" + nodalArgsMap[device][siteArrObj]["site-name"]);
                } else if (requestContext.get("svcType") === "composite:composite" && nodalArgsMap[device][siteArrObj]["@"] && nodalArgsMap[device][siteArrObj]["@"]["serviceType"] &&
                    topologySites.contains(device + "|" + nodalArgsMap[device][siteArrObj]["@"]["serviceType"] + "_" + nodalArgsMap[device][siteArrObj]["site-name"])) {
                    topologySites.remove(device + "|" + nodalArgsMap[device][siteArrObj]["@"]["serviceType"] + "_" + nodalArgsMap[device][siteArrObj]["site-name"]);
                }
            }
        }
    }
    if (topologySites.size()>0)
        sfLogger.error("[MDT-SVC-FWK] getDiffSiteFromTopo diff Sites  = {}", topologySites.toString());
    return topologySites;
};

/*
   function: copyTopoObjects
    since: NSP 22.6
    short_description: Create new topology or clone existing with updated sites and XtraInfo
     input:
        deviceIdsCreatedModified:
          type: Object
          description: List of sites
          mandatory: True
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: True
     output:
      success:
        type: IIntentTopology
        description: IM topology instance
*/
IBSFIntentHelper.prototype.copyTopoObjects = function (deviceIdsCreatedModified, requestContext) {
    let newTopo = topologyFactory.createServiceTopology();
    if (!requestContext)
        requestContext = requestScope.get();

    for (var device in requestContext.get("siteObjMap")) {
        for (var siteArrObj in requestContext.get("siteObjMap")[device]) {
            if (deviceIdsCreatedModified.indexOf(device) !== -1) {
                if (requestContext.get("intentType") === "composite" || requestContext.get("intentType") === "wavencecomposite")
                    newTopo.addTopologyObject(topologyFactory.createTopologyObjectFrom("Sites", device.replaceAll(":", "-") +
                        ":" + requestContext.get("siteObjMap")[device][siteArrObj]["site-name"] + "-" + requestContext.get("svcType"), "INFRASTRUCTURE"));
                else if (requestContext.get("siteObjMap")[device][siteArrObj]["@"] && requestContext.get("siteObjMap")[device][siteArrObj]["@"]["serviceType"])
                    newTopo.addTopologyObject(topologyFactory.createTopologyObjectFrom("Sites", device.replaceAll(":", "-") +
                        ":" + requestContext.get("siteObjMap")[device][siteArrObj]["@"]["serviceType"] + "_"
                        +requestContext.get("siteObjMap")[device][siteArrObj]["site-name"], "INFRASTRUCTURE"));
                else
                    newTopo.addTopologyObject(topologyFactory.createTopologyObjectFrom("Sites", device.replaceAll(":", "-") +
                        ":" + requestContext.get("siteObjMap")[device][siteArrObj]["site-name"], "INFRASTRUCTURE"));
            }
        }
    }

    if (requestContext.get("currentTopology") && requestContext.get("currentTopology").getXtraInfo() !== null && !requestContext.get("currentTopology").getXtraInfo().isEmpty()) {
        requestContext.get("currentTopology").getXtraInfo().forEach(function (extraInfo) {
            newTopo.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom(extraInfo.getKey(), extraInfo.getValue()));
        })
    }

    requestContext.get("sfLogger").info("copyTopoObjects new Topology - {}", newTopo);
    requestContext.put("currentTopology", newTopo);
    return newTopo;
};

/*
   function: addTopologyExtraInfo
    since: NSP 22.6
    short_description: Create new topology or clone existing with updated sites and XtraInfo
     input:
        key:
          type: String
          description: key to be added
          mandatory: True
        value:
          type: String
          description: value to be added
          mandatory: True
        newTopo:
          type: IIntentTopology
          description: if topology is provided it will be used, else topology in requestContext will be used
          mandatory: False
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: True
*/
IBSFIntentHelper.prototype.addTopologyExtraInfo = function (key, value, newTopo, requestContext) {
    let xtraInfo = topologyFactory.createTopologyXtraInfoFrom(key, value);
    if (newTopo){
        newTopo.addXtraInfo(xtraInfo);
    } else{
        if (!requestContext) requestContext = requestScope.get();
        requestContext.get("currentTopology").addXtraInfo(xtraInfo);
    }
};

/*
   function: checkSitesOnAudit
    since: NSP 22.6
    short_description: Helper function to find diff sites.
    description:
        - By comparing to topology, diff all missing sites and show in audit report
     input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
        auditReport:
          type: auditReport
          description: IM auditReport object.
          mandatory: True
        auditFactory:
          type: auditFactory
          description: IM auditFactory object.
          mandatory: True
*/
IBSFIntentHelper.prototype.checkSitesOnAudit = function (requestContext, auditReport, auditFactory) {
    if (!requestContext) requestContext = requestScope.get();
    let topologySites = this.getDiffSiteFromTopo(requestContext.get("currentTopology"), requestContext.get("siteObjMap"), requestContext);
    topologySites.forEach(function (topologySite) {
        auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(requestContext.get("target"), false, topologySite.split("|")[0]));
    });
};

/*
   function: auditJson
    since: NSP 22.6
    short_description: MDM audit
      input:
        requestContext:
           type: HashMap
           description: Thread local attribute map for each intent instance.
           mandatory: True
        expectedJson:
           type: HashMap
           description: Expected device configuration
           mandatory: True
        configJson:
           type: Object
           description: Actual NE device configuration
           mandatory: True
        nodeDefaultJson:
           type: Object
           description: NE configuration along with default values
           mandatory: True, if supported
        device:
           type: String
           description: Name of the NE
           mandatory: True
        auditReport:
           type: auditReport
           description: IM auditReport object.
           mandatory: True
        ignoreStrictCheck:
           type: Boolean
           description: expectedJson and configJson must be exact match
           mandatory: False
        ainKey:
           type: String
           description: only used by recursive function call
           mandatory: False
        ainAggregatedKey:
           type: String
           description: only used by recursive function call
           mandatory: False
        ignoreEmptyExpected:
           type: Boolean
           description: only should be set to true in recursive call when nodeDefault is copied over to nodeJson
           mandatory: False
     output:
      success:
        type: IIntentTopology
        description: IM topology instance
*/
IBSFIntentHelper.prototype.auditJson = function (requestContext, expectedJson, nodeJson, nodeDefaultJson, mdcMapper, device, auditReport, ignoreStrictCheck, ainKey, ainAggregatedKey, ignoreEmptyExpected){
     requestContext.get("sfLogger").debug("[ServiceFulfillmentIntentHelper] auditJson {expected}: " + JSON.stringify(expectedJson));
     requestContext.get("sfLogger").debug("[ServiceFulfillmentIntentHelper] auditJson {node}: " + JSON.stringify(nodeJson));
     requestContext.get("sfLogger").debug("[ServiceFulfillmentIntentHelper] auditJson {nodeDefault}: " + JSON.stringify(nodeDefaultJson));
     let sfLogger = requestContext.get("sfLogger");
     let self = this;
     if (expectedJson == null || expectedJson == undefined){
        if (ignoreEmptyExpected == null || !ignoreEmptyExpected) {

            if (!ainAggregatedKey)
                 ainAggregatedKey = ainKey

            if (Array.isArray(nodeJson)){
                let nodeKeys = mdcMapper.getDeviceKey()(ainKey);
                if (nodeKeys && nodeKeys.length > 0){
                    for (let lNode in nodeJson) {
                        let newAinAggregatedKey = ainAggregatedKey + "=" + nodeJson[lNode][nodeKeys[0]] 
                        auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(newAinAggregatedKey, false, device, true));
                    }
                }
                else{
                    auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(ainAggregatedKey, false, device, true));
                }
            }
            else {
                auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(ainAggregatedKey, false, device, true));
            }
        }
     } else if (Array.isArray(nodeJson)){
         sfLogger.debug("[ServiceFulfillmentIntentHelper] Array handling nodeJson {} expectedJson {}", JSON.stringify(nodeJson), JSON.stringify(expectedJson));
         if (!Array.isArray(expectedJson)){
             nodeJson = JSON.stringify(nodeJson);
             if (!ainAggregatedKey)
                 ainAggregatedKey = ainKey
             auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(ainAggregatedKey, false, device, true));
         } else if (JSON.stringify(expectedJson[0]) === "null" || JSON.stringify(nodeJson[0]) === "null") { //null leaf-list (juniper)
             if (JSON.stringify(expectedJson) === "[{}]" && JSON.stringify(nodeJson) === "[null]"){
                 //ignore - juniper usecase
             } else if (JSON.stringify(expectedJson) !== JSON.stringify(nodeJson)){
                 if (!ainAggregatedKey)
                     ainAggregatedKey = ainKey
                 auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(ainAggregatedKey, JSON.stringify(expectedJson), JSON.stringify(nodeJson), device));
             }
         } else if (Array.isArray(expectedJson) && typeof expectedJson[0] !== "object") { //leaf-list
             expectedJson = expectedJson.sort();
             nodeJson = nodeJson.sort();
             if (expectedJson+"" !== nodeJson+""){
                 if (!ainAggregatedKey)
                     ainAggregatedKey = ainKey
                 auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(ainAggregatedKey, expectedJson, nodeJson, device));
             }
         } else {
             sfLogger.debug("[ServiceFulfillmentIntentHelper] Array handling 1 nodeJson {} expectedJson {}", JSON.stringify(nodeJson), JSON.stringify(expectedJson));
             let nodeHash = new HashMap();
             let expectedHash = new HashMap();
             let nodeDefaultHash = new HashMap();
             let nodeKeys = mdcMapper.getDeviceKey()(ainKey);

             if (!nodeKeys)
                 throw new RuntimeException ("MDC mapper doesnt have keys defined for " + ainKey)

             for (var lNodeJson in nodeJson) {
                 let keyStr = "";
                 for (var k=0; k<nodeKeys.length; k++){
                     keyStr += nodeJson[lNodeJson][nodeKeys[k]] + ",";
                 }
                 if (keyStr === "")
                     throw new RuntimeException ("MDC mapper doesnt have keys defined for " + ainKey)
                 keyStr = keyStr.slice(0, -1);
                 nodeHash.put(keyStr, nodeJson[lNodeJson]);
             }
             for (var lExpectedJson in expectedJson) {
                 let keyStr = "";
                 for (var k=0; k<nodeKeys.length; k++){
                     keyStr += expectedJson[lExpectedJson][nodeKeys[k]] + ",";
                 }
                 if (keyStr === "")
                     throw new RuntimeException ("MDC mapper doesnt have keys defined for " + ainKey)
                 keyStr = keyStr.slice(0, -1);
                 expectedHash.put(keyStr, expectedJson[lExpectedJson]);
             }
             sfLogger.debug("[ServiceFulfillmentIntentHelper] Array handling HashMap nodeHash {} expectedHash {}", nodeHash, expectedHash);
             expectedHash.keySet().forEach(function (i) {
                 if (!nodeHash.get(i)){
                     let lDisplayedKey = "";
                     let iObj = i;
                     if (i.indexOf(",")!== -1){
                         let iSplit = i.split(",");
                         if (iSplit && iSplit.length > 1) {
                             for (let  j = 0; j < iSplit.length; j++) {
                                 iSplit[j] = Java.type("java.net.URLEncoder").encode(iSplit[j], "UTF-8").replaceAll("\\+", "%20");
                             }
                         }
                         iObj = iSplit.join(",");
                     } else {
                         iObj = Java.type("java.net.URLEncoder").encode(iObj, "UTF-8").replaceAll("\\+", "%20");
                     }
                     if (ainAggregatedKey)
                         lDisplayedKey = ainAggregatedKey + "=" + iObj;
                     else
                         lDisplayedKey = ainKey + "=" + iObj;
                    auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(lDisplayedKey, true, device, false));
                 }
             });
             if (nodeDefaultJson) {
                for (var lNodeDefaultJson in nodeDefaultJson) {
                    let keyStr = "";
                    for (var k=0; k<nodeKeys.length; k++){
                        keyStr += nodeDefaultJson[lNodeDefaultJson][nodeKeys[k]] + ",";
                    }
                    if (keyStr === "")
                        throw new RuntimeException ("MDC mapper doesnt have keys defined for " + ainKey)
                    keyStr = keyStr.slice(0, -1);
                    nodeDefaultHash.put(keyStr, nodeDefaultJson[lNodeDefaultJson]);
                }
            }
            nodeHash.keySet().forEach(function (i) {
                let lDisplayedKey = "";
                let iObj = i;
                if (i.indexOf(",")!== -1){
                    let iSplit = i.split(",");
                    if (iSplit && iSplit.length > 1) {
                        for (let  j = 0; j < iSplit.length; j++) {
                            iSplit[j] = Java.type("java.net.URLEncoder").encode(iSplit[j], "UTF-8").replaceAll("\\+", "%20");
                        }
                    }
                    iObj = iSplit.join(",");
                } else {
                    iObj = Java.type("java.net.URLEncoder").encode(iObj, "UTF-8").replaceAll("\\+", "%20");
                }
                if (ainAggregatedKey)
                    lDisplayedKey = ainAggregatedKey + "=" + iObj;
                else
                    lDisplayedKey = ainKey + "=" + iObj;
                let defaultHashItem = (nodeDefaultHash.isEmpty() ? null : nodeDefaultHash.get(i));
                new IBSFIntentHelper().auditJson(requestContext, expectedHash.get(i), nodeHash.get(i), defaultHashItem, mdcMapper, device, auditReport, ignoreStrictCheck, i, lDisplayedKey, ignoreEmptyExpected);
            });
        }
     } else {
        let totalKeys = Object.keys(nodeJson);
        sfLogger.debug("[ServiceFulfillmentIntentHelper] totalKeys 1 " + JSON.stringify(totalKeys));
        Object.keys(expectedJson).forEach(function (key) {
            if (totalKeys.indexOf(key) === -1) {
                totalKeys.push(key);
            }
        });
        sfLogger.debug("[ServiceFulfillmentIntentHelper] totalKeys 2 " + JSON.stringify(totalKeys));
        totalKeys.forEach(function (key) {
            sfLogger.debug("[ServiceFulfillmentIntentHelper] nodeJson " + key + " type of -" + typeof nodeJson[key]);
            if (typeof nodeJson[key] === "object" && Object.keys(nodeJson[key]).length !== 0) {
                let lDisplayedKey = ainAggregatedKey + "/" + key;
                sfLogger.debug("[ServiceFulfillmentIntentHelper] found object  expectedJson[key]" + JSON.stringify(expectedJson[key]) + "  nodeJson[key]" + JSON.stringify(nodeJson[key]));
                let defaultJson = null;
                if (nodeDefaultJson) {
                    defaultJson = nodeDefaultJson[key];
                }
                new IBSFIntentHelper().auditJson(requestContext, expectedJson[key], nodeJson[key], defaultJson, mdcMapper, device, auditReport, ignoreStrictCheck, key, lDisplayedKey, ignoreEmptyExpected);
            } else if (nodeDefaultJson && typeof expectedJson[key] === "object" && expectedJson[key] !== null && Object.keys(expectedJson[key]).length !== 0 && (!nodeJson[key] || JSON.stringify(nodeJson[key]) == "{}") && typeof nodeDefaultJson[key] === "object" && Object.keys(nodeDefaultJson[key]).length !== 0) {
                //This is the case where expectedJson has values but they are all node default in container.  Need to use nodeDefaultJson if defined
                let lDisplayedKey = ainAggregatedKey + "/" + key;
                new IBSFIntentHelper().auditJson(requestContext, expectedJson[key], nodeDefaultJson[key], null, mdcMapper, device, auditReport, true, key, lDisplayedKey, true);
            } else {
                logger.debug("[ServiceFulfillmentIntentHelper] expectedJson[key] " + JSON.stringify(expectedJson[key]) + " nodeJson[key]" + JSON.stringify(nodeJson[key]))
                if (expectedJson[key] == nodeJson[key]) {
                    sfLogger.debug("[ServiceFulfillmentIntentHelper] Values for " + key + " are the same.");
                } else {
                    sfLogger.debug("[ServiceFulfillmentIntentHelper] expectedJson[key] " +expectedJson[key] + "  nodeJson[key] " + nodeJson[key]);
                    let expectedValue = Object.keys(expectedJson).indexOf(key) !== -1 ? expectedJson[key] : "{empty}";
                    let nodeValue;
                    if (Object.keys(nodeJson).indexOf(key) !== -1) {
                        nodeValue = nodeJson[key];
                    } else if (nodeDefaultJson) {
                        nodeValue = Object.keys(nodeDefaultJson).indexOf(key) !== -1 ? nodeDefaultJson[key] : "{empty}";
                    } else {
                        nodeValue = "{empty}";
                    }
                    if (expectedValue === "{}" && nodeValue === "{empty}") {
                        sfLogger.debug("[ServiceFulfillmentIntentHelper] Values for " + key + " are the same.");
                    }  else if (expectedValue === "{empty}" && typeof nodeValue === "object" && JSON.stringify(nodeValue) == "{}") {
                        sfLogger.debug("[ServiceFulfillmentIntentHelper] Values for " + key + " are the same.");
                    } else if (typeof expectedValue === 'object' && JSON.stringify(expectedValue) === "{}" && typeof nodeValue === "object" && JSON.stringify(nodeValue) == "{}") {
                        sfLogger.debug("[ServiceFulfillmentIntentHelper] Values for " + key + " are the same.");
                    } else if (nodeValue == expectedValue) {
                        sfLogger.debug("[ServiceFulfillmentIntentHelper] Values for " + key + " were found in the default node config");
                    } else if (ignoreStrictCheck && ignoreEmptyExpected && expectedValue == null) {
                        sfLogger.debug("[ServiceFulfillmentIntentHelper] Ignoring Undefined for " + key);
                    } else if (!(expectedValue === "{empty}" && nodeValue !== "{empty}") && ignoreStrictCheck) {
                        if (ainAggregatedKey)
                            key = ainAggregatedKey + "/" + key;
                        if (typeof nodeValue === "object" || typeof expectedValue === 'object') {
                            auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(key, true, device, false));
                        } else
                            auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(key, expectedValue, nodeValue, device));
                    } else if(!ignoreStrictCheck) {
                        if (ainAggregatedKey)
                            key = ainAggregatedKey + "/" + key;
                        if (typeof nodeValue === "object" || typeof expectedValue === 'object') {
                            auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(key, true, device, false));
                        } else
                            auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(key, expectedValue, nodeValue, device));
                    }
                }
            }
        });
     }
}
