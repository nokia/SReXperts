function ServiceFulfillmentLogger(intentTypeName, intentTypeVersion, target) {
    if (intentTypeName)
        this.intentTypeName = intentTypeName;
    if (intentTypeVersion)
        this.intentTypeVersion = intentTypeVersion;
    if (target)
        this.target = target;
}

ServiceFulfillmentLogger.prototype.target = "";
ServiceFulfillmentLogger.prototype.intentTypeVersion = "";
ServiceFulfillmentLogger.prototype.intentTypeName = "";

function initLogger(){
    if (!this.target || !this.intentTypeName || (this.intentTypeName === "" && this.target === "")){
        if (requestScope && requestScope.get() && requestScope.get().get("target")
            && requestScope.get().get("intentTypeVersion") && requestScope.get().get("intentType")){
            this.target = requestScope.get().get("target");
            this.intentTypeVersion = requestScope.get().get("intentTypeVersion");
            this.intentTypeName = requestScope.get().get("intentType");
        } else
            logger.debug("Cannot resolve target/intentTypeVersion/intentTypeName");
    }
}

/*
   function: debug
    since: NSP 21.11
    short_description: Formats debug logging
    input:
        logMessage:
          description: message to be be logged
          type: String
          mandatory: True
    example_responses:
      Success: |
        response: "[EPIPE][1][test32] logMessage"
*/
ServiceFulfillmentLogger.prototype.debug = function () {
    initLogger();
    arguments[0] = "[" + this.intentTypeName + "]" + "[" + this.intentTypeVersion + "]" + "[" + this.target + "] " + arguments[0];
    logger.debug(arguments[0], Array.prototype.slice.call(arguments, 1));
};

/*
   function: info
    since: NSP 21.11
    short_description: Formats info logging
    input:
        logMessage:
          description: message to be be logged
          type: String
          mandatory: True
    example_responses:
      Success: |
        response: "[EPIPE][1][test32] logMessage"
*/
ServiceFulfillmentLogger.prototype.info = function () {
    initLogger();
    arguments[0] = "[" + this.intentTypeName + "]" + "[" + this.intentTypeVersion + "]" + "[" + this.target + "] " + arguments[0];
    logger.info(arguments[0], Array.prototype.slice.call(arguments, 1));
};

/*
   function: warn
    since: NSP 21.11
    short_description: Formats warning logging
    input:
        logMessage:
          description: message to be be logged
          type: String
          mandatory: True
    example_responses:
      Success: |
        response: "[EPIPE][1][test32] logMessage"
*/
ServiceFulfillmentLogger.prototype.warn = function () {
    initLogger();
    arguments[0] = "[" + this.intentTypeName + "]" + "[" + this.intentTypeVersion + "]" + "[" + this.target + "] " + arguments[0];
    logger.warn(arguments[0], Array.prototype.slice.call(arguments, 1));
};

/*
   function: error
    since: NSP 21.11
    short_description: Formats error logging
    input:
        logMessage:
          description: message to be be logged
          type: String
          mandatory: True
    example_responses:
      Success: |
        response: "[EPIPE][1][test32] logMessage"
*/
ServiceFulfillmentLogger.prototype.error = function () {
    initLogger();
    arguments[0] = "[" + this.intentTypeName + "]" + "[" + this.intentTypeVersion + "]" + "[" + this.target + "] " + arguments[0];
    logger.error(arguments[0], Array.prototype.slice.call(arguments, 1));
};
