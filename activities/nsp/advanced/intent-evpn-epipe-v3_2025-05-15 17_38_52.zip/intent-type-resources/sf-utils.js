function ServiceFulfillmentIntentUtils(sfLogger) {
    if (sfLogger)
        this.sfLogger = sfLogger;
}

ServiceFulfillmentIntentUtils.prototype.target = null;
ServiceFulfillmentIntentUtils.prototype.intentTypeName = null;
ServiceFulfillmentIntentUtils.prototype.intentTypeVersion = null;
ServiceFulfillmentIntentUtils.prototype.sfLogger = new ServiceFulfillmentLogger();

/*
   function: getTypeVersionMediation
    since: NSP 21.6
    short_description: find mediation for given device
    description:
        - if device is found in mdc/nfmp mediator use version/name from mediator
        - else fetch from NSP inventory - oSF AMI usecases
    input:
        deviceName:
          description: Device NE ID
          type: String
          mandatory: True
    output:
      deviceObject:
        type: Boolean
        description: A device object that consist of type, version and mediation
    examples:
      "getTypeVersionMediation": |
        this.sfUtils.getTypeVersionMediation(deviceId);
    example_responses:
      Success: |
        result: {type : "7750 SR", "version": "21.10.R1", mediation: "mdc"}
*/
ServiceFulfillmentIntentUtils.prototype.getTypeVersionMediation = function (deviceName) {
    //TODO - handle dual management usecase
    let typeAndVersionMap = null;
    let self = this;
    let deviceInfo = mds.getAllInfoFromDevices(deviceName);
    logger.info("[MDT-FWK] NFMP getTypeVersionMediation deviceInfo:{}",deviceInfo);
    if (deviceInfo && !deviceInfo.isEmpty()){
        if (deviceInfo.size() > 1) {
            throw new RuntimeException("Found " + deviceInfo.size() + "instances in mediator for NE - " + deviceName);
        }
        deviceInfo.forEach(function (device) {
            logger.debug("[MDT-FWK] getTypeVersionMediation " + deviceName + " : " + device);
            if (device.getName() === deviceName) {
                if (device.getManagerName() === "MDC"){
                    let lRelease = device.getFamilyTypeRelease().split(":");
                    typeAndVersionMap = {
                        type: lRelease[2],
                        version: lRelease[1],
                        mediation: "mdc"
                    }
                }
                else if (device.getManagerName() === "NFM-P") {
                    typeAndVersionMap = {
                        type: device.getName(),
                        version: device.getFamilyTypeRelease().split(":")[1],
                        family: device.getFamilyTypeRelease(),
                        mediation: "nfmp"
                    };
                } else {
                    //Alien Mediator - HCO
                    if (device.getManagerName().indexOf("MDC") !== -1){
                        let lRelease = device.getFamilyTypeRelease().split(":");
                        typeAndVersionMap = {
                            type: lRelease[2],
                            version: lRelease[1],
                            family: device.getFamilyTypeRelease(),
                            alienMediatorName : device.getManagerName(),
                            "mediation": "mdc"
                        };
                    } else if (device.getManagerName().indexOf("NFM-P") !== -1) {
                        typeAndVersionMap = {
                            type: device.getName(),
                            version: device.getFamilyTypeRelease().split(":")[1],
                            family: device.getFamilyTypeRelease(),
                            alienMediatorName : device.getManagerName(),
                            "mediation": "nfmp"
                        };
                    } else
                        throw new RuntimeException ("Found device "+ deviceName + ", but cannot resolve mediation layer - " + device.getManagerName())
                }
            }
        })
    }

    if (!typeAndVersionMap) {
        let deviceInfos = nspRestconfFwk.findByXpath("/nsp-equipment:network/network-element[ne-id='" + deviceName + "']", 2);
        if (!deviceInfos) {
            throw new RuntimeException("Device not found :" + deviceName);
        } else if (deviceInfos.length != 1) {
            throw new RuntimeException("Device more devices for  :" + deviceName);
        } else {
            deviceInfos = deviceInfos[0];
        }
        let lMediation = "mdm-ami";
        let lVersion = deviceInfos["version"];
        if (deviceInfos["@"]["nsp-model:sources"][0].indexOf("sam") !== -1){
            lMediation = "nfmp";
            lVersion = lVersion.replace("TiMOS-B-","").replace("TiMOS-C-","");
        }
        typeAndVersionMap = {
            type: deviceInfos["type"],
            version: lVersion,
            mediation: lMediation
        };
    }
    return typeAndVersionMap;
};

/*
   function: getTemplateMappings
    since: NSP 21.6
    short_description: find matching entry for given device in templateMapping.json
    input:
        deviceName:
          description: Device NE ID
          type: String
          mandatory: True
        target:
          description: intent target
          type: String
          mandatory: True
        intentType:
          description: intent-type name
          type: String
          mandatory: True
        intentVersion:
          description: intent-type version
          type: String
          mandatory: True
        deviceType:
          description: Device chassis info
          type: String
          mandatory: True
        deviceVersion:
          description: Device version
          type: String
          mandatory: True
        extraParams:
          description: Additional info that is needed for templating
          type: Object
          mandatory: False
    output:
      matchingEntry:
        type: Object
        description: matching entry found in templateMapping.json for given device
    examples:
      "getTemplateMappings": |
        let templateMeta = this.sfUtils.getTemplateMappings(device, encodeURIComponent(templateArgs["site-name"]), requestContext.get("intentType"), requestContext.get("intentTypeVersion"), templateArgs["@"]["typeAndVersionMap"]['type'],
                    templateArgs["@"]["typeAndVersionMap"]['version'], {neighborName: adjecentDeviceList[0]});
    example_responses:
      Success: |
        result: {
            "type":"SR-",
            "serviceRoot": "https://restconf-gateway:443/restconf/data/nsp-network:network/node=1.1.1.1/node-root/nokia-conf:/configure/service?client-context=ibsf:epipe:1:servicetest1",
            "fetchUrl": "restconf/data/network-device-mgr:network-devices/network-device=1.1.1.1/root/nokia-conf:/configure/service/epipe=servicetest1",
            "deviceMapper": "srDeviceMapper"
          }
*/
ServiceFulfillmentIntentUtils.prototype.getTemplateMappings = function (deviceName, target, intentType, intentVersion, deviceType, deviceVersion, extraParams) {
    let templateEntry = {};
    target = target+"";
    let bridgeGroupName=target.split('%3A')[0];
    let targets=target.replace('%25','%').replace('%23','#').split('#');
    let sdpId=(targets.length===2) ? targets[1] : '';
    let templateMappings = utilityService.processTemplate(resourceProvider.getResource("templateMappings.json"),
        {deviceName: deviceName, target: target, targetEncoded: encodeURIComponent(target), sdpId: sdpId , intentType:intentType, intentVersion:intentVersion, extraParams: extraParams,bridgeGroupName:bridgeGroupName});
    this.sfLogger.debug("[MDT-FWK] Template Mappings for device " + deviceName + " : " + templateMappings);
    let json = JSON.parse(templateMappings);
    let found = false;
    json.forEach(function (element) {
        if (!found && deviceType.indexOf(element.type) !== -1 && deviceVersion.indexOf(element.version) !== -1) {
            templateEntry = element;
            found = true;
        } else if (!found && deviceType.indexOf(element.type) !== -1 && (element.version === undefined || element.version === null)) {
            templateEntry = element;
            found = true;
        }
    });
    if (!found) {
        templateEntry = null;
    }
    this.sfLogger.debug("[MDT-FWK] getTemplateMappings templateEntry: " + JSON.stringify(templateEntry));
    return templateEntry;
};

/*
   function: findNFMPByObjectFullName
    since: NSP 21.6
    short_description: find NFMP object by object full name
    input:
        className:
          description: Class name to be searched
          type: String
          mandatory: True
        objectFullName:
          description: object full name to be searched
          type: String
          mandatory: True
        childrenClassList:
          description: children to be included in search
          type: Object
          mandatory: False
    output:
      nfmpObject:
        type: Object
        description: Searched NFMP class objects
    examples:
      "findNFMPByObjectFullName": |
        let lServiceObj = this.sfUtils.findNFMPByObjectFullName("cpipe.Cpipe", "svc-mgr:service-" + operModel["id"], []);
*/
ServiceFulfillmentIntentUtils.prototype.findNFMPByObjectFullName = function (className, objectFullName, childrenClassList, alienMediator) {
    let payload = {
        "fullClassName": className,
        "filter": {
            "equal": {
                "name": "objectFullName",
                "value": objectFullName
            }
        }
    };
    if (childrenClassList && Array.isArray(childrenClassList)){
        payload["resultFilter"] = {};
        payload["resultFilter"]["children"] = [];
        childrenClassList.forEach(function (lClassName) {
            payload["resultFilter"]["children"].push({"resultFilter": lClassName});
        });
        if (payload["resultFilter"]["children"].length === 0){ //For some reason empty [] returns children
            payload["resultFilter"]["children"] = {};
        }
    }
    let nfmpMediator = new MediatorFramework("NFMP", this.sfLogger);
    if (alienMediator) nfmpMediator = new MediatorFramework(alienMediator, this.sfLogger);
    let results = nfmpMediator.post("/v3/search", payload);
    if (!results.success) {
        throw new RuntimeException(results.msg);
    } else {
        return JSON.parse(results.response);
    }
};

/*
   function: findNFMPGeneric
    since: NSP 21.6
    short_description: find NFMP object by object full name
    input:
        payload:
          description: Search payload body.
          type: Object
          mandatory: True
        objName:
          description: object full name to be searched. Only used by error string
          type: String
          mandatory: False
    output:
      nfmpObject:
        type: Object
        description: Searched NFMP class objects
    examples:
      "findNFMPGeneric": |
        let results = this.sfUtils.findNFMPGeneric(payload, sapAmi["qos"]["sap-" + direction]["policy-name"]);
*/
ServiceFulfillmentIntentUtils.prototype.findNFMPGeneric = function (payload, objName, alienMediator) {
    this.sfLogger.debug("[SR-SVC-FWK] nfmpSend payload = " + payload);
    let ret = null;
    let nfmpMediator = new MediatorFramework("NFMP", this.sfLogger)
    if (alienMediator) nfmpMediator = new MediatorFramework(alienMediator, this.sfLogger);
    let res = nfmpMediator.post("/v3/search", payload);
    if (res && res.success && res["response"]) {
        res["response"] = JSON.parse(res["response"]);
        if (res["response"][payload["fullClassName"]])
            ret = res["response"][payload["fullClassName"]]["id"];
    }
    if (!ret) {
        throw new RuntimeException("Didnt find " + payload["fullClassName"] + " NFMP  - " + objName);
    }
    return ret;
};

/*
   function: nfmpAudit
    since: NSP 21.6
    short_description: Parse NFMP audit response and construct auditReport
    input:
        intentType:
          description: IM intent-type name
          type: Object
          mandatory: True
        jsonRequest:
          description: configInfo object
          type: String
          mandatory: True
        fdn:
          description: object full name to be searched.
          type: String
          mandatory: True
        auditReport:
          description: IM auditReport object
          type: auditReport
          mandatory: True
        target:
          description: IM intent target
          type: String
          mandatory: True
        nfmpMapper:
          description: nfmp-mapper.js instance
          type: Object
          mandatory: False
    examples:
      "nfmpAudit": |
        this.nfmpAudit(lspPayload, auditReport, requestContext.get("target"));
*/
ServiceFulfillmentIntentUtils.prototype.nfmpAudit = function (intentType, jsonRequest, fdn, auditReport, target, nfmpMapper, alienMediator, distinguishedName, isSiteBased = true) {
    let payload = {};

    if (jsonRequest && jsonRequest.hasOwnProperty("distinguishedName") && jsonRequest.hasOwnProperty("objectFullName") && jsonRequest.hasOwnProperty("childConfigInfo")) {
        payload = jsonRequest;
    } else {

        payload["objectFullName"] = fdn;

        if (distinguishedName)
            payload["distinguishedName"] = distinguishedName
        else if (fdn.indexOf('serviceTunnel')===0) {
            payload["distinguishedName"] = "serviceTunnel"
        } else {
            payload["distinguishedName"] = "svc-mgr"
        }

        payload["configInfo"] = jsonRequest.childConfigInfo;
    }

    let nfmpMediator = new MediatorFramework("NFMP", this.sfLogger);

    if (alienMediator) nfmpMediator = new MediatorFramework(alienMediator, this.sfLogger);
    
    this.sfLogger.info("[" + this.intentType + "] NFMP audit payload : " + JSON.stringify(payload, null, 4));
    let jsonResponse = nfmpMediator.post("/audit", payload);

    if (jsonResponse.success) {

        jsonResponse = jsonResponse.response;
        let report = JSON.parse(jsonResponse);
        let cloneReport = JSON.parse(JSON.stringify(report));
        var splitter;
      
        if (isSiteBased == true) {
            splitter = getJsonPathSplitter(Object.keys(jsonRequest.childConfigInfo)[0]);
        }
        
        for (var  i = 0; i < report["misaligned-attributes"].length; i++) {
            if(report["misaligned-attributes"][i]["path"].indexOf(splitter) != -1){
                cloneReport["misaligned-attributes"][i]["name"] = report["misaligned-attributes"][i]["id"] + "|||" + "$" + report["misaligned-attributes"][i]["path"].substring(report["misaligned-attributes"][i]["path"].indexOf(splitter));
            } else{
                cloneReport["misaligned-attributes"][i]["name"] = report["misaligned-attributes"][i]["id"] + "|||" + report["misaligned-attributes"][i]["path"];
            }
        }
       
        for (var  i = 0; i < report["undesired-objects"].length; i++) {
            if(report["undesired-objects"][i]["path"].indexOf(splitter) != -1) {
                cloneReport["undesired-objects"][i]["object-id"] = report["undesired-objects"][i]["id"] + "|||" + "$" + report["undesired-objects"][i]["path"].substring(report["undesired-objects"][i]["path"].indexOf(splitter));
            } else {
                cloneReport["undesired-objects"][i]["object-id"] = report["undesired-objects"][i]["id"] + "|||" + report["undesired-objects"][i]["path"];
            }
        }
      
        for (var  i = 0; i < report["misaligned-objects"].length; i++) {
            if(report["misaligned-objects"][i]["path"].indexOf(splitter) != -1) {
                cloneReport["misaligned-objects"][i]["object-id"] = report["misaligned-objects"][i]["id"] + "|||" + "$" + report["misaligned-objects"][i]["path"].substring(report["misaligned-objects"][i]["path"].indexOf(splitter));
            } else {
                cloneReport["misaligned-objects"][i]["object-id"] = report["misaligned-objects"][i]["id"] + "|||" + report["misaligned-objects"][i]["path"];
            }
        }
    
        report = JSON.parse(JSON.stringify(cloneReport));
      
        if (!report.aligned) {
          
            if (nfmpMapper && typeof  nfmpMapper.cleanAuditAttribute === "function"){
                report["misaligned-attributes"] = nfmpMapper.cleanAuditAttribute(report["misaligned-attributes"]);
                report["undesired-objects"] = nfmpMapper.cleanAuditAttribute(report["undesired-objects"]);
                report["misaligned-objects"] = nfmpMapper.cleanAuditAttribute(report["misaligned-objects"]);
            }
          
            for (var  i = 0; i < report["misaligned-attributes"].length; i++) {
                let attributeData = report["misaligned-attributes"][i];
                let foundBitMaskIssue = false;

                //Clean up bitmask
                if (attributeData.expected && attributeData.expected["bit"] && Array.isArray(attributeData.expected["bit"])){
                    if (attributeData.expected["bit"].length === 0) foundBitMaskIssue = true;
                    attributeData.expected["bit"].forEach(function (lBit) {
                        if (JSON.stringify(attributeData.actual).indexOf(lBit) !== -1)
                            foundBitMaskIssue = true;
                    })
                }
              
                if (!foundBitMaskIssue) {
                    let misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, JSON.stringify(attributeData.expected), JSON.stringify(attributeData.actual), target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }
            }

            for (var  i = 0; i < report["undesired-objects"].length; i++) {
                let attributeData = report["undesired-objects"][i];
                let undesiredObj = auditFactory.createMisAlignedObject(attributeData["object-id"], false, target, true);
                auditReport.addMisAlignedObject(undesiredObj);
            }
          
            for (var  i = 0; i < report["misaligned-objects"].length; i++) {
                let attributeData = report["misaligned-objects"][i];
                let misalignedObj = auditFactory.createMisAlignedObject(attributeData["object-id"], true, target, false);
                auditReport.addMisAlignedObject(misalignedObj);
            }
        }
    } else {
        throw new RuntimeException(jsonResponse.response);
    }

};

function getJsonPathSplitter(service_type) {
    var splitter;

    switch(service_type){
        case 'epipe.Epipe':
            splitter = "['epipe.Site']";
            break;
        case 'vprn.Vprn':
            splitter = "['vprn.Site']";
            break;
        case 'cpipe.Cpipe':
            splitter = "['cpipe.Site']";
            break;
        case 'ies.Ies':
            splitter = "['ies.Site']";
            break;
        case 'vpls.Vpls':
            splitter = "['vpls.Site']";
            break;
    }
    
    return splitter;
}

/*
   function: cleanEmtyObjects
    since: NSP 21.6
    short_description: helper function that cleans up empty string or empty objects.
    input:
        obj:
          description: object that contains empty string or empty containers
          type: Object
          mandatory: True
        removeEmpty:
          description: function that provide the capability to ignore removing empty obejcts
          type: function
          mandatory: False
    output:
      lCleanObj:
        type: Object
        description: input object after removing empty objects or empty string
    examples:
      "cleanEmtyObjects": |
         expectedJson = this.sfUtils.cleanEmtyObjects(expectedJson);
*/
ServiceFulfillmentIntentUtils.prototype.cleanEmtyObjects = function (obj, removeEmpty) {
    this.sfLogger.debug("[MDT-SVC-FWK] cleanEmtyObjects obj {}", JSON.stringify(obj, null, 2));
    let lCleanObj = cleanEmtyObj(obj, removeEmpty);
    this.sfLogger.debug("[MDT-SVC-FWK] cleanEmtyObjects ret {}", JSON.stringify(lCleanObj, null, 2));
    return lCleanObj;
};

function cleanEmtyObj(obj, removeEmpty) {
    let rtn = obj;
    if (typeof (obj) === 'object') {
        rtn = JSON.parse(JSON.stringify(obj));
        if (obj instanceof Array) {
            rtn = obj.map((x) => cleanEmtyObj(x, removeEmpty));
        } else {
            for (var  key in obj) {
                if (key && obj.hasOwnProperty(key)) {
                    logger.debug("[MDT-SVC-FWK] cleanEmtyObj key " + key + " obj[key] = " + obj[key] + " typeof obj[key]  " + typeof obj[key]);
                    if (obj[key] && typeof obj[key] === 'object' && (Object.keys(obj[key]).length === 0)) {
                        if (!removeEmpty || removeEmpty(key)) {
                            delete rtn[key]
                        }
                    } else if (typeof obj[key] === 'string' && (obj[key].length === 0)) {
                        if (!removeEmpty || removeEmpty(key)) {
                           delete rtn[key]
                        }
                    } else {
                        let lClean = cleanEmtyObj(obj[key], removeEmpty);
                        logger.debug("[MDT-SVC-FWK] cleanEmtyObj lClean {}  type:{}", JSON.stringify(lClean), typeof lClean);
                        if (lClean && typeof lClean === 'object' && JSON.stringify(lClean) === '{}') {
                            if (!removeEmpty || removeEmpty(key)) {
                                delete rtn[key];
                            }
                        } else
                            rtn[key] = lClean
                    }
                }
            }
        }
    }
    return rtn
}

/*
   function: convertToString
    since: NSP 21.6
    short_description: Stringfy object or return empty string
    input:
        property:
          description: Object to be sorted
          type: Object
          mandatory: True
    output:
      sortedObject:
        type: Object
        description: Object returned after sorting
*/
ServiceFulfillmentIntentUtils.prototype.convertToString = function (property) {
    if (property) {
        return property + "";
    } else {
        return ""
    }
};

/*
   function: getIntentTypeVersion
    since: NSP 21.6
    short_description: Find intent-type version for given instance
    input:
        intentType:
          description: intent-type name
          type: Object
          mandatory: True
        target:
          description: intent-type instance name
          type: Object
          mandatory: True
    output:
      intentTypeVersion:
        type: Object
        description: intent type version
*/
ServiceFulfillmentIntentUtils.prototype.getIntentTypeVersion = function (intentType, target) {
    let lIntent = ibnService.getIntent(intentType, target);
    this.target = target;
    this.intentTypeName = intentType;
    this.intentTypeVersion = lIntent.getIntentTypeVersion();
    return this.intentTypeVersion;
};

/*
   function: parseError
    since: NSP 21.6
    short_description: Parse NSP error response and extract error string
    input:
        errorResponse:
          description: NSP error response
          type: Object
          mandatory: True
    output:
      errorString:
        type: String
        description: Extracted error string
*/
ServiceFulfillmentIntentUtils.prototype.parseError = function (errorResponse) {
    let res = null;
    try {
        errorResponse = errorResponse[Object.keys(errorResponse)[0]];
        if (errorResponse["edit-status"] && errorResponse["edit-status"]["edit"] && errorResponse["edit-status"]["edit"][0])
            res = errorResponse["edit-status"]["edit"][0];
        else if (errorResponse["ietf-restconf:errors"] && errorResponse["ietf-restconf:errors"]["error"])
            res = errorResponse["ietf-restconf:errors"]["error"][0]["error-message"];
        else if (errorResponse["error"] && errorResponse["error"][0])
            res = errorResponse["error"][0]["error-message"];
        else
            res = errorResponse;
        res = res.replaceAll('<','').replaceAll('>','');
    } catch (e) {
        this.sfLogger.error("[SvcFwk] parseError {}", e.message);
        res = errorResponse;
    }
    this.sfLogger.debug("[SvcFwk] error message returning {}", JSON.stringify(res));
    return JSON.stringify(res);
};

/*
   function: objectAssign
    since: NSP 22.6
    short_description: Merge two objects. IM javascript engine doesnt have Object.assign()
    input:
        newObject:
          description: First Object
          type: Object
          mandatory: True
        oldObject:
          description: Second Object
          type: Object
          mandatory: True
    output:
      mergedObject:
        type: String
        description: Merged object
*/
ServiceFulfillmentIntentUtils.prototype.objectAssign = function(newObject, oldObject) {
    if (!Object.assign) {
        Object.defineProperty(Object, 'assign', {
            enumerable: false,
            configurable: true,
            writable: true,
            value: function(target) {
                'use strict';
                if (target === undefined || target === null) {
                    throw new TypeError('Cannot convert first argument to object');
                }

                let to = Object(target);
                for (var  i = 1; i < arguments.length; i++) {
                    let nextSource = arguments[i];
                    if (nextSource === undefined || nextSource === null) {
                        continue;
                    }
                    nextSource = Object(nextSource);

                    let keysArray = Object.keys(nextSource);
                    for (var  nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                        let nextKey = keysArray[nextIndex];
                        let desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                        if (desc !== undefined && desc.enumerable) {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
                return to;
            }
        });
    }
    newObject = Object.assign(newObject, oldObject);
    return newObject;
};

/*
   function: OBJtoXML
    since: NSP 23.4
    short_description: Convert JSON object to XML
    input:
        obj:
          description: JSON object
          type: Object
          mandatory: True
    output:
      xmlObject:
        type: String
        description: XML output
*/
ServiceFulfillmentIntentUtils.prototype.OBJtoXML = function(obj) {
    let xml = '';
    for (var  prop in obj) {
        if (obj[prop] || obj[prop] === false ||  obj[prop] == 0 ) {
            xml += obj[prop] instanceof Array ? '' : "<" + prop + ">";
            if (obj[prop] instanceof Array) {
                for (var  array in obj[prop]) {
                    xml += "<" + prop + ">";
                    xml += this.OBJtoXML(new Object(obj[prop][array]));
                    xml += "</" + prop + ">";
                }
            } else if (typeof obj[prop] == "object") {
                xml += this.OBJtoXML(new Object(obj[prop]));
            } else {
                xml += Java.type("org.apache.commons.lang.StringEscapeUtils").escapeXml(obj[prop].toString());
            }
            xml += obj[prop] instanceof Array ? '' : "</" + prop + ">";
        }
    }
    xml = xml.replace(/<\/?[0-9]{1,}>/g, '');
    this.sfLogger.debug("[SvcFwk] OBJtoXML {}", xml);
    return xml
}

/*
   function: getExtraInfo
    since: NSP 23.4
    short_description: Get extra info from topology
    input:
        key:
          description: key to be retrieved from topology
          type: String
          mandatory: True
        topology:
          description: Topology object
          type: Object
          mandatory: True
    output:
      value:
        type: String
        description: Value stored in topology extra info
*/
ServiceFulfillmentIntentUtils.prototype.getExtraInfo = function (key, topology) {
    let ret = null;
    if (topology && topology.getXtraInfo() !== null && !topology.getXtraInfo().isEmpty()) {
        let self = this;
        topology.getXtraInfo().forEach(function (extraInfo) {
            self.sfLogger.debug("[SvcFwk][getExtraInfo] extraInfo {} {} ", key, extraInfo.getKey());
            if (extraInfo.getKey() != null && extraInfo.getKey() === key) {
                if (extraInfo.getValue() != null) {
                    ret = extraInfo.getValue();
                }
            }
        });
    }
    this.sfLogger.debug("[SvcFwk][getExtraInfo]  ret {} ", ret);
    return ret;
};

/*
   function: expandIfIPv6Address
    since: NSP 24.8
    short_description: Expand IPv6 short abbreviation. Used to expand and uppercase to match NFMP. Expanded shorten usually pads non 0 to 4 numbers but NFMP does not, optional flag
    input:
        address:
          description: ipv6 or ipv6 address with or without prefix
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Expanded IPv6 address
*/
ServiceFulfillmentIntentUtils.prototype.expandIfIPv6Address = function (address, padNonZero) {
    if(typeof address !== 'string'){
        return address;
    }
    if (typeof padNonZero === 'undefined') {
        padNonZero = false;
    }
    return (address.indexOf(":")>=0) ? this.expandIPv6Address(address, padNonZero) : address;
}


/*
   function: expandIPv6Address
    since: NSP 23.8
    short_description: Expand IPv6 short abbreviation. Used to expand and uppercase to match NFMP. Expanded shorten usually pads non 0 to 4 numbers but NFMP does not, optional flag
    input:
        address:
          description: Short IPv6 address
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Expanded IPv6 address
*/
ServiceFulfillmentIntentUtils.prototype.expandIPv6Address = function (address, padNonZero) {
    if(typeof address !== 'string'){
        return address;
    }
    if (typeof padNonZero === 'undefined') {
        padNonZero = false;
    }
    var fullAddress = [];
    var expandedAddress = "";
    var validGroupCount = 8;

    // Split CIDR notation if present
    var parts = address.split('/');
    var ipv6 = parts[0];
    var cidr = parts[1] || '';

    // Handle embedded IPv4
    var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
    var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;

    // Look for embedded IPv4
    if (validateIpv4.test(ipv6)) {
        var groups = ipv6.match(extractIpv4);
        var ipv4 = groups.slice(1).map(function(g) {
            return ('00' + parseInt(g, 10).toString(16)).slice(-2);
        }).join('');
        ipv6 = ipv6.replace(extractIpv4, ipv4.slice(0, 4).replace(/^0+/, '') + ':' + ipv4.slice(4).replace(/^0+/, ''));
    }

    // Handle '::' notation
    if (ipv6.indexOf("::")>=0) {
        var sides = ipv6.split("::");
        var leftGroups = sides[0] ? sides[0].split(":") : [];
        var rightGroups = sides[1] ? sides[1].split(":") : [];
        var missingGroups = validGroupCount - (leftGroups.length + rightGroups.length);

        fullAddress = leftGroups;
        for (var i = 0; i < missingGroups; i++) {
            fullAddress.push('0');
        }
        fullAddress = fullAddress.concat(rightGroups);
    } else {
        fullAddress = ipv6.split(":");
    }

    // Ensure we have exactly 8 groups
    if (fullAddress.length !== validGroupCount) {
        throw new Error("Invalid IPv6 address");
    }

    // Expand each group
    expandedAddress = fullAddress.map(function(group) {
        group = group.toUpperCase();
        group = group.replace(/^0+/, '') || '0';
        if (group !== '0' && padNonZero) {
            group = ('0000' + group).slice(-4);
        }
        return group;
    }).join(':');

    // Add back the CIDR notation if it was present
    return expandedAddress + (cidr ? '/' + cidr : '');
};


/*
   function: compressIfIPV6
    since: NSP 24.8
    short_description: Compress to IPv6 short abbreviation in lowercase for md-sros
    input:
        address:
          description: ipv6 or ipv4 address with or without prefix
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Compressed IPv6 address or ipv4
*/
ServiceFulfillmentIntentUtils.prototype.compressIfIPV6 = function (address) {
    return (address.indexOf(":")>=0) ? this.compressIPV6(address) : address;
}

/*
   function: compressIPV6
    since: NSP 23.8
    short_description: Compress to IPv6 short abbreviation in lowercase for md-sros
    input:
        address:
          description: Expanded IPv6 address
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Compressed IPv6 address
*/
ServiceFulfillmentIntentUtils.prototype.compressIPV6 = function (address) {
    address=this.expandIPv6Address(address);

    // Split CIDR notation if present
    var parts = address.split('/');
    var ipv6 = parts[0];
    var cidr = parts[1] || '';

    // Split the address into groups
    var groups = ipv6.split(':');

    // Remove empty groups at the beginning and end
    while (groups[0] === '') groups.shift();
    while (groups[groups.length - 1] === '') groups.pop();

    // Find the position of the double colon if it exists
    var doubleColonIndex = groups.indexOf('');

    if (doubleColonIndex !== -1) {
        // Remove all empty groups
        groups = groups.filter(function(group) { return group !== ''; });

        // Insert the correct number of zero groups
        var zerosToAdd = 8 - groups.length;
        var zeros = [];
        for (var i = 0; i < zerosToAdd; i++) {
            zeros.push('0');
        }
        groups.splice.apply(groups, [doubleColonIndex, 0].concat(zeros));
    }

    // Ensure we have 8 groups
    //while (groups.length < 8) groups.push('0');

    // Remove leading zeros from each group
    groups = groups.map(function(group) {
        return parseInt(group || '0', 16).toString(16);
    });

    // Find the longest run of zeros
    var longestZeroRun = {start: -1, length: 0};
    var currentRun = {start: -1, length: 0};

    for (var i = 0; i < groups.length; i++) {
        if (groups[i] === '0') {
            if (currentRun.length === 0) currentRun.start = i;
            currentRun.length++;
            if (currentRun.length > longestZeroRun.length) {
                longestZeroRun = {start: currentRun.start, length: currentRun.length};
            }
        } else {
            currentRun = {start: -1, length: 0};
        }
    }

    // Replace longest run of zeros with '::'
    if (longestZeroRun.length > 1) {
        groups.splice(longestZeroRun.start, longestZeroRun.length, '');
        if (longestZeroRun.start === 0) groups.unshift('');
        if (longestZeroRun.start + longestZeroRun.length === 8) groups.push('');
    }

    // Join the groups and add back the CIDR notation if it was present
    return groups.join(':') + (cidr ? '/' + cidr : '');
};

/*
   function: getIpv4System
    since: NSP 24.8
    short_description: Retrieve ipv4 system ip.
    input:
      systemIp:
        description: Source NE system ID
        type: String
        mandatory: True
    output:
      response:
        type: String
        description: IPV4 system ip
*/
ServiceFulfillmentIntentUtils.prototype.getIpv4System = function (sysIp) {
    //Requires openconfig adaptor sros-oc-logical-inventory
    if(sysIp.indexOf(":")>=0){
        let xpath="/nsp-network:network/node[node-id='"+sysIp+"']/node-root/openconfig-interfaces:interfaces/interface/subinterfaces/subinterface[index=1]/openconfig-if-ip:ipv4/addresses/address[nsp-openconfig-if-ip-augments:primary='true']"
        let findRes = nspRestconfFwk.findByXpath(xpath, 2, "ip");
        if(findRes && findRes.length>0 && findRes[0].ip && findRes[0].ip!==null && findRes[0].ip !==''){
            sysIp=findRes[0].ip;
        }
    }
    this.sfLogger.debug("[getIpv4System] sysIp {}", sysIp);
    return sysIp;
};

/*
   function: isSrsNode
    since: NSP 23.11
    short_description:
    input:
        neId:
          description: NE ID
          type: String
          mandatory: True
    output:
      value:
        type: boolean
        description: If the NE chassis type is SR-s
*/
ServiceFulfillmentIntentUtils.prototype.isSrsNode = function (neId, lDeviceInfo) {
    let lIsSrs = false;
    let lSrsTypes = ["7750 SR-7s", "7750 SR-14s", "7750 SR-1s", "7750 SR-2s"]
    if(lDeviceInfo===undefined) { lDeviceInfo = this.getTypeVersionMediation(neId) };
    if (lDeviceInfo && lDeviceInfo["family"]) {
        let lNeType = lDeviceInfo["family"].split(":")[2];
        if (lSrsTypes.indexOf(lNeType) > -1) {
            lIsSrs = true;
        }
    }

    return lIsSrs;
}

/*
   function: is7750Node
    since: NSP 23.11
    short_description:
    input:
        neId:
          description: NE ID
          type: String
          mandatory: True
    output:
      value:
        type: boolean
        description: If the NE chassis type is 7750
*/
ServiceFulfillmentIntentUtils.prototype.is7750Node = function (neId, lDeviceInfo) {
    let lIs7750 = false;
    if(lDeviceInfo===undefined) { lDeviceInfo = this.getTypeVersionMediation(neId) };
    if (lDeviceInfo) {
        let lNeType = " ";
        if (lDeviceInfo["family"]) {
            lNeType = lDeviceInfo["family"].split(":")[2];
        } else if (lDeviceInfo["type"]) {
            lNeType = lDeviceInfo["type"];
        }
        if (lNeType.indexOf("7750") > -1) {
            lIs7750 = true;
        }
    }

    return lIs7750;
}

/*
   function: isIxrR6OrENode
    since: NSP 23.11
    short_description:
    input:
        neId:
          description: NE ID
          type: String
          mandatory: True
    output:
      value:
        type: boolean
        description: If the NE chassis type is IXR-R6 or IXR-e
*/
ServiceFulfillmentIntentUtils.prototype.isIxrR6OrENode = function (neId, lDeviceInfo) {
    let lIsIxrR6OrE = false;
    if(lDeviceInfo===undefined) { lDeviceInfo = this.getTypeVersionMediation(neId) };
    if (lDeviceInfo) {
        let lNeType = " ";
        if (lDeviceInfo["family"]) {
            lNeType = lDeviceInfo["family"].split(":")[2];
        } else if (lDeviceInfo["type"]) {
            lNeType = lDeviceInfo["type"];
        }
        if (lNeType.indexOf("7250") > -1) {
            lIsIxrR6OrE = true;
        }
    }

    return lIsIxrR6OrE;
}

/*
   function: isIxrsNode
    since: NSP 23.11
    short_description:
    input:
        neId:
          description: NE ID
          type: String
          mandatory: True
    output:
      value:
        type: boolean
        description: If the NE chassis type is IXR-s
*/
ServiceFulfillmentIntentUtils.prototype.isIxrsNode = function (neId, lDeviceInfo) {
    let lIsIxrs = false;
    let lTypes = ["7250 IXR-s"]
    if(lDeviceInfo===undefined) { lDeviceInfo = this.getTypeVersionMediation(neId) };
    if (lDeviceInfo) {
        let lNeType = " ";
        if (lDeviceInfo["family"]) {
            lNeType = lDeviceInfo["family"].split(":")[2];
        } else if (lDeviceInfo["type"]) {
            lNeType = lDeviceInfo["type"];
        }
        if (lTypes.indexOf(lNeType) > -1) {
            lIsIxrs = true;
        }
    }

    return lIsIxrs;
}

/*
   function: isIxr6Node
    since: NSP 23.11
    short_description:
    input:
        neId:
          description: NE ID
          type: String
          mandatory: True
    output:
      value:
        type: boolean
        description: If the NE chassis type is IXR-6
*/
ServiceFulfillmentIntentUtils.prototype.isIxr6Node = function (neId, lDeviceInfo) {
    let lIsIxr6 = false;
    let lTypes = ["7250 IXR-6"]
    if(lDeviceInfo===undefined) { let lDeviceInfo = this.getTypeVersionMediation(neId) };
    if (lDeviceInfo) {
        let lNeType = " ";
        if (lDeviceInfo["family"]) {
            lNeType = lDeviceInfo["family"].split(":")[2];
        } else if (lDeviceInfo["type"]) {
            lNeType = lDeviceInfo["type"];
        }
        if (lTypes.indexOf(lNeType) > -1) {
            lIsIxr6 = true;
        }
    }

    return lIsIxr6;
}

/*
   function: getRtFormat
    since: NSP 23.11
    short_description: Determines RT format.
    input:
        routeTarget:
          description: Route Target in var1:var2 format.  Logic only for ipv4 at the moment.
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: asBased or ipAddressBased or as4Byte
*/
ServiceFulfillmentIntentUtils.prototype.getRtFormat = function (routeTarget) {
    let lRtFormat = "asBased";
    if (routeTarget) {
        if (routeTarget.contains(".")) {
            return "ipAddressBased";
        }
        let lRt = routeTarget.split(":");
        if (lRt.length > 0 && parseInt(lRt[0]) > 65535) {
            return "as4Byte";
        }
    }

    return lRtFormat;
}

/*
   function: is7705Node
    since: NSP 23.11
    short_description:
    input:
        neId:
          description: NE ID
          type: String
          mandatory: True
    output:
      value:
        type: boolean
        description: If the NE chassis type is 7705
*/
ServiceFulfillmentIntentUtils.prototype.is7705Node = function (neId, lDeviceInfo) {
    let lIs7705 = false;
    if(lDeviceInfo===undefined) { lDeviceInfo = this.getTypeVersionMediation(neId) };
    if (lDeviceInfo && lDeviceInfo["family"]) {
        let lNeType = lDeviceInfo["family"].split(":")[2];
        if (lNeType.indexOf("7705") > -1) {
            lIs7705 = true;
        }
    }

    return lIs7705;
}

/*
   function: nfmpRedundancyForceSwitchover
    since: NSP 23.11
    short_description:
    input:
        input:
          description: This object contains information about action input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: ActionInput
          mandatory: True
        serviceType:
          type: String
          description: Service type
          mandatory: True
    output:
      rpcResults:
        type: string
        description: force switchover success.
    output_on_error:
      rpcResults:
        type: string
        description: on error utilityService.buildErrorActionResponse("someString") is used to generate error.
     examples:
      "rpc nfmp-redundancy-force-switchover": |
        return sfUtils.nfmpRedundancyForceSwitchover(input, "vll");
*/
ServiceFulfillmentIntentUtils.prototype.nfmpRedundancyForceSwitchover = function (input, operModelSvcType, aInNspRestconfFwk) {
    this.sfLogger.debug("nfmpRedundancyForceSwitchover   input:   " + JSON.stringify(input));
    let nfmpFwk = new MediatorFramework("NFMP");
    let lError;
    let fetchResp = aInNspRestconfFwk.getServiceRootElements(operModelSvcType, input.getTarget(), "name;services;id");
    let lSvcMgrId;
    if (fetchResp) {
        lSvcMgrId= fetchResp.id;
    } else {
        lError = "nfmpRedundancyForceSwitchover failed: cannot get service manager Id with intent target as" + input.getTarget();
        this.sfLogger.error("nfmpRedundancyForceSwitchover:   " + lError);
        return utilityService.buildErrorActionResponse(lError);
    }
    let serviceType = operModelSvcType;
    if (operModelSvcType === "eline" || operModelSvcType === "cline") {
        serviceType = "vll";
    } else if (operModelSvcType === "elan") {
        serviceType = "vpls";
    }

    let rootChildren = input.getActionTreeElement().getChildNodes();
    let lRpcDeviceId;
    let lRpcEndpointName;
    let lRpcSdpId;
    let lRpcVcId;
    let lRpcForceSwitchover;
    for (var i = 0; i < rootChildren.getLength(); i++) {
        let child = rootChildren.item(i);
        if (child.getLocalName() == "device-id") {
            lRpcDeviceId = child.getTextContent();
        } else if (child.getLocalName() == "endpoint-name") {
            lRpcEndpointName = child.getTextContent();
        } else if (child.getLocalName() == "sdp-id") {
            lRpcSdpId = child.getTextContent();
        } else if (child.getLocalName() == "vc-id") {
            lRpcVcId = child.getTextContent();
        }  else if (child.getLocalName() == "force-switchover") {
            lRpcForceSwitchover = child.getTextContent();
        }
    }

    // Input validation
    if (!lRpcDeviceId || !lRpcEndpointName || !lRpcSdpId || !lRpcVcId) {
        lError = "Input missing device-id, endpoint-name, sdp-id or vc-id.";
        this.sfLogger.error("nfmpRedundancyForceSwitchover:   " + lError);
        return utilityService.buildErrorActionResponse(lError);
    }
    let lDevInfo = this.getTypeVersionMediation(lRpcDeviceId);
    if (lDevInfo["mediation"] !== "nfmp") {
        lError = "This RPC is only applicable to NFM-P node";
        this.sfLogger.error("getNfmpSdpRedundancyActiveState:   " + lError);
        return utilityService.buildErrorActionResponse(lError);
    }

    let lEndpointParentFdn = "svc-mgr:service-" + lSvcMgrId + ":" + lRpcDeviceId;
    let lEpDistinguishedName = lEndpointParentFdn + ":endpoint-" + lRpcEndpointName;
    let lEpClassName = serviceType + ".Endpoint";

    let lPayload = {
        "distinguishedName": lEpDistinguishedName,
        "configInfo": {},
        "objectFullName": lEpDistinguishedName
    }
    if (lRpcForceSwitchover == "false") {
        lRpcSdpId = 0;
        lRpcVcId = 0;
    }
    lPayload["configInfo"][lEpClassName] = {
        "displayedName": lRpcEndpointName,
        "forceSwitchOver": "doAction",
        "switchOverSdpBindingPathId": lRpcSdpId,
        "switchOverSdpFecId": "0",
        "switchOverSdpBindingVcId": lRpcVcId
    }

    let depResponse = nfmpFwk.post("/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true", lPayload);
    if (!(depResponse.success && depResponse["response"])) {
        lError = "Fail to perform the switchover action: " + JSON.stringify(depResponse);
        this.sfLogger.error("nfmpRedundancyForceSwitchover:   " + lError);
        return utilityService.buildErrorActionResponse(lError);
    }

    return utilityService.buildOkActionResponse();
}

/*
   function: getNfmpSdpRedundancyActiveState
    since: NSP 23.11
    short_description:
    input:
        input:
          description: This object contains information about action input and contains information about an intent configuration, required network state, current topology, and Encrypted intent configuration. Please see https://network.developer.nokia.com/learn/22_6/network-programmability-automation-frameworks/network-automation/nsp-intent-manager-framework/im-apis-mapping-script-implementation/im-javascript-common-objects/syncinputinput/?highlight=input
          type: ActionInput
          mandatory: True
        actionNamingSpace:
          type: String
          description: Action naming space
          mandatory: True
    output:
      rpcResults:
        type: list sdp
        description: list of SDP on the intent target service site.
    output_on_error:
      rpcResults:
        type: string
        description: on error utilityService.buildErrorActionResponse("someString") is used to generate error.
     examples:
      "rpc get-nfmp-sdp-redundancy-active-state": |
        return sfUtils.getNfmpSdpRedundancyActiveState(input, "redundant-eline-action");
*/
ServiceFulfillmentIntentUtils.prototype.getNfmpSdpRedundancyActiveState = function (input, operModelSvcType, aInNspRestconfFwk, actionNamingSpace) {
    this.sfLogger.debug("getNfmpSdpRedundancyActiveState   input:   " + JSON.stringify(input));
    let lError;

    let fetchResp = aInNspRestconfFwk.getServiceRootElements(operModelSvcType, input.getTarget(), "name;services;id");
    let lTargetSvcName;
    if (fetchResp) {
        lTargetSvcName = fetchResp.name;
    } else {
        lError = "getNfmpSdpRedundancyActiveState failed: cannot get service manager Id with intent target as" + input.getTarget();
        this.sfLogger.error("nfmpRedundancyForceSwitchover:   " + lError);
        return utilityService.buildErrorActionResponse(lError);
    }

    let lRpcDeviceId;
    let rootChildren = input.getActionTreeElement().getChildNodes();
    for (var i = 0; i < rootChildren.getLength(); i++) {
        let child = rootChildren.item(i);
        if (child.getLocalName() == "device-id") {
            lRpcDeviceId = child.getTextContent();
        }
    }

    let lSdpList;
    if (lRpcDeviceId) {
        let lDevInfo = this.getTypeVersionMediation(lRpcDeviceId);
        if (lDevInfo["mediation"] !== "nfmp") {
            lError = "This RPC is only applicable to NFM-P node" ;
            this.sfLogger.error("getNfmpSdpRedundancyActiveState:   " + lError);
            return utilityService.buildErrorActionResponse(lError);
        }

        let lPayload = {
            "fullClassName": "svt.SpokeSdpBinding",
            "filter": {
                "and": {
                    "equal": [
                        {"name": "serviceName", "value": lTargetSvcName},
                        {"name": "fromNodeId", "value": lRpcDeviceId}
                    ]
                }
            },
            "resultFilter": {
                "attribute": [
                    "objectFullName",
                    "txActiveState"
                ],
                "children": {}
            }
        }
        let lNfmpMediator = new MediatorFramework("NFMP");
        let lSdpResponse = lNfmpMediator.post("/v3/search", lPayload);
        if (lSdpResponse.success) {
            if(lSdpResponse["response"]) {
                lSdpResponse = JSON.parse(lSdpResponse["response"]);
                if (lSdpResponse["svt.SpokeSdpBinding"]) {
                    lSdpList = "";
                    if (Array.isArray(lSdpResponse["svt.SpokeSdpBinding"])) {
                        lSdpResponse["svt.SpokeSdpBinding"].forEach(function (aInSdp) {
                            lSdpList =
                                lSdpList + "<sdp xmlns=\"http://www.nokia.com/management-solutions/" + actionNamingSpace + "\">"
                                + "<full-name xmlns=\"http://www.nokia.com/management-solutions/" + actionNamingSpace + "\">"
                                + aInSdp["objectFullName"] + "</full-name>"
                                + "<active-state xmlns=\"http://www.nokia.com/management-solutions/" + actionNamingSpace + "\">"
                                + aInSdp["txActiveState"] + "</active-state>"
                                + "</sdp>"
                        })
                    } else {
                        lSdpList =
                            lSdpList + "<sdp xmlns=\"http://www.nokia.com/management-solutions/" + actionNamingSpace + "\">"
                            + "<full-name xmlns=\"http://www.nokia.com/management-solutions/" + actionNamingSpace + "\">"
                            + lSdpResponse["svt.SpokeSdpBinding"]["objectFullName"] + "</full-name>"
                            + "<active-state xmlns=\"http://www.nokia.com/management-solutions/" + actionNamingSpace + "\">"
                            + lSdpResponse["svt.SpokeSdpBinding"]["txActiveState"] + "</active-state>"
                            + "</sdp>"
                    }
                }
            }
        } else {
            lError = "getServiceSiteSdpBindings failed: " + JSON.stringify(lPayload);
            this.sfLogger.error("getNfmpSdpRedundancyActiveState:   " + lError);
            return utilityService.buildErrorActionResponse(lError);
        }
    } else {
        lError = "RPC input device-id not set" ;
        this.sfLogger.error("getNfmpSdpRedundancyActiveState:   " + lError);
        return utilityService.buildErrorActionResponse(lError);
    }

    if (lSdpList) {
        return lSdpList;
    } else {
        return utilityService.buildOkActionResponse();
    }
}

/*
   function: intentToNFMPMapperLeafList
    since: NSP 24.8
    short_description: helper function, intent model to device - leaf-list mapping
    input:
        aInNfmpListRoot:
          type: Object
          description: NFMP class attributes
          mandatory: True
        aInIntList:
          type: Object
          description: Intent policy object
          mandatory: True
        aInMaxListSize:
          type: int
          description: Maximum length of the list
          mandatory: True
        aInNfmpItemName:
          type: String
          description: Name of the NFMP list item
          mandatory: True
    output:
      device model:
        type: Object
        description: device model after translation
    examples:
      "intentToNFMPMapperLeafList": |
            this.sfUtils.intentToNFMPMapperLeafList(payload["vpls.Site"][0]["children-Set"]["vpls.SitePimSnooping"],
            siteObjMap["pim-snooping"]["group-policy"], 5, "groupPolicy");
*/
ServiceFulfillmentIntentUtils.prototype.intentToNFMPMapperLeafList = function (aInNfmpListRoot, aInIntList, aInMaxListSize, aInNfmpItemName) {
    if (aInIntList) {
        for (var  k = 1; k <= aInMaxListSize; k++) {
            if (aInIntList && aInIntList[k - 1]){
                aInNfmpListRoot[aInNfmpItemName + k] = aInIntList[k - 1];
            }
            else
                aInNfmpListRoot[aInNfmpItemName + k] = "";
        }
    } else {
        for (var  k = 1; k <= aInMaxListSize; k++) {
            aInNfmpListRoot[aInNfmpItemName + k] = "";
        }
    }

    return aInNfmpListRoot;
};

/*
   function: nfmpToIntentMapperLeafList
    since: NSP 24.8
    short_description: Reverse mapping - Map device model to intent model - leaf-list
    input:
        aInNfmpClassVal:
          type: Object
          description: NFMP class attributes
        aInIntLeafList:
          type: Object
          description: Current intent bgp policy object
          mandatory: True
        aInMaxListSize:
          type: int
          description: Maximum length of the list
          mandatory: True
        aInNfmpItemName:
          type: String
          description: Name of the NFMP list item
          mandatory: True
    examples:
      "nfmpToIntentMapperLeafList": |
            this.sfUtils.nfmpToIntentMapperLeafList(intentModel["site"]["pim-snooping"]["group-policy"], childClassVal, 5, "groupPolicy");

*/
ServiceFulfillmentIntentUtils.prototype.nfmpToIntentMapperLeafList = function (aInIntLeafList, aInNfmpClassVal, aInMaxListSize, aInNfmpItemName) {
    for (var  k = 1; k <= aInMaxListSize; k++) {
        if (aInNfmpClassVal[aInNfmpItemName + k] !== "" && aInNfmpClassVal[aInNfmpItemName + k] !== "N/A")
            aInIntLeafList.push(aInNfmpClassVal[aInNfmpItemName + k]);
    }
};

/*
   function: generateUrl
    short_description: helper function to construct url
    input:
        key:
            baseUrl: base url
                type: string
                mandatory: True
            queryStrings: query strings, if any in the url (zero or many)
                type: string/array
                mandatory: False
    output:
        value:
            type: string
            description: fully constructed url
*/
ServiceFulfillmentIntentUtils.prototype.generateUrl = function(baseUrl, queryStrings) {
    let url = baseUrl;
    if (queryStrings) {
        if (!Array.isArray(queryStrings))
            queryStrings = [queryStrings];
        if (queryStrings.length > 0) {
            url += "?" + queryStrings.join("&");
        }
    }
    return url;
}

/*
   function: retrieveUacObjects
    short_description: helper function to construct url
    input:
        key:
            baseUrl: input
                type: string
                mandatory: True
            intNeIdFn: function to retrieve ne-id list from intent config
                type: function
                mandatory: False
            intUrlNeIdFn: function to retrieve ne-id list from URL and intent config
                type: function
                mandatory: False
            intPutNeIdFn: function to retrieve ne-id list for put action from URL and intent config
                type: function
                mandatory: False
            intTypeName: input
                type: string
                mandatory: True
    output:
        value:
            type: list of string
            description: ne-id list
*/
ServiceFulfillmentIntentUtils.prototype.retrieveUacObjects = function(input, intNeIdFn, intUrlNeIdFn, intPutNeIdFn, intTypeName, intTargetName) {
    this.sfLogger.debug(intTypeName + " " + intTargetName + " " + "retrieveUacObjects: Calling retrieveUacObjects.");
    let startTime = new Date().getTime();
    function xml2object(xmlElement) {
        let lXml = Java.type("org.json.XML");
        let lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        let serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        let str = serializer.writeToString(xmlElement);
        let json = lXml.toJSONObject(str).toString();
        return JSON.parse(json);
    }

    let lActionName;
    let lActionUrl;
    let lIntentConfig;
    let lInputIntJson;
    let lInputPayload;
    let payloadIntKey;
    let payloadKeys;
    let lNeList;

    let rootChildren = input.getActionTreeElement().getChildNodes();
    for (var i = 0; i < rootChildren.getLength(); i++) {
        let child = rootChildren.item(i);
        if (child.getLocalName() == "action-name") {
            lActionName = child.getTextContent().toLowerCase();
        } else if (child.getLocalName() == "action-url") {
            lActionUrl = child.getTextContent();
            lActionUrl = decodeURIComponent(lActionUrl);
        } else if (child.getLocalName() == "intent-config") {
            lIntentConfig = child.getTextContent();
            lIntentConfig = JSON.parse(lIntentConfig);
        }
    }
    this.sfLogger.debug(intTypeName + " " + intTargetName + " " + "retrieveUacObjects: rpc input: \n"
                        + "action-name: " + lActionName + "\n"
                        + "action-url: " + lActionUrl + "\n"
                        + "intent-config: " + JSON.stringify(lIntentConfig));
    switch (lActionName) {
        case "post":
            // payload examples:
            // {
            //     "nsp-service-intent:intent": [
            //     {
            //         "service-name": "jun-epipe-clone-921",
            //         "intent-type": "epipe",
            //         "intent-type-version": "2",
            //         "olc-state": "saved",
            // or
            // {
            //     "intent": [
            //     {
            //         "service-name": "paulEpipeNeRbac",
            //         "intent-type": "epipe",
            //         "intent-type-version": "2",
            //         "olc-state": "deployed",

            if (lIntentConfig) {
                payloadKeys = Object.keys(lIntentConfig);
                for (let i = 0; i < payloadKeys.length; i++) {
                    if (payloadKeys[i] === "intent" || payloadKeys[i].lastIndexOf(":intent") > -1) {
                        payloadIntKey = payloadKeys[i];
                        break;
                    }
                }
                if (lIntentConfig[payloadIntKey] && lIntentConfig[payloadIntKey][0]["intent-specific-data"]) {
                    lNeList = intNeIdFn(lIntentConfig[payloadIntKey][0]["intent-specific-data"][intTypeName + ":" + intTypeName])
                }
            }

            break;

        case "put":
            lNeList = intPutNeIdFn(lActionUrl, lIntentConfig, xml2object);
            break;

        case "patch":
        case "delete":
            if (lIntentConfig) {
                if (lIntentConfig[intTypeName + ":" + intTypeName]) {
                    lInputPayload = lIntentConfig[intTypeName + ":" + intTypeName];
                } else {
                    lInputPayload = lIntentConfig;
                }
            }

            lNeList = intUrlNeIdFn(lActionName, lActionUrl, lInputPayload, xml2object);
            break;

        case "default":
            // lInputIntJson:
            // {
            //     "site-a": {
            //     "site-name": "jun-epipe-810",
            //         "device-id": "15.15.15.15"
            // },
            //     "xmlns": "urn:nokia:nsp:model:nsp-service-intent:services:epipe",
            //     "customer-id": 1,
            //     "site-b": "",
            //     "admin-state": "unlocked",
            //     "ne-service-id": 810,
            //     "sdp-details": ""
            // }
            lInputIntJson = xml2object(input.getIntentConfiguration())['configuration'][intTypeName];
            lNeList = intNeIdFn(lInputIntJson);
            break;

        default:
    }
    this.sfLogger.debug(intTypeName + " " + intTargetName + " " + "retrieveUacObjects: NE list for uac validation: " + lNeList);
    let endtTime = new Date().getTime();
    this.sfLogger.debug(intTypeName + " " + intTargetName + " " + "retrieveUacObjects: it took " + (endtTime - startTime) + " milliseconds");
    if (lNeList) {
        return lNeList;
    } else {
        return utilityService.buildOkActionResponse();
    }
}

/*
   function: versionCompare
    short_description: compare version of yang and the node
    input:
        key:
            supportedYangVersion: Version of the yang used to create the intent
                type: string
                mandatory: True
            siteId: Node ID
                type: string
                mandatory: True
    output:
        value:
            type: boolean
            description: Returns true if deviceVersion is older than yangVersion
*/
ServiceFulfillmentIntentUtils.prototype.versionCompare = function(supportedYangVersion, siteId) {

    let deviceInfo = this.getTypeVersionMediation(siteId);
    let deviceVersion = deviceInfo.version.substring(0, deviceInfo.version.lastIndexOf("."));
    let isDeviceVersionOld=false
    let deviceVersionSplit = deviceVersion.split(".")
    let yangVersionSplit = supportedYangVersion.split(".")
    if (parseInt(deviceVersionSplit[0]) == parseInt(yangVersionSplit[0]) ){
        if (parseInt(deviceVersionSplit[1]) < parseInt(yangVersionSplit[1]) ) 
          isDeviceVersionOld=true
      }
      else if (parseInt(deviceVersionSplit[0]) < parseInt(yangVersionSplit[0]))
        isDeviceVersionOld=true
    return isDeviceVersionOld
}
