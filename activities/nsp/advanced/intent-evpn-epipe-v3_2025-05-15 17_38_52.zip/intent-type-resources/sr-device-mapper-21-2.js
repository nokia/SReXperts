function SrDeviceMapper212(sfLogger) {
    SrDeviceMapper.call(this)
    if (sfLogger){
        this.sfLogger = sfLogger;
        this.srSvcFwk = new SrSvcFwk(sfLogger);
    }
}

SrDeviceMapper212.prototype = Object.create(SrDeviceMapper.prototype);
SrDeviceMapper212.prototype.constructor = SrDeviceMapper212;

/*
   function: mapToDeviceModel
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model
 */
SrDeviceMapper212.prototype.mapToDeviceModel = function (templateArgs, siteId, target, requestContext) {
    let payload = new SrDeviceMapper().mapToDeviceModel(templateArgs, siteId, target, requestContext);
    this.sfLogger.info("SrDeviceMapper212 Device:{} payload :{} ", siteId, JSON.stringify(payload));
    if (payload["bgp-evpn"] && payload["bgp-evpn"]["local-ac"]) {
        payload["bgp-evpn"]["local-attachment-circuit"] = [];
        payload["bgp-evpn"]["local-attachment-circuit"].push(payload["bgp-evpn"]["local-ac"]);
        delete payload["bgp-evpn"]["local-ac"];
    }
    if (payload["bgp-evpn"] && payload["bgp-evpn"]["remote-ac"]) {
        payload["bgp-evpn"]["remote-attachment-circuit"] = [];
        payload["bgp-evpn"]["remote-attachment-circuit"].push(payload["bgp-evpn"]["remote-ac"]);
        delete payload["bgp-evpn"]["remote-ac"];
    }
    return payload;
};

/*
   function: mapToIntentModel
    since: NSP 21.6
    short_description: Reverse mapping - Map device model to intent model
    input:
        deviceModel:
          type: Object
          description: Device config fetched
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
    output:
      intentModel:
        type: Object
        description: intent model after translation
 */
SrDeviceMapper212.prototype.mapToIntentModel = function (deviceModel, siteId) {
    let intentModel = new SrDeviceMapper().mapToIntentModel(deviceModel, siteId);
    if (deviceModel[0]["bgp-evpn"]) {
        if (deviceModel[0]["bgp-evpn"]["local-attachment-circuit"]) {
            intentModel["site"]["local-ac"] = deviceModel[0]["bgp-evpn"]["local-attachment-circuit"][0];
        }
        if (deviceModel[0]["bgp-evpn"]["remote-attachment-circuit"]) {
            intentModel["site"]["remote-ac"] = deviceModel[0]["bgp-evpn"]["remote-attachment-circuit"][0];
        }
    }
    return intentModel;
};
