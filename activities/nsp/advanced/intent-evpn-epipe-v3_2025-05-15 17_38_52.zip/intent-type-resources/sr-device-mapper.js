function SrDeviceMapper(sfLogger) {
    if (sfLogger){
        this.sfLogger = sfLogger;
        this.srSvcFwk = new SrSvcFwk(sfLogger);
    }
}
SrDeviceMapper.prototype.srSvcFwk = new SrSvcFwk();
SrDeviceMapper.prototype.sfLogger = new ServiceFulfillmentLogger();
SrDeviceMapper.prototype.sfUtils = new ServiceFulfillmentIntentUtils();

/*
   function: mapToDeviceModel
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model
 */
SrDeviceMapper.prototype.mapToDeviceModel = function (templateArgs, siteId, target, requestContext) {
    this.sfLogger.info("[EVPN-ELINE] mapToDeviceModel Device:{} templateArgs: {}", siteId, JSON.stringify(templateArgs));
    let service = {};
    service = this.srSvcFwk.svcToDevice(templateArgs, service, siteId, requestContext);

    if (templateArgs["sap-details"] && templateArgs["sap-details"]["sap"]) {
        service["sap"] = [];
        for (let  j = 0; j < templateArgs["sap-details"]["sap"].length; j++) {
            let sapAmi = templateArgs["sap-details"]["sap"][j];
            let sapDevice = {};
            sapDevice = this.srSvcFwk.sapToDevice(sapAmi, sapDevice);
            if (sapAmi.ingress) {
                this.srSvcFwk.mapAccessQosFilterToDevice(sapAmi.ingress, sapDevice, "ingress", siteId);
            }
            if (sapAmi.egress) {
                this.srSvcFwk.mapAccessQosFilterToDevice(sapAmi.egress, sapDevice, "egress", siteId);
            }
            service["sap"].push(sapDevice);
        }

    }

    service["bgp-evpn"] = {};
    service["bgp-evpn"].evi = templateArgs.evi;

    if (templateArgs["local-ac"]) {
        service["bgp-evpn"]["local-ac"] = {};
        service["bgp-evpn"]["local-ac"]["name"] = templateArgs["local-ac"]["name"];
        service["bgp-evpn"]["local-ac"]["eth-tag"] = templateArgs["local-ac"]["eth-tag"];
    }

    if (templateArgs["remote-ac"]) {
        service["bgp-evpn"]["remote-ac"] = {};
        service["bgp-evpn"]["remote-ac"]["name"] = templateArgs["remote-ac"]["name"];
        service["bgp-evpn"]["remote-ac"]["eth-tag"] = templateArgs["remote-ac"]["eth-tag"];
    }

    if (templateArgs["evpn-type"] === "vxlan") {
        service["vxlan"] = {};
        service["vxlan"]["instance"] = [];
        let vxlanDevice = {};
        vxlanDevice["vni"] = templateArgs.vxlan.vni;
        vxlanDevice["vxlan-instance"] = 1;
        service["vxlan"]["instance"].push(vxlanDevice);
        service["bgp-evpn"]["vxlan"] = [];
        vxlanDevice = {};
        vxlanDevice["bgp-instance"] = 1;
        vxlanDevice["vxlan-instance"] = 1;
        vxlanDevice["admin-state"] = "enable";
        if (templateArgs["ecmp"])
            vxlanDevice["ecmp"] = templateArgs["ecmp"];
        service["bgp-evpn"]["vxlan"].push(vxlanDevice);

        if (templateArgs["routed-vpls"]) {
            service["bgp-evpn"]["routes"] = {};
            service["bgp-evpn"]["routes"]["ip-prefix"] = {};
            service["bgp-evpn"]["routes"]["ip-prefix"]["advertise"] = true;
        }

        if (templateArgs.vxlan["bgp-instance"]) {
            if (!service["bgp"])
                service["bgp"] = [];
            let bgpConfig = {};
            bgpConfig["bgp-instance"] = 1;
            bgpConfig["route-distinguisher"] = templateArgs.vxlan["bgp-instance"]["route-distinguisher"];
            if(templateArgs.vxlan["bgp-instance"]["vsi-import"])
                bgpConfig["vsi-import"] = templateArgs.vxlan["bgp-instance"]["vsi-import"];
            if(templateArgs.vxlan["bgp-instance"]["vsi-export"])
                bgpConfig["vsi-export"] = templateArgs.vxlan["bgp-instance"]["vsi-export"];
            if (templateArgs.vxlan["bgp-instance"]["route-target"]) {
                bgpConfig["route-target"] = {};
                templateArgs.vxlan["bgp-instance"]["route-target"].forEach(function(intentRt) {
                    if (intentRt["target-type"] === "import-export") {
                        bgpConfig["route-target"]["import"] = "target:" + intentRt["target-value"];
                        bgpConfig["route-target"]["export"] = "target:" + intentRt["target-value"];
                    } else if (intentRt["target-type"] === "imp") {
                        bgpConfig["route-target"]["import"] = "target:" + intentRt["target-value"];
                    } else if (intentRt["target-type"] === "exp") {
                        bgpConfig["route-target"]["export"] = "target:" + intentRt["target-value"];
                    }
                })
            }

            service["bgp"].push(bgpConfig);
        }
    }

    if (templateArgs["evpn-type"] === "mpls") {
        service["bgp-evpn"]["mpls"] = [];
        let mplsConfig = {};
        mplsConfig["admin-state"] = "enable";
        mplsConfig["bgp-instance"] = 1;
        if (templateArgs["ecmp"])
            mplsConfig["ecmp"] = templateArgs["ecmp"];
        if (templateArgs.mpls) {
            mplsConfig["force-vc-forwarding"] = templateArgs.mpls["force-vc-forwarding"];

            mplsConfig["auto-bind-tunnel"] = templateArgs.mpls["auto-bind-tunnel"];

            if (templateArgs.mpls["bgp-instance"]) {
                if (!service["bgp"])
                    service["bgp"] = [];
                let bgpConfig = {};
                bgpConfig["bgp-instance"] = 1;
                bgpConfig["route-distinguisher"] = templateArgs.mpls["bgp-instance"]["route-distinguisher"];
                if (templateArgs.mpls["bgp-instance"]["vsi-import"])
                    bgpConfig["vsi-import"] = templateArgs.mpls["bgp-instance"]["vsi-import"];
                if (templateArgs.mpls["bgp-instance"]["vsi-export"])
                    bgpConfig["vsi-export"] = templateArgs.mpls["bgp-instance"]["vsi-export"];
                if (templateArgs.mpls["bgp-instance"]["route-target"]) {
                    bgpConfig["route-target"] = {};
                    templateArgs.mpls["bgp-instance"]["route-target"].forEach(function (intentRt) {
                        if (intentRt["target-type"] === "import-export") {
                            bgpConfig["route-target"]["import"] = "target:" + intentRt["target-value"];
                            bgpConfig["route-target"]["export"] = "target:" + intentRt["target-value"];
                        } else if (intentRt["target-type"] === "imp") {
                            bgpConfig["route-target"]["import"] = "target:" + intentRt["target-value"];
                        } else if (intentRt["target-type"] === "exp") {
                            bgpConfig["route-target"]["export"] = "target:" + intentRt["target-value"];
                        }
                    })
                }
                service["bgp"].push(bgpConfig);
            }
        }
        service["bgp-evpn"]["mpls"].push(mplsConfig);
    }

    this.sfLogger.info("[EVPN-ELINE] mapToDeviceModel Device:{} service:{}", siteId, JSON.stringify(service));
    return service;
};

/*
   function: yangPatchPayload
    since: NSP 21.6
    short_description: Forward mapping - Map intent model to device model
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        extraParams:
          type: Object
          description: Any extra attribute required for mapping can be passed in here.
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model in IETF yang patch payload
 */
SrDeviceMapper.prototype.yangPatchPayload = function (templateArgs, target, extraParams, siteId, requestContext) {
    return {
        "ietf-yang-patch:yang-patch": {
            "patch-id": "edit-epipe-1",
            "edit": [
                {
                    "edit-id": "config-epipe-1",
                    "target": "/epipe="+target,
                    "operation": "replace",
                    "value": this.mapToDeviceModel(templateArgs, siteId, target, requestContext)
                }
            ]
        }
    }
};

/*
   function: postDeploymentResync
    since: NSP 21.6
    short_description: generate md-resync payload for resync after deployment
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
        device:
          type: String
          description: NE system address
          mandatory: True
    output:
      mdResyncPayload:
        type: Object
        description: md-resync app re-sync payload
 */
SrDeviceMapper.prototype.postDeploymentResync = function (templateArgs, requestContext, device) {
    this.sfLogger.info("postDeploymentResync templateArgs : {}", JSON.stringify(templateArgs, null, 2));
    return [
        {
            "class-id": "nokia-state:/state/service/epipe",
            "sbi-instance-id": [
                "fdn:model:mdm:" + device + ":/state/service/epipe[service-name=\""+ templateArgs["site-name"] + "\"]"
            ]
        }
    ]
};

/*
   function: yangPatchDelete
    since: NSP 21.6
    short_description: Yang patch payload with operation delete
    input:
        templateArgs:
          type: Object
          description: Intent Site/Service object
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        extraParams:
          type: Object
          description: Any extra attribute required for mapping can be passed in here.
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
    output:
      srDeviceDeletePayload:
        type: Object
        description: MD-SR delete service using IETF yang patch
 */
SrDeviceMapper.prototype.yangPatchDelete = function (templateArgs, target, extraParams, siteId) {
    return {
        "ietf-yang-patch:yang-patch": {
            "patch-id": "edit-epipe-1",
            "edit": [
                {
                    "edit-id": "config-epipe-1",
                    "target": "/epipe="+target,
                    "operation": "remove"
                }
            ]
        }
    }
};

/*
   function: populateSources
    since: NSP 21.6
    short_description: Populate device specific sources (nsp-model:sources) for md-resync app
    description:
        - prior deployment set MDM device source to nsp site object
        - Its used by md-resync app after deployment
    input:
        svcObj:
          type: Object
          description: Intent Service object
          mandatory: True
        deviceName:
          type: String
          description: NE system address
          mandatory: True
        siteObj:
          type: Object
          description: Intent Site object
          mandatory: True
        topology:
          type: Object
          description: IM Topology object
          mandatory: True
        target:
          type: String
          description: Intent target
          mandatory: False
        intentTypeName:
          type: String
          description: Intent-type name
          mandatory: True
 */
SrDeviceMapper.prototype.populateSources = function (svcObj, deviceName, siteObj, topo, target, intentTypeName) {
    //SVC source - NSPD-283845/NSPF-273681
    if (!svcObj["@"]) svcObj["@"] = {"nsp-model:sources": []};
    if (!svcObj["@"]["nsp-model:sources"]) svcObj["@"]["nsp-model:sources"] = [];
    svcObj["@"]["nsp-model:sources"].push("fdn:yang:nsp-service-intent:/nsp-service-intent:intent-base/intent[service-name='" + target + "'][intent-type='" + intentTypeName + "']");

    let siteSources = [
        "fdn:yang:nsp-network:/nsp-network:network/node[node-id='{deviceName}']/node-root/nokia-conf:/configure/service/epipe[service-name='{target}']",
        "fdn:yang:nsp-network:/nsp-network:network/node[node-id='{deviceName}']/node-root/nokia-state:/state/service/epipe[service-name='{target}']",
        "fdn:app:mdm-ami-cmodel:" + deviceName + ":service:Site:/service[service-id='{neServiceId}']",
        "fdn:model:mdm:" + deviceName + ":/state/service/epipe[service-name='{target}']",
        "fdn:model:mdm:" + deviceName + ":/configure/service/epipe[service-name='{target}']"
    ];

    if (!siteObj["@"]) {
        siteObj["@"] = {};
    }
    siteObj["@"]["svcSource"] = [];

    siteSources.forEach(function (lSiteSource) {
        lSiteSource = lSiteSource
            .replace("{deviceName}", deviceName)
            .replace("{target}", siteObj["site-name"])
            .replace("{neServiceId}", svcObj["ne-service-id"]);
        siteObj["@"]["svcSource"].push(lSiteSource);
    });
};

/*
   function: mapToIntentModel
    since: NSP 21.6
    short_description: Reverse mapping - Map device model to intent model
    input:
        deviceModel:
          type: Object
          description: Device config fetched
          mandatory: True
        siteId:
          type: String
          description: NE system address
          mandatory: True
    output:
      intentModel:
        type: Object
        description: intent model after translation
 */
SrDeviceMapper.prototype.mapToIntentModel = function (deviceModel, siteId) {
    deviceModel = deviceModel[0];
    this.sfLogger.info("[EVPN-ELINE] mapToIntentModel siteId: {} deviceModel : {}",siteId, JSON.stringify(deviceModel, null, 2));
    let intentModel = {};
    intentModel["service"] = {};
    intentModel["site"] = {};
    intentModel["sdp"] = [];

    intentModel["site"]["device-id"] = siteId;
    intentModel["site"]["site-name"] = deviceModel["service-name"];
    intentModel["site"]["description"] = deviceModel["description"];
    intentModel["service"]["ne-service-id"] = deviceModel["service-id"];
    intentModel["site"].mtu = deviceModel["service-mtu"];
    this.srSvcFwk.deviceToSvc(intentModel["service"], deviceModel);

    if (deviceModel["sap"]){
        if (!intentModel["site"]["sap-details"])
            intentModel["site"]["sap-details"] = {};
        if (!intentModel["site"]["sap-details"]["sap"])
            intentModel["site"]["sap-details"]["sap"] = [];
        for (let  j = 0; j < deviceModel["sap"].length; j++) {
            let intentSap = {};
            this.srSvcFwk.deviceToSap(intentSap, deviceModel["sap"][j]);
            if (typeof (deviceModel["sap"][j].ingress) !== "undefined" && deviceModel["sap"][j].ingress !== null) {
                this.srSvcFwk.mapDeviceToAccessQosFilter(intentSap, deviceModel["sap"][j], "ingress");
            }
            if (typeof (deviceModel["sap"][j].egress) !== "undefined" && deviceModel["sap"][j].egress !== null) {
                this.srSvcFwk.mapDeviceToAccessQosFilter(intentSap, deviceModel["sap"][j], "egress");
            }
            intentModel["site"]["sap-details"]["sap"].push(intentSap);
        }
    }

    let lEvpnType = "mpls";
    if (deviceModel["bgp-evpn"]){
        intentModel["site"]["evi"] = deviceModel["bgp-evpn"]["evi"];
        if (deviceModel["bgp-evpn"]["local-ac"]){
            intentModel["site"]["local-ac"] = deviceModel["bgp-evpn"]["local-ac"];
        }
        if (deviceModel["bgp-evpn"]["remote-ac"]){
            intentModel["site"]["remote-ac"] = deviceModel["bgp-evpn"]["remote-ac"];
        }

        if (deviceModel["bgp-evpn"]["vxlan"]){
            lEvpnType = "vxlan";
            if (!intentModel["site"]["vxlan"])
                intentModel["site"]["vxlan"] = {};
            if (deviceModel["vxlan"] && deviceModel["vxlan"]["instance"])
                intentModel["site"]["vxlan"]["vni"] = deviceModel["vxlan"]["instance"][0]["vni"];
            intentModel["site"]["ecmp"] = deviceModel["bgp-evpn"]["vxlan"]["ecmp"]
            intentModel["service"]["evpn-type"] = lEvpnType;
        }

        if (deviceModel["bgp-evpn"] && deviceModel["bgp-evpn"]["routes"] && deviceModel["bgp-evpn"]["routes"]["ip-prefix"]
            && deviceModel["bgp-evpn"]["routes"]["ip-prefix"]["advertise"])
            intentModel["site"]["routed-vpls"] = true;

        if (deviceModel["bgp-evpn"]["mpls"] && deviceModel["bgp-evpn"]["mpls"][0]){
            if (!intentModel["site"]["mpls"])
                intentModel["site"]["mpls"] = {};
            intentModel["site"]["ecmp"] = deviceModel["bgp-evpn"]["mpls"][0]["ecmp"];
            intentModel["site"]["mpls"]["force-vc-forwarding"] = deviceModel["bgp-evpn"]["mpls"][0]["force-vc-forwarding"];
            intentModel["site"]["mpls"]["auto-bind-tunnel"] = deviceModel["bgp-evpn"]["mpls"][0]["auto-bind-tunnel"];
            intentModel["service"]["evpn-type"] = lEvpnType;
        }
    }

    if (deviceModel["bgp"] && deviceModel["bgp"][0]){
        if (!intentModel["site"][lEvpnType])
            intentModel["site"][lEvpnType] = {};
        if (!intentModel["site"][lEvpnType]["bgp-instance"])
            intentModel["site"][lEvpnType]["bgp-instance"] = {};
        intentModel["site"][lEvpnType]["bgp-instance"]["route-distinguisher"]  = deviceModel["bgp"][0]["route-distinguisher"];
        intentModel["site"][lEvpnType]["bgp-instance"]["route-target"] = [];
        if (deviceModel["bgp"][0]["route-target"]){
            if (deviceModel["bgp"][0]["route-target"]["import"] && deviceModel["bgp"][0]["route-target"]["export"] ){
                if (deviceModel["bgp"][0]["route-target"]["import"] === deviceModel["bgp"][0]["route-target"]["export"] ){
                    intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                        "target-type" : "import-export",
                        "target-value" : deviceModel["bgp"][0]["route-target"]["import"].replace("target:","")
                    });
                } else {
                    intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                        "target-type" : "imp",
                        "target-value" : deviceModel["bgp"][0]["route-target"]["import"].replace("target:","")
                    },{
                        "target-type" : "exp",
                        "target-value" : deviceModel["bgp"][0]["route-target"]["export"].replace("target:","")
                    });
                }
            }else if (deviceModel["bgp"][0]["route-target"]["import"] ){
                intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                    "target-type" : "imp",
                    "target-value" : deviceModel["bgp"][0]["route-target"]["import"].replace("target:","")
                });
            }else {
                intentModel["site"][lEvpnType]["bgp-instance"]["route-target"].push({
                    "target-type" : "exp",
                    "target-value" : deviceModel["bgp"][0]["route-target"]["export"].replace("target:","")
                });
            }
        }
        if (deviceModel["bgp"][0]["vsi-import"]){
            intentModel["site"][lEvpnType]["bgp-instance"]["vsi-import"] = deviceModel["bgp"][0]["vsi-import"];
        }
        if (deviceModel["bgp"][0]["vsi-export"]){
            intentModel["site"][lEvpnType]["bgp-instance"]["vsi-export"] = deviceModel["bgp"][0]["vsi-export"];
        }
    };

    this.sfLogger.debug("[EVPN-ELINE] mapToIntentModel intentModel {}", JSON.stringify(intentModel,null,2));
    return intentModel;
};

/*
   function: getDeviceKey
    since: NSP 21.6
    short_description: for given device model list object return its keys
    output:
      deviceListKeys:
        type: Object
        description: Device list object keys
 */
SrDeviceMapper.prototype.getDeviceKey = function () {
    return function (listName) {
        switch (listName) {
            case "sap":
                return ["sap-id"];
            case "queue":
                return ["queue-id"];
            case "route-target":
                return ["target-type", "target-value"];
            case "policer":
                return ["policer-id"];
            case "scheduler":
                return ["scheduler-name"];
            case "priority":
                return ["priority-level"];
            case "bgp":
                return ["bgp-instance"]
            case "local-attachment-circuit":
                return ["name"]
            case "remote-attachment-circuit":
                return ["name"]
            case "local-ac":
                return ["name"]
            case "remote-ac":
                return ["name"]
            case "mpls":
                return ["bgp-instance"]
            case "vxlan":
                return ["bgp-instance"]
            case "instance":
                return ["vxlan-instance"]
            default:
                return null;
        }
    };
};
