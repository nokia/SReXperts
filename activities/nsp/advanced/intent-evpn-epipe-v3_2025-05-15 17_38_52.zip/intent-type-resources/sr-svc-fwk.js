/*
*
* The intent of this framework is to provide vendor
* specific conversion for MD-SF yang files
*
*/
load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
load({script: resourceProvider.getResource('sf-utils.js'), name: 'util-fwk'});

function SrSvcFwk(sfLogger) {
    this.nfmpFwk = new MediatorFramework("NFMP");
    if (sfLogger){
        this.sfLogger = sfLogger;
        this.nspRestconfFwk = new NspRestconfFwk(sfLogger);
        this.sfUtils = new ServiceFulfillmentIntentUtils(sfLogger);
    }
}

SrSvcFwk.prototype.nfmpFwk = null;
SrSvcFwk.prototype.customerInfo = null;
SrSvcFwk.prototype.sfLogger = new ServiceFulfillmentLogger();
SrSvcFwk.prototype.nspRestconfFwk = new NspRestconfFwk();
SrSvcFwk.prototype.sfUtils = new ServiceFulfillmentIntentUtils();

// MD-SR

/*
   function: mapAccessQosFilterToDevice
    since: NSP 21.6
    short_description: MD-SR map intent model to device model - QoS and filter
    input:
        sapXgressAmi:
          type: Object
          description: Intent QoS object
          mandatory: True
        sapDevice:
          type: Object
          description: Existing device object
          mandatory: True
        direction:
          type: String
          description: ingress/egress
          mandatory: True
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model with QoS and filter
    examples:
      "mapAccessQosFilterToDevice": |
        this.srSvcFwk.mapAccessQosFilterToDevice(sapAmi.ingress, sapDevice, "ingress");
 */
SrSvcFwk.prototype.mapAccessQosFilterToDevice = function (sapXgressAmi, sapDevice, direction, siteId, lDeviceInfo) {
    if(lDeviceInfo===undefined) { lDeviceInfo = this.sfUtils.getTypeVersionMediation(siteId) };
    this.sfLogger.debug("[SR-SVC-FWK] mapAccessQosFilterToDevice  direction: {} sapXgressAmi : {}", direction, JSON.stringify(sapXgressAmi));
    let xGressDevice = {};
    let lIsIxrR6OrENode = this.sfUtils.isIxrR6OrENode(siteId, lDeviceInfo);
    let lIsIxr6Node = this.sfUtils.isIxr6Node(siteId, lDeviceInfo);

    if (direction !== "ingress" && direction !== "egress") {
        this.sfLogger.error(null, "[SR-SVC-FWK] Wrong direction argument passed in mapQosToDeviceModel");
        return;
    }

    sapDevice[direction] = xGressDevice;

    if (sapXgressAmi.queueGroupRedirectList !== null) {
        xGressDevice["queue-group-redirect-list"] = sapXgressAmi.queueGroupRedirectList;
    }

    if (direction === "ingress") {
        if (lIsIxrR6OrENode) {
            if (sapXgressAmi["aggregate-policer"]) {
                xGressDevice["aggregate-policer"] = sapXgressAmi["aggregate-policer"];
            }
            if (sapXgressAmi["vlan-manipulation"]) {
                xGressDevice["vlan-manipulation"] = sapXgressAmi["vlan-manipulation"];    
            }
        }
    } else if (direction === "egress"){
        if (lIsIxrR6OrENode) {
            xGressDevice["percent-agg-rate"] = sapXgressAmi["percent-agg-rate"];
            xGressDevice["vlan-manipulation"] = sapXgressAmi["vlan-manipulation"];
        }
        if (sapXgressAmi["agg-rate"]) {
            xGressDevice["agg-rate"] = {};
            if (sapXgressAmi["agg-rate"].rate) {
                xGressDevice["agg-rate"]["rate"] = parseInt(sapXgressAmi["agg-rate"].rate);
            }
            if (lIsIxrR6OrENode) {
                xGressDevice["agg-rate"]["cir"] = sapXgressAmi["agg-rate"]["cir"];
            }
        }
    }

    if (sapXgressAmi.qos) {
        let sapXgressQosDevice = {};
        xGressDevice["qos"] = sapXgressQosDevice;
        if (sapXgressAmi.qos["match-qinq-dot1p"]) {
            sapXgressQosDevice["match-qinq-dot1p"] = sapXgressAmi.qos["match-qinq-dot1p"];
        }

        if (sapXgressAmi.qos["qinq-mark-top-only"]) {
            sapXgressQosDevice["qinq-mark-top-only"] = sapXgressAmi.qos["qinq-mark-top-only"];
        }

        let sapXgressAmiQosSapXgress;
        if (direction === "ingress") {
            sapXgressAmiQosSapXgress = sapXgressAmi.qos["sap-ingress"];
        } else {
            sapXgressAmiQosSapXgress = sapXgressAmi.qos["sap-egress"];
        }

        if (sapXgressAmiQosSapXgress) {
            let sapXgressQosSapXgressDevice = {};
            if (sapXgressAmiQosSapXgress["policy-name"]) {
                sapXgressQosSapXgressDevice["policy-name"] = sapXgressAmiQosSapXgress["policy-name"];
            }
            if (sapXgressAmiQosSapXgress["queuing-type"]) {
                sapXgressQosSapXgressDevice["queuing-type"] = sapXgressAmiQosSapXgress["queuing-type"];
            }
            sapXgressQosDevice["sap-" + direction] = sapXgressQosSapXgressDevice;

            if (sapXgressAmiQosSapXgress.overrides) {
                sapXgressQosSapXgressDevice["overrides"] = {};
                if (sapXgressAmiQosSapXgress.overrides.queue) {
                    sapXgressQosSapXgressDevice["overrides"]["queue"] = [];
                    for (var  index = 0; index < sapXgressAmiQosSapXgress.overrides.queue.length; index++) {
                        let queueAmi = sapXgressAmiQosSapXgress.overrides.queue[index];
                        let queueDevice = {};
                        queueDevice["queue-id"] = queueAmi["queue-id"];
                        queueDevice["cbs"] = this.sfUtils.convertToString(queueAmi.cbs);
                        queueDevice["mbs"] = this.sfUtils.convertToString(queueAmi.mbs);
                        if (queueAmi["rate"]) {
                            queueDevice["rate"] = {};
                            queueDevice["rate"]["pir"] = this.sfUtils.convertToString(queueAmi["rate"]["pir"]);
                            queueDevice["rate"]["cir"] = this.sfUtils.convertToString(queueAmi["rate"]["cir"]);
                        }
                        sapXgressQosSapXgressDevice["overrides"]["queue"].push(queueDevice);
                    }
                }

                if (sapXgressAmiQosSapXgress.overrides.policer) {
                    sapXgressQosSapXgressDevice["overrides"]["policer"] = [];
                    for (var  index = 0; index < sapXgressAmiQosSapXgress.overrides.policer.length; index++) {
                        let policerAmi = sapXgressAmiQosSapXgress.overrides.policer[index];
                        let policerDevice = {};
                        policerDevice["policer-id"] = policerAmi["policer-id"];
                        policerDevice["cbs"] = this.sfUtils.convertToString(policerAmi.cbs);
                        policerDevice["mbs"] = this.sfUtils.convertToString(policerAmi.mbs);
                        policerAmi["stat-mode"] ? policerDevice["stat-mode"] = policerAmi["stat-mode"] : policerDevice["stat-mode"] = null;
                        if (policerAmi["rate"])
                            policerDevice["rate"] = policerAmi["rate"];
                        else if (policerAmi["percent-rate"])
                            policerDevice["percent-rate"] = policerAmi["percent-rate"];
                        sapXgressQosSapXgressDevice["overrides"]["policer"].push(policerDevice);
                    }
                }
            }
        }

        if (direction === "egress" && lIsIxrR6OrENode) {
            if (!lIsIxr6Node) {
                if (sapXgressAmi["qos"]["vlan-qos-policy"]) {
                    sapXgressQosDevice["vlan-qos-policy"] = sapXgressAmi["qos"]["vlan-qos-policy"];
                }
            }
            if (sapXgressAmi["qos"]["egress-remark-policy"]) {
                sapXgressQosDevice["egress-remark-policy"] =
                    sapXgressAmi["qos"]["egress-remark-policy"];
            }
        }

        if (sapXgressAmi.qos["policer-control-policy"]) {
            if (sapXgressAmi.qos["policer-control-policy"]["policy-name"]) {
                sapXgressQosDevice["policer-control-policy"] = sapXgressAmi.qos["policer-control-policy"];
            }
        }

        if (sapXgressAmi.qos["scheduler-policy"]) {
            let schedulerPolicy = {};
            if (sapXgressAmi.qos["scheduler-policy"]["policy-name"]) {
                schedulerPolicy["policy-name"] = sapXgressAmi.qos["scheduler-policy"]["policy-name"];
                if (sapXgressAmi.qos["scheduler-policy"]["overrides"] && sapXgressAmi.qos["scheduler-policy"]["overrides"]["scheduler"]) {
                    let sapXgressSchOverAmi = sapXgressAmi.qos["scheduler-policy"]["overrides"]["scheduler"];
                    this.sfLogger.debug("[SR-SVC-FWK] mapAccessQosFilterToDevice sapXgressSchOverAmi" + JSON.stringify(sapXgressSchOverAmi));
                    schedulerPolicy["overrides"] = {};
                    schedulerPolicy["overrides"]["scheduler"] = [];
                    for (var  i = 0; i < sapXgressSchOverAmi.length; i++) {
                        let sapXgressSchDev = {};
                        sapXgressSchDev["scheduler-name"] = sapXgressSchOverAmi[i]["scheduler-name"];
                        if (sapXgressSchOverAmi[i]["rate"]) {
                            sapXgressSchDev["rate"] = {};
                            sapXgressSchDev["rate"]["pir"] = this.sfUtils.convertToString(sapXgressSchOverAmi[i]["rate"]["pir"]);
                            sapXgressSchDev["rate"]["cir"] = this.sfUtils.convertToString(sapXgressSchOverAmi[i]["rate"]["cir"]);
                        }
                        if (sapXgressSchOverAmi[i]["parent"]) {
                            sapXgressSchDev["parent"] = sapXgressSchOverAmi[i]["parent"];
                        }
                        schedulerPolicy["overrides"]["scheduler"].push(sapXgressSchDev);
                    }

                }
            }
            sapXgressQosDevice["scheduler-policy"] = schedulerPolicy;
        }
    }

    if (sapXgressAmi.filter && typeof (sapXgressAmi.filter) === "object" && Object.keys(sapXgressAmi.filter).length !== 0) {
        xGressDevice["filter"] = {"ip": sapXgressAmi.filter.ip, "ipv6": sapXgressAmi.filter.ipv6, "mac": sapXgressAmi.filter.mac};
    }

    this.sfLogger.debug("[SR-SVC-FWK] mapAccessQosFilterToDevice sapDevice" + JSON.stringify(sapDevice));
};

/*
   function: mapDeviceToAccessQosFilter
    since: NSP 21.6
    short_description: MD-SR map device model to intent model - Brownfield - QoS and filter
    input:
        sapXgressAmi:
          type: Object
          description: Existing intent object
          mandatory: True
        sapDevice:
          type: Object
          description: Device object
          mandatory: True
        direction:
          type: String
          description: ingress/egress
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with QoS and filter.
    examples:
      "mapAccessQosFilterToDevice": |
        this.srSvcFwk.mapDeviceToAccessQosFilter(interfaceDevice["sap"], lInterface["sap"][0], "ingress");
 */
SrSvcFwk.prototype.mapDeviceToAccessQosFilter = function (sapXgressAmi, sapDevice, direction) {
    this.sfLogger.debug("[SR-SVC-FWK] mapDeviceToAccessQosFilter direction: {}, sapDevice: {}", direction, JSON.stringify(sapDevice));
    if (direction !== "ingress" && direction !== "egress") {
        this.sfLogger.error(null, "[SR-SVC-FWK] Wrong direction argument passed in mapDeviceToAccessQosFilter");
        return;
    }
    if (sapDevice[direction]){
        if (!sapXgressAmi[direction]) sapXgressAmi[direction] = {};
        if(sapDevice[direction]["qos"])
            sapXgressAmi[direction]["qos"] = JSON.parse(JSON.stringify(sapDevice[direction]["qos"]));
        if(sapDevice[direction]["filter"])
            //mac filter as creating issues with pull from network
            if (sapDevice[direction]["filter"]["ip"] || sapDevice[direction]["filter"]["ipv6"]) {
                sapXgressAmi[direction]["filter"] = JSON.parse(JSON.stringify(sapDevice[direction]["filter"]));
            } else if (sapDevice[direction]["filter"]["mac"]) {
                sapXgressAmi[direction]["filter"] = JSON.parse(JSON.stringify(sapDevice[direction]["filter"]));
            }
        if (direction === "ingress" && sapDevice[direction]["aggregate-policer"]) {
            sapXgressAmi[direction]["aggregate-policer"] = JSON.parse(JSON.stringify(sapDevice[direction]["aggregate-policer"]));
        }
        if (direction === "egress" && sapDevice[direction]["agg-rate"]) {
            sapXgressAmi[direction]["agg-rate"] = JSON.parse(JSON.stringify(sapDevice[direction]["agg-rate"]));
        }
        if (direction === "egress" && sapDevice[direction]["percent-agg-rate"]) {
            sapXgressAmi[direction]["percent-agg-rate"] = JSON.parse(JSON.stringify(sapDevice[direction]["percent-agg-rate"]));
        }
        if (sapDevice[direction]["vlan-manipulation"]) {
            sapXgressAmi[direction]["vlan-manipulation"] = JSON.parse(JSON.stringify(sapDevice[direction]["vlan-manipulation"]));
        }
        sapXgressAmi["enable-filter"] = true;
        sapXgressAmi["enable-qos"] = true;

        //change scheduler-name as fist object for reconcile
        if (sapDevice[direction]["qos"] && sapDevice[direction]["qos"]["scheduler-policy"] && sapDevice[direction]["qos"]["scheduler-policy"]["overrides"] &&
            sapDevice[direction]["qos"]["scheduler-policy"]["overrides"]["scheduler"]){
            sapXgressAmi[direction]["qos"]["scheduler-policy"]["overrides"]["scheduler"] = [];
            sapDevice[direction]["qos"]["scheduler-policy"]["overrides"]["scheduler"].forEach(function (lScheduler) {
                sapXgressAmi[direction]["qos"]["scheduler-policy"]["overrides"]["scheduler"].push({
                    "scheduler-name" : lScheduler["scheduler-name"],
                    "rate" : lScheduler["rate"],
                    "parent" : lScheduler["parent"]
                })
            })
        }

        if (sapDevice[direction]["qos"] && sapDevice[direction]["qos"]["sap-"+direction] && sapDevice[direction]["qos"]["sap-"+direction]["overrides"]
            && sapDevice[direction]["qos"]["sap-"+direction]["overrides"]["policer"]){
            sapXgressAmi[direction]["qos"]["sap-"+direction]["overrides"]["policer"] = [];
            sapDevice[direction]["qos"]["sap-"+direction]["overrides"]["policer"].forEach(function (lPolicer) {
                let policerDevice = {
                    "policer-id" : lPolicer["policer-id"],
                    "cbs" : lPolicer["cbs"],
                    "mbs" : lPolicer["mbs"],
                    "stat-mode" : lPolicer["stat-mode"]
                }
                if (lPolicer["rate"])
                    policerDevice["rate"] = lPolicer["rate"];
                else if (lPolicer["percent-rate"])
                    policerDevice["percent-rate"] = lPolicer["percent-rate"];
                sapXgressAmi[direction]["qos"]["sap-"+direction]["overrides"]["policer"].push(policerDevice)
            })
        }
    }

};

/*
   function: mapEthCfmMepToDevice
    since: NSP 21.6
    short_description: MD-SR map intent model to device model - MEP
    input:
        mepAmi:
          type: Object
          description: Intent MEP object
          mandatory: True
        mepDevice:
          type: Object
          description: Existing device object
          mandatory: True
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model with MEP
    examples:
      "mapEthCfmMepToDevice": |
        "mep":[this.srSvcFwk.mapEthCfmMepToDevice(templateArgs.mep, {})]
 */
SrSvcFwk.prototype.mapEthCfmMepToDevice = function (mepAmi, mepDevice) {

    if (mepAmi["mac-address"])
        mepDevice["mac-address"] = mepAmi["mac-address"];
    if (mepAmi["mep-id"])
        mepDevice["mep-id"] = mepAmi["mep-id"];
    if (mepAmi["one-way-delay-threshold"])
        mepDevice["one-way-delay-threshold"] = mepAmi["one-way-delay-threshold"];
    if (mepAmi.ccm)
        mepDevice["ccm"] = mepAmi.ccm;
    if (mepAmi["md-admin-name"])
        mepDevice["md-admin-name"] = mepAmi["md-admin-name"];
    if (mepAmi["ma-admin-name"])
        mepDevice["ma-admin-name"] = mepAmi["ma-admin-name"];
    if (mepAmi["ccm-ltm-priority"])
        mepDevice["ccm-ltm-priority"] = mepAmi["ccm-ltm-priority"];
    if (mepAmi["eth-test"] && mepAmi["eth-test"]["admin-state"]) {
        mepDevice["eth-test"] = {};
    }
    if (mepAmi["admin-state"] === "unlocked") {
        mepDevice["admin-state"] = "enable";
    } else {
        mepDevice["admin-state"] = "disable";
    }
    return mepDevice;
};

/*
   function: sdpBindingToDevice
    since: NSP 21.6
    short_description: MD-SR map intent model to device model - SDP
    input:
        sdpAmi:
          type: Object
          description: Intent SDP object
          mandatory: True
        sdpDevice:
          type: Object
          description: Existing device object
          mandatory: True
        serviceId:
          type: String
          description: If vc-id is not overridden, service-id will be used as vc-id
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model with SDP
    examples:
      "sdpBindingToDevice": |
         this.srSvcFwk.sdpBindingToDevice(spokeSdpAmi, spokeSdpDevice, templateArgs["ne-service-id"]);
 */
SrSvcFwk.prototype.sdpBindingToDevice = function (sdpAmi, sdpDevice, serviceId, deviceId) {
    if (sdpAmi["vc-id"])
        sdpDevice["sdp-bind-id"] = sdpAmi["sdp-id"] + ":" + sdpAmi["vc-id"];
    else
        sdpDevice["sdp-bind-id"] = sdpAmi["sdp-id"] + ":" + serviceId;
    if (sdpAmi["admin-state"]) { //vprn - this property is not applicable
        if (sdpAmi["admin-state"] === "unlocked") {
            sdpDevice["admin-state"] = "enable";
        } else {
            sdpDevice["admin-state"] = "disable";
        }
    }
    if (sdpAmi.description)
        sdpDevice["description"] = sdpAmi.description + "";
    if (sdpAmi["vc-type"])
        sdpDevice["vc-type"] = sdpAmi["vc-type"];
    if (sdpAmi["fdb"])
        sdpDevice["fdb"] = sdpAmi["fdb"];
    if (sdpAmi["igmp-snooping"])
        sdpDevice["igmp-snooping"] = sdpAmi["igmp-snooping"];
    if (sdpAmi["dhcp"])
        sdpDevice["dhcp"] = sdpAmi["dhcp"];
    if (typeof sdpAmi["control-word"] !== "undefined") {
        sdpDevice["control-word"] = sdpAmi["control-word"];
    }
    if (typeof sdpAmi["collect-stats"] !== "undefined" && (!deviceId || !this.sfUtils.isIxrR6OrENode(deviceId))) {
        sdpDevice["collect-stats"] = sdpAmi["collect-stats"];
    }
    if (sdpAmi["force-vc-forwarding"])
        sdpDevice["force-vc-forwarding"] = sdpAmi["force-vc-forwarding"];
    if (sdpAmi["accounting-policy-id"])
        sdpDevice["accounting-policy"] = sdpAmi["accounting-policy-id"];
    if (typeof sdpAmi["vlan-vc-tag"] !== "undefined")
        sdpDevice["vlan-vc-tag"] = sdpAmi["vlan-vc-tag"];
    if (sdpAmi["entropy-label"]) {
        sdpDevice["entropy-label"] = sdpAmi["entropy-label"];
    } else if (typeof sdpAmi["hash-label"] !== "undefined") {
        sdpDevice["hash-label"] = {};
        if (sdpAmi["hash-label"]["signal-capability"]) {
            sdpDevice["hash-label"]["signal-capability"] =  sdpAmi["hash-label"]["signal-capability"];
        } 
    }
    if (typeof sdpAmi["pw-status"] !== "undefined") {
        sdpDevice["pw-status"] = {};
        sdpDevice["pw-status"]["signaling"] = sdpAmi["pw-status"]["signaling"];
        if (!deviceId || !this.sfUtils.isIxrR6OrENode(deviceId)) {
            sdpDevice["pw-status"]["block-on-peer-fault"] = sdpAmi["pw-status"]["block-on-peer-fault"];
            sdpDevice["pw-status"]["standby-signaling-slave"] = sdpAmi["pw-status"]["standby-signaling-slave"];
        }
    }
};

/*
   function: deviceToSdpBinding
    since: NSP 21.6
    short_description: MD-SR map device model to intent model - Brownfield - SDP
    input:
        sdpAmi:
          type: Object
          description: Existing intent object
          mandatory: True
        sdpDevice:
          type: Object
          description: Device object
          mandatory: True
        sourceSite:
          type: String
          description: Source NE id
          mandatory: True
        serviceId:
          type: String
          description: If vc-id is not overridden, service-id will be used as vc-id
          mandatory: False
    output:
      intentModel:
        type: Object
        description: Intent model with SDP.
    examples:
      "deviceToSdpBinding": |
        this.srSvcFwk.deviceToSdpBinding(intentSdp, deviceModel["spoke-sdp"][j], siteId, intentModel["service"]["ne-service-id"]);
 */
SrSvcFwk.prototype.deviceToSdpBinding = function (sdpAmi, sdpDevice, sourceSite, serviceId) {
    sdpAmi["source-device-id"] = sourceSite;
    let lSdpId = sdpDevice["sdp-bind-id"].split(":");
    if (lSdpId.length === 2) {
        sdpAmi["sdp-id"] = lSdpId[0];
        if (lSdpId != serviceId){
            sdpAmi["vc-id"] = lSdpId[1];
            sdpAmi["override-vc-id"] = true;
        } else {
            sdpAmi["override-vc-id"] = false;
        }

    }
    if (sdpDevice["admin-state"] === "disable")
        sdpAmi["admin-state"] = "locked";
    else
        sdpAmi["admin-state"] = "unlocked";
    sdpAmi.description = sdpDevice["description"];
    sdpAmi["vc-type"] = sdpDevice["vc-type"];

    if (sdpDevice["fdb"])
        sdpAmi["fdb"] = sdpDevice["fdb"];
    if (sdpDevice["igmp-snooping"])
        sdpAmi["igmp-snooping"] = sdpDevice["igmp-snooping"];
    if (sdpDevice["dhcp"])
        sdpAmi["dhcp"] = sdpDevice["dhcp"];
    if (typeof sdpDevice["control-word"] !== "undefined") {
        sdpAmi["control-word"] = sdpDevice["control-word"];
    }
    if (sdpDevice["force-vc-forwarding"])
        sdpAmi["force-vc-forwarding"] = sdpDevice["force-vc-forwarding"];
    if (typeof sdpDevice["collect-stats"] !== "undefined") {
        sdpAmi["collect-stats"] = sdpDevice["collect-stats"];
    }
    if (sdpDevice["accounting-policy"]) {
        sdpAmi["accounting-policy-id"] = sdpDevice["accounting-policy"];
    }
    if (sdpDevice["vlan-vc-tag"]) {
        sdpAmi["vlan-vc-tag"] = sdpDevice["vlan-vc-tag"];
    }
    if (sdpDevice["entropy-label"]) {
        sdpAmi["entropy-label"] = sdpDevice["entropy-label"];
    } else if (sdpDevice["hash-label"]) {
        sdpAmi["hash-label"] = sdpDevice["hash-label"];
    }
};

/*
   function: sapIdToDevice
    since: NSP 21.6
    short_description: Construct SAP id in SR format
    input:
        portId:
          type: String
          description: Port Name
          mandatory: True
        innerTag:
          type: String
          description: Inner VLAN tag
          mandatory: True
        outerTag:
          type: String
          description: Outer VLAN tag
          mandatory: True
    output:
      srSapId:
        type: String
        description: SR SAP id
 */
SrSvcFwk.prototype.sapIdToDevice = function (portId, innerTag, outerTag, cpId) {
    let sapId = null;
    if (portId) {
        portId = portId.replace(/^LAG/i, 'lag');//make lag prefix lowercase to handle old adp LAG-testLag2
        if (innerTag === 4095) {
            innerTag = "*"
        }
        if (outerTag === 4095) {
            outerTag = "*"
        }
        if (typeof cpId === "undefined" || cpId === null) {
            if ((!innerTag && !outerTag) || (innerTag == -1 && outerTag == -1)) {
                sapId = portId;
            } else if (typeof innerTag === "undefined" || innerTag === null || innerTag == -1) {
                sapId = portId + ':' + outerTag;
            } else {
                sapId = portId + ':' + outerTag + '.' + innerTag;
            }
        } else {
            //Connection Profile is set
            if ((typeof innerTag === "undefined" || innerTag === null || innerTag == -1) && 
                (typeof outerTag === "undefined" || outerTag === null || outerTag == -1)) {
                //Probably dot1Q
                sapId = portId + ':' + "cp-" + cpId;
            } else if ((typeof innerTag === "undefined" || innerTag === null || innerTag == -1) && outerTag != -1) {
                sapId = portId + ':' + outerTag + '.' + "cp-" + cpId;
            } else {
                sapId = portId + ':' + "cp-" + cpId + '.' + innerTag;    
            }
        }
    }
    return sapId;
};

/*
   function: sapToDevice
    since: NSP 21.6
    short_description: MD-SR map intent model to device model - SAP
    input:
        sapAmi:
          type: Object
          description: Intent SAP object
          mandatory: True
        sapDevice:
          type: Object
          description: Existing device object
          mandatory: True
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model with SAP
    examples:
      "sapToDevice": |
         sapDevice = this.srSvcFwk.sapToDevice(sapAmi, sapDevice);
 */
SrSvcFwk.prototype.sapToDevice = function (sapAmi, sapDevice) {
    if (sapAmi["port-id"]) {
        if (sapAmi["port-id"].toLowerCase().indexOf("lag") == -1 && sapAmi["port-id"].indexOf("Port ") !== -1){
            sapAmi["port-id"] = sapAmi["port-id"].replace("Port ", "");
        }
        sapDevice["sap-id"] = this.sapIdToDevice(sapAmi["port-id"], sapAmi["inner-vlan-tag"], sapAmi["outer-vlan-tag"], sapAmi["connection-profile-id"]);
    }

    if (sapAmi.description)
        sapDevice["description"] = sapAmi.description;

    if (sapAmi["admin-state"] === "unlocked") {
        sapDevice["admin-state"] = "enable";
    } else {
        sapDevice["admin-state"] = "disable";
    }

    if (typeof sapAmi["collect-stats"] !== "undefined")
        sapDevice["collect-stats"] = sapAmi["collect-stats"]

    if (sapAmi["accounting-policy-id"]) {
        sapDevice["accounting-policy"] = sapAmi["accounting-policy-id"];
    }

    if (sapAmi["multi-service-site"]) {
        sapDevice["multi-service-site"] = sapAmi["multi-service-site"];
    }

    if (sapAmi["cpu-protection"]) {
        sapDevice["cpu-protection"] = sapAmi["cpu-protection"];
    }

    return sapDevice;
};

/*
   function: deviceToSap
    since: NSP 21.6
    short_description: MD-SR map device model to intent model - Brownfield - SAP
    input:
        sapAmi:
          type: Object
          description: Existing intent object
          mandatory: True
        sapDevice:
          type: Object
          description: Device object
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with SAP.
    examples:
      "deviceToSap": |
        self.srSvcFwk.deviceToSap(interfaceDevice["sap"], lInterface["sap"][0]);
 */
SrSvcFwk.prototype.deviceToSap = function (sapAmi, sapDevice) {
    let lPort = sapDevice["sap-id"].split(":");
    sapAmi["port-id"] = lPort[0];
    if (lPort.length === 2) { //has vlan tags
        let lConnectionProfile = null;
        let lPortTag = lPort[1].split(".");
        if (lPortTag.length === 2) {
            if (lPortTag[1] === "*") {
                sapAmi["inner-vlan-tag"] = "4095";
            } else {
                if (lPortTag[1] && lPortTag[1].contains("cp-")) {
                    sapAmi["inner-vlan-tag"] = "-1";
                    let cpId = lPortTag[1].split("-");
                    if (cpId.length === 2) {
                        lConnectionProfile = cpId[1];    
                    }
                } else {
                    sapAmi["inner-vlan-tag"] = lPortTag[1];
                }
            }
        } else {
            sapAmi["inner-vlan-tag"] = "-1";
        }
        if (lPortTag[0] === "*") {
            sapAmi["outer-vlan-tag"] = "4095";
        } else {
            if (lPortTag[0] && lPortTag[0].contains("cp-")) {
                sapAmi["outer-vlan-tag"] = "-1";
                let cpId = lPortTag[0].split("-");
                if (cpId.length === 2) {
                    lConnectionProfile = cpId[1];
                }
            } else {
                sapAmi["outer-vlan-tag"] = lPortTag[0];
            }
        }
        if (lConnectionProfile) {
            sapAmi["connection-profile-id"] = lConnectionProfile;
        }
    } else {
        sapAmi["inner-vlan-tag"] = "-1";
        sapAmi["outer-vlan-tag"] = "-1";
    }
    sapAmi.description = sapDevice["description"];
    if (sapDevice["admin-state"] === "disable")
        sapAmi["admin-state"] = "locked";
    else
        sapAmi["admin-state"] = "unlocked";

    if (typeof sapDevice["collect-stats"] !== "undefined") {
        sapAmi["collect-stats"] = sapDevice["collect-stats"];
    }

    if (sapDevice["accounting-policy"]) {
        sapAmi["accounting-policy-id"] = sapDevice["accounting-policy"];
    }

    if (sapDevice["multi-service-site"])
        sapAmi["multi-service-site"] = sapDevice["multi-service-site"];

    if (sapDevice["cpu-protection"] && sapDevice["cpu-protection"]["policy-id"])
        sapAmi["cpu-protection"] = {"policy-id" : sapDevice["cpu-protection"]["policy-id"]};
};

/*
   function: svcToDevice
    since: NSP 21.6
    short_description: MD-SR map intent model to device model - Service level objects
    input:
        svcAmi:
          type: Object
          description: Intent SDP object
          mandatory: True
        service:
          type: Object
          description: Existing device object
          mandatory: True
        siteId:
          type: String
          description: Site ID
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      srDeviceModel:
        type: Object
        description: MD-SR device model with Service level properties set
    examples:
      "svcToDevice": |
        service = this.srSvcFwk.svcToDevice(templateArgs, service, siteId);
 */
SrSvcFwk.prototype.svcToDevice = function (svcAmi, service, siteId, requestContext) {

    if (svcAmi["site-name"])
        service["service-name"] = svcAmi["site-name"] + "";
    else
        service["service-name"] = svcAmi["service-name"] + "";

    if (siteId && !requestContext.get("audit")  && requestContext.get("topologyDeviceList") && requestContext.get("topologyDeviceList").indexOf(siteId.replaceAll(":", "-")) === -1){
        let serviceType = "vprn";

        if (requestContext.get("svcType") === "elan") serviceType = "vpls";
        else if (requestContext.get("svcType") === "eline") serviceType = "epipe";
        else if (requestContext.get("svcType") === "cline") serviceType = "cpipe";
        else if (requestContext.get("svcType") === "ies") serviceType = "ies";

        let url = this.nspRestconfFwk.constructURL("/restconf/data/network-device-mgr:network-devices/network-device=" + siteId + "/root/nokia-state:/state/service/" + serviceType + "=" +
            Java.type("java.net.URLEncoder").encode(service["service-name"], "UTF-8").replaceAll("\\+", "%20") + "?depth=2&fields=service-name", "GET");

        let lFetch;

        if (svcAmi["@"] && svcAmi["@"]["typeAndVersionMap"] && svcAmi["@"]["typeAndVersionMap"]["alienMediatorName"]){
            lFetch = new MediatorFramework(svcAmi["@"]["typeAndVersionMap"]["alienMediatorName"].replace("MDC","NSP")).fetch(url);
        } else {
            lFetch = this.nspRestconfFwk.mediatorFwk.fetch(url);
        }

        if (lFetch.success){
            throw new RuntimeException("Service already found on NE - " + siteId + " Service-name - "  + service["service-name"]);
        }
    }

    if (svcAmi["description"])
        service["description"] = svcAmi["description"] + "";

    if (svcAmi["customer-id"] && svcAmi["customer-id"] != "1")
        service["customer"] = this.srCheckCustomerAndDeploy(svcAmi["customer-id"], siteId, svcAmi["@"]["customerInfo"], svcAmi["@"]["typeAndVersionMap"]["alienMediatorName"]);
    else
        service["customer"] = "1";

    if (svcAmi["admin-state"] === "unlocked") {
        service["admin-state"] = "enable";
    } else {
        service["admin-state"] = "disable";
    }

    if (svcAmi["ne-service-id"]) {
        service["service-id"] = svcAmi["ne-service-id"];
    }

    if (svcAmi["mtu"]) {
        service["service-mtu"] = svcAmi["mtu"];
    }
    return service;
};

/*
   function: deviceToSvc
    since: NSP 21.6
    short_description: MD-SR map device model to intent model - Brownfield - Service level properties
    input:
        svcAmi:
          type: Object
          description: Existing intent object
          mandatory: True
        service:
          type: Object
          description: Device object
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with Service level properties.
    examples:
      "deviceToSvc": |
        this.srSvcFwk.deviceToSvc(intentModel["service"], deviceModel);
 */
SrSvcFwk.prototype.deviceToSvc = function (svcAmi, service) {
    svcAmi["customer-id"] = service["operObj"]["tenant"][0]["id"];
    if (service["admin-state"] === "enable")
        svcAmi["admin-state"] = "unlocked";
    else
        svcAmi["admin-state"] = "locked";
};

// NFMP
/*
   function: findNfmpMepCctID
    since: NSP 21.6
    short_description: Helper function to find objectFullName of ethernetoam.CcTest
    input:
        mgmtMaintDomainAdminName:
          type: String
          description: Maintenance Domain name
          mandatory: True
        mgmtMaintAssocAdminName:
          type: String
          description: Admin Name (/Maintenance Entity Group)
          mandatory: True
    output:
      objectFullName:
        type: String
        description: ObjectFullName of MEP
    examples:
      "findNfmpMepCctID": |
         let mep = this.srSvcUtils.findNfmpMepCctID(templateArgs.mep["md-admin-name"], templateArgs.mep["ma-admin-name"]);
 */
SrSvcFwk.prototype.findNfmpMepCctID = function (mgmtMaintDomainAdminName, mgmtMaintAssocAdminName, device) {
    let responseObj = null;
    let payload = {
        "fullClassName": "ethernetoam.MaintenanceDomain",
        "filter": {
            "and": {
                "equal": [
                    {"name": "mgmtMaintDomainAdminName", "value": mgmtMaintDomainAdminName},
                    {"name": "isLocal", "value": false}
                ]
            }
        },
        "resultFilter": {
            "attribute": [
                "objectFullName",
                "id",
                "isLocal"
            ],
            "children": {}
        }
    };
    let maintenanceDomainResults = this.nfmpFwk.post("/v3/search", payload);
    if (!(maintenanceDomainResults.success && maintenanceDomainResults["response"]))
        throw new RuntimeException("Didnt find MaintenanceDomain - " + mgmtMaintDomainAdminName);
    maintenanceDomainResults = JSON.parse(maintenanceDomainResults["response"]);
    if (maintenanceDomainResults["ethernetoam.MaintenanceDomain"]) {
        let payload = {
            "fullClassName": "ethernetoam.MaintAssociation",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "maintenanceDomainPointer",
                            "value": "network:" + device + ":" + maintenanceDomainResults["ethernetoam.MaintenanceDomain"]["objectFullName"]
                        },
                        {"name": "mgmtMaintAssocAdminName", "value": mgmtMaintAssocAdminName}
                    ]
                }
            },
            "resultFilter": {
                "attribute": [
                    "objectFullName"
                ],
                "children": {}
            }
        };
        let ccTestResults = this.nfmpFwk.post("/v3/search", payload);
        if (!(ccTestResults.success && ccTestResults["response"]))
            throw new RuntimeException("Didnt find mgmtMaintAssocAdminName - " + mgmtMaintAssocAdminName);
        ccTestResults = JSON.parse(ccTestResults["response"]);
        if (ccTestResults["ethernetoam.MaintAssociation"])
            responseObj = ccTestResults["ethernetoam.MaintAssociation"]["objectFullName"];
    }
    return responseObj;
};
/*
   function: findNFMPMepBySite
    since: NSP 22.11
    short_description: Helper function to find NFMP MEP by service site
    input:
        serviceSitePointer:
          type: String
          description: service site pointer
          mandatory: True
    output:
      nfmpMepObj:
        type: String
        description: nfmp mep object
 */
SrSvcFwk.prototype.findNFMPMepBySite = function (serviceSitePointer) {
    let payload = {
        "fullClassName": "ethernetoam.Mep",
        "filter": {
            "and": {
                "equal": [
                    {"name": "serviceSitePointer", "value": serviceSitePointer}
                ]
            }
        }
    };
    let ccTestResults = this.nfmpFwk.post("/v3/search", payload);
    if (ccTestResults.success && !(ccTestResults.response === "{}" || ccTestResults.response.indexOf("does not exist") !== -1)) {
        return JSON.parse(ccTestResults["response"]);
    } else
        return null;
};

/*
   function: findNfmpBvplsSvcMgrId
    since: NSP 21.6
    short_description: Helper function to find service manager id of b-vpls by service-name
    input:
        bVplsServiceName:
          type: String
          description: b-vpls service name
          mandatory: True
    output:
      serviceMgrId:
        type: String
        description: b-vpls serviceMgrId
    examples:
      "findNfmpBvplsSvcMgrId": |
         sitePayload["backboneSvcSitePointer"] = this.srSvcUtils.findNfmpBvplsSvcMgrId(siteObjMap["pbb"]["backbone-vpls"]["backbone-vpls-service-name"]);
 */
SrSvcFwk.prototype.findNfmpBvplsSvcMgrId = function (bVplsServiceName) {
    let payload = {
        "fullClassName": "vpls.BSite",
        "filter": {
            "equal": {
                "name": "displayedName",
                "value": bVplsServiceName
            }
        },
        "resultFilter": {
            "attribute": [
                "objectFullName"
            ],
            "children": {}
        }
    };
    let bVplsSite = this.nfmpFwk.post("/v3/search", payload);
    if (!(bVplsSite.success && bVplsSite["response"]))
        throw new RuntimeException("Didnt find B-VPLS Site - " + bVplsServiceName);
    bVplsSite = JSON.parse(bVplsSite["response"]);
    if (bVplsSite["vpls.BSite"]["objectFullName"])
        return bVplsSite["vpls.BSite"]["objectFullName"];
    else
        throw new RuntimeException("Didnt find B-VPLS Site - " + bVplsServiceName);
};

/*
   function: findNfmpBvplsDisplayedName
    since: NSP 21.6
    short_description: Helper function to find service name of b-vpls by objectFullName
    input:
        objectFullName:
          type: String
          description: b-vpls nfmp objectFullName
          mandatory: True
    output:
      serviceName:
        type: String
        description: b-vpls service name
    examples:
      "findNfmpBvplsDisplayedName": |
         "backbone-vpls-service-name": this.srSvcUtils.findNfmpBvplsDisplayedName(lSiteObj["backboneSvcSitePointer"]),
 */
SrSvcFwk.prototype.findNfmpBvplsDisplayedName = function (objectFullName) {
    let payload = {
        "fullClassName": "vpls.BSite",
        "filter": {
            "equal": {
                "name": "objectFullName",
                "value": objectFullName
            }
        },
        "resultFilter": {
            "attribute": [
                "displayedName", "objectFullName"
            ],
            "children": {}
        }
    };
    let bVplsSite = this.nfmpFwk.post("/v3/search", payload);
    if (!(bVplsSite.success && bVplsSite["response"]))
        throw new RuntimeException("Didnt find B-VPLS Site - " + objectFullName);
    bVplsSite = JSON.parse(bVplsSite["response"]);
    if (bVplsSite["vpls.BSite"]["displayedName"])
        return bVplsSite["vpls.BSite"]["displayedName"];
    else
        throw new RuntimeException("Didnt find B-VPLS Site - " + objectFullName);
};

/*
   function: IntentQoSToNFMPMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map intent model to device model - QoS and filter
    input:
        sapAmi:
          type: Object
          description: Intent SAP object
          mandatory: True
        sapDevice:
          type: Object
          description: Existing NFMP object
          mandatory: True
        direction:
          type: String
          description: ingress/egress
          mandatory: True
        deviceId:
          type: String
          description: device NE ID
          mandatory: True
        neSvcType:
          type: String
          description: service type
          mandatory: False
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with QoS and filter
    examples:
      "IntentQoSToNFMPMapper": |
         this.srSvcUtils.IntentQoSToNFMPMapper(sapAmi["ingress"], sapDevice, "ingress", deviceId);
 */
SrSvcFwk.prototype.IntentQoSToNFMPMapper = function (sapAmi, sapDevice, direction, deviceId, neSvcType, alienMediatorName, svcObj, requestContext) {
    let directionUpper = direction.charAt(0).toUpperCase() + direction.slice(1);
    let directionUpperFirstThreeChar = directionUpper.substring(0,3);
    if (direction === "ingress") {
        sapDevice[direction + "PolicyObjectPointer"] = "Access Ingress:1";
        sapDevice[direction + "SchedulerObjectPointer"] = "";
    } else if (direction === "egress") {
        sapDevice[direction + "PolicyObjectPointer"] = "Access Egress:1";
        sapDevice[direction + "SchedulerObjectPointer"] = "";
    }
    if (!sapDevice["children-Set"]) sapDevice["children-Set"] = {}
    sapDevice["children-Set"]["service." + directionUpper + "AccessPolicyQueueOverride"] = [];
    sapDevice["children-Set"]["service.Sap" + directionUpper + "PolicerOverride"] = [];
    sapDevice["children-Set"]["service." + directionUpper + "SchedulerPolicyEntryOverride"] = [];

    if (sapAmi["qos"]) {
        if (sapAmi["qos"]["scheduler-policy"] && sapAmi["qos"]["scheduler-policy"]["policy-name"]) {
            sapDevice[direction + "SchedulerObjectPointer"] = "Scheduler:" + sapAmi["qos"]["scheduler-policy"]["policy-name"];
        }

        if (sapAmi["qos"]["match-qinq-dot1p"]) {
            sapDevice[direction + "MatchQinqDot1pBits"] = sapAmi["qos"]["match-qinq-dot1p"];
        }

        if (direction === "egress") {
            sapDevice[direction + "QinqMarkTopBitsOnly"] = sapAmi["qos"]["qinq-mark-top-only"]
        }

        if (direction === "ingress" && sapAmi["qos"]["sap-ingress"]) {
            let qType = sapAmi["qos"]["sap-ingress"]["queuing-type"];
            let isSrs = this.sfUtils.isSrsNode(deviceId);
            let isSar = this.sfUtils.is7705Node(deviceId);
            if (!isSrs && !isSar) {
                if (qType === "shared") {
                    sapDevice["sharedQueueOn"] = true;
                    if (neSvcType && neSvcType !== "epipe") {
                        sapDevice["usesMultipointShared"] = false;
                    }
                } else if (qType === "multipoint-shared") {
                    sapDevice["sharedQueueOn"] = true;
                    sapDevice["usesMultipointShared"] = true;
                } else {
                    sapDevice["sharedQueueOn"] = false;
                    if (neSvcType && neSvcType !== "epipe") {
                        sapDevice["usesMultipointShared"] = false;
                    }
                }
            }
        }

        if (sapAmi["qos"]["scheduler-policy"]["overrides"] && sapAmi["qos"]["scheduler-policy"]["overrides"]["scheduler"]) {
            for (var  k = 0; k < sapAmi["qos"]["scheduler-policy"]["overrides"]["scheduler"].length; k++) {
                let overrideAmi = sapAmi["qos"]["scheduler-policy"]["overrides"]["scheduler"][k];
                let schedulerOverride = {
                    "schedulerPolicyEntryDisplayedName": overrideAmi["scheduler-name"],
                    "overrideFlags":{"bit":[]}
                };
                if (overrideAmi["rate"] && overrideAmi["rate"]["pir"] === "max") {
                    schedulerOverride["pir"] = "-1";
                    schedulerOverride["overrideFlags"]["bit"].push("pir")
                } else if (overrideAmi["rate"] && overrideAmi["rate"]["pir"]) {
                    schedulerOverride["pir"] = overrideAmi["rate"]["pir"];
                    schedulerOverride["overrideFlags"]["bit"].push("pir")
                } else
                    schedulerOverride["pir"] = "-2";

                if (overrideAmi["rate"] && overrideAmi["rate"]["cir"] === "max") {
                    schedulerOverride["cir"] = "-1";
                    schedulerOverride["overrideFlags"]["bit"].push("cir")
                } else if (overrideAmi["rate"] && overrideAmi["rate"]["cir"]) {
                    schedulerOverride["cir"] = overrideAmi["rate"]["cir"];
                    schedulerOverride["overrideFlags"]["bit"].push("cir")
                } else
                    schedulerOverride["cir"] = "-2";

                if (overrideAmi["parent"] && overrideAmi["parent"]["weight"]) {
                    schedulerOverride["overrideFlags"]["bit"].push("weight")
                    schedulerOverride["parentWeight"] = "weight" + overrideAmi["parent"]["weight"];
                }

                if (overrideAmi["parent"] && overrideAmi["parent"]["cir-weight"]) {
                    schedulerOverride["overrideFlags"]["bit"].push("cirWeight")
                    schedulerOverride["parentCirWeight"] = "weight" + overrideAmi["parent"]["cir-weight"];
                }

                sapDevice["children-Set"]["service." + directionUpper + "SchedulerPolicyEntryOverride"].push(schedulerOverride);
            }
        }

        if (sapAmi["qos"]["policer-control-policy"] && sapAmi["qos"]["policer-control-policy"]["policy-name"]){
            sapDevice[direction + "PolicerPolicyPointer"] = "hPolicing:" + sapAmi["qos"]["policer-control-policy"]["policy-name"];
            sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"] = [];
            if (sapAmi["qos"]["policer-control-policy"]["overrides"] && sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]){
                sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"] = {
                    "policerCtlOvrMaxRate" : "-2",
                    "policerCtlOvrMinMBSSep" : "-2",
                    "children-Set" : {}
                };
                sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"] = [];
                let PolicerLevelOverride = {};
                for (let  j = 1; j < 9; j++) {
                    PolicerLevelOverride[j] = {"level":"level"+j, "subProfPCtrlLvlOvrCumMBS": -2}
                }
                if (sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["max-rate"] && sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["max-rate"] === "max")
                    sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["policerCtlOvrMaxRate"]
                        = "-1";
                else if (sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["max-rate"])
                    sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["policerCtlOvrMaxRate"]
                        = sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["max-rate"];
                if (sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]){
                    if (sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["min-thresh-separation"] === "auto")
                        sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["policerCtlOvrMinMBSSep"] = "-1"
                    else if (sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["min-thresh-separation"])
                        sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["policerCtlOvrMinMBSSep"] =
                        sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["min-thresh-separation"]

                    if (sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["priority"]) {
                        sapAmi["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["priority"].forEach(function (lPriority) {
                            let nfmpPriorityClass = {
                                "level": "level" + lPriority["priority-level"]
                            };
                            if (lPriority["mbs-contribution"] === "auto")
                                nfmpPriorityClass["subProfPCtrlLvlOvrCumMBS"] = "-1"
                            else if (lPriority["mbs-contribution"])
                                nfmpPriorityClass["subProfPCtrlLvlOvrCumMBS"] = lPriority["mbs-contribution"]
                            else
                                nfmpPriorityClass["subProfPCtrlLvlOvrCumMBS"] = "-2"
                            PolicerLevelOverride[lPriority["priority-level"]] = nfmpPriorityClass
                        })
                    }
                } else {
                    sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["policerCtlOvrMinMBSSep"] = "-2"
                }

                Object.keys(PolicerLevelOverride).forEach(function (lKey) {
                    sapDevice["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"].push(PolicerLevelOverride[lKey])
                })

            } else if (requestContext && !requestContext.get("audit")) {
                if (svcObj["serviceMgrId"]) {
                    let payload = {
                        "fullClassName": "",
                        "filter": {
                            "and": {
                                "equal": [
                                    {
                                        "name": "svcComponentId",
                                        "value": svcObj["serviceMgrId"].replace("svc-mgr:service-","")
                                    },
                                    {
                                        "name": "siteId",
                                        "value": deviceId
                                    }
                                ]
                            }
                        }
                    }
                    payload["fullClassName"] = "service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"
                    let policerOverride = this.nfmpFwk.post("/v3/search", payload);
                    if (policerOverride.success && policerOverride.response && !(policerOverride.response === "{}" || policerOverride.response.indexOf("does not exist") !== -1)) {
                        policerOverride =  JSON.parse(policerOverride["response"]);
                        if (policerOverride["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]){
                            let deleteRes = this.nfmpFwk.delete("/v3/delete/" + encodeURIComponent(encodeURIComponent(policerOverride["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["objectFullName"])) + "?synchronousDeploy=true&clearOnDeployFailure=true");
                            if (!deleteRes.success) {
                                throw new RuntimeException(deleteRes.msg);
                            }
                        }
                    }
                }
            }
        } else {
            sapDevice[direction + "PolicerPolicyPointer"] = "";
            if (requestContext && !requestContext.get("audit")) {
                if (svcObj["serviceMgrId"]) {
                    let payload = {
                        "fullClassName": "",
                        "filter": {
                            "and": {
                                "equal": [
                                    {
                                        "name": "svcComponentId",
                                        "value": svcObj["serviceMgrId"].replace("svc-mgr:service-","")
                                    },
                                    {
                                        "name": "siteId",
                                        "value": deviceId
                                    }
                                ]
                            }
                        }
                    }
                    payload["fullClassName"] = "service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"
                    let policerOverride = this.nfmpFwk.post("/v3/search", payload);
                    if (policerOverride.success && policerOverride.response && !(policerOverride.response === "{}" || policerOverride.response.indexOf("does not exist") !== -1)) {
                        policerOverride =  JSON.parse(policerOverride["response"]);
                        if (policerOverride["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]){
                            let deleteRes = this.nfmpFwk.delete("/v3/delete/" + policerOverride["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]["objectFullName"] + "?synchronousDeploy=true&clearOnDeployFailure=true");
                            if (!deleteRes.success) {
                                throw new RuntimeException(deleteRes.msg);
                            }
                        }
                    }
                }
            }
        }

        if (sapAmi["qos"]["sap-" + direction] && sapAmi["qos"]["sap-" + direction]["policy-name"]) {
            let payload = {
                "filter": {
                    "and": {
                        "equal": [
                            {"name": "policyName", "value": sapAmi["qos"]["sap-" + direction]["policy-name"]},
                            {"name": "siteId", "value": deviceId}
                        ]
                    }
                },
                "resultFilter": {
                    "attribute": ["policyName", "id", "isLocal"],
                    "children": {}
                }
            };
            if (direction === "ingress") {
                payload["fullClassName"] = "aingr.Policy";
            } else {
                payload["fullClassName"] = "aengr.Policy";
            }
            let results = this.sfUtils.findNFMPGeneric(payload, sapAmi["qos"]["sap-" + direction]["policy-name"], alienMediatorName);
            if (results) {
                sapDevice[direction + "PolicyObjectPointer"] = "Access " + directionUpper + ":" + results;
            }
        }

        if (sapAmi["qos"]["sap-" + direction]["overrides"]) {
            if (sapAmi["qos"]["sap-" + direction]["overrides"]["queue"]) {
                for (var  k = 0; k < sapAmi["qos"]["sap-" + direction]["overrides"]["queue"].length; k++) {
                    let overrideAmi = sapAmi["qos"]["sap-" + direction]["overrides"]["queue"][k];
                    let queueOverride = {
                        "accessPolicyQueueId": overrideAmi["queue-id"]
                    };
                    if (overrideAmi["rate"]["pir"] === "max")
                        queueOverride["pir"] = "-1";
                    else
                        queueOverride["pir"] = overrideAmi["rate"]["pir"];

                    if (overrideAmi["rate"]["cir"] === "max")
                        queueOverride["cir"] = "-1";
                    else
                        queueOverride["cir"] = overrideAmi["rate"]["cir"];

                    if (overrideAmi["cbs"] === "default")
                        queueOverride["committedBurstSize"] = "-1";
                    else
                        queueOverride["committedBurstSize"] = overrideAmi["cbs"];

                    if (overrideAmi["mbs"] === "default")
                        queueOverride["maximumBurstSize"] = "-1";
                    else
                        queueOverride["maximumBurstSizeBytes"] = overrideAmi["mbs"];

                    sapDevice["children-Set"]["service." + directionUpper + "AccessPolicyQueueOverride"].push(queueOverride);
                }
            }
            if (sapAmi["qos"]["sap-" + direction]["overrides"]["policer"]) {
                for (var  k = 0; k < sapAmi["qos"]["sap-" + direction]["overrides"]["policer"].length; k++) {
                    let overrideAmi = sapAmi["qos"]["sap-" + direction]["overrides"]["policer"][k];
                    let policerOverride = {
                        "accessPolicyId": results,
                        "policerId": overrideAmi["policer-id"]
                    };

                    if (overrideAmi["cbs"] === "default")
                        policerOverride["cbs"] = "-1";
                    else
                        policerOverride["cbs"] = overrideAmi["cbs"];

                    if (overrideAmi["mbs"] === "default")
                        policerOverride["mbs"] = "-1";
                    else
                        policerOverride["mbs"] = overrideAmi["mbs"];

                    if (overrideAmi["rate"]) {
                        if (overrideAmi["rate"]["pir"] === "max")
                            policerOverride["pir"] = "-1"
                        else
                            policerOverride["pir"] = overrideAmi["rate"]["pir"]

                        if (overrideAmi["rate"]["cir"] === "max")
                            policerOverride["cir"] = "-1"
                        else
                            policerOverride["cir"] = overrideAmi["rate"]["cir"]
                    } else {
                        policerOverride["cir"] = "-2"
                        policerOverride["pir"] = "-2"
                    }

                    if (overrideAmi["percent-rate"]) {
                        policerOverride["pirPercent"] = overrideAmi["percent-rate"]["pir"]
                        policerOverride["cirPercent"] = overrideAmi["percent-rate"]["cir"]
                    } else {
                        policerOverride["pirPercent"] = "-2.0"
                        policerOverride["cirPercent"] = "-2.0"
                    }

                    if (overrideAmi["stat-mode"]){
                        if (overrideAmi["stat-mode"] === "no-stats") policerOverride["statsMode"] = "noStats";
                        else if (overrideAmi["stat-mode"] === "minimal") policerOverride["statsMode"] = "min";
                        else if (overrideAmi["stat-mode"] === "offered-profile-no-cir") policerOverride["statsMode"] = "offeredProfNoCir";
                        else if (overrideAmi["stat-mode"] === "offered-total-cir") policerOverride["statsMode"] = "offeredTotalCIR";
                        else if (overrideAmi["stat-mode"] === "offered-priority-no-cir") policerOverride["statsMode"] = "offeredPriNoCir";
                        else if (overrideAmi["stat-mode"] === "offered-profile-cir") policerOverride["statsMode"] = "offeredProfCir";
                        else if (overrideAmi["stat-mode"] === "offered-priority-cir") policerOverride["statsMode"] = "offeredPriCir";
                        else if (overrideAmi["stat-mode"] === "offered-limited-profile-cir") policerOverride["statsMode"] = "offeredLimitedProfCIR";
                        else if (overrideAmi["stat-mode"] === "offered-profile-capped-cir") policerOverride["statsMode"] = "offeredProfileCapCIR";
                        else if (overrideAmi["stat-mode"] === "offered-limited-capped-cir") policerOverride["statsMode"] = "offeredLimitedCapCIR";
                    } else
                        policerOverride["statsMode"] = "noOverride";

                    sapDevice["children-Set"]["service.Sap" + directionUpper + "PolicerOverride"].push(policerOverride);
                }
            }
        }
    }


    if (direction === "ingress" && sapAmi) this.IntentQoSToNFMPMapperIng(sapAmi, sapDevice, deviceId, neSvcType);
    if (direction === "egress" && sapAmi) this.IntentQoSToNFMPMapperEgr(sapAmi, sapDevice, deviceId, neSvcType);


    if (sapAmi && sapAmi["filter"] && Object.keys(sapAmi["filter"]).length > 0) {
        let payload = {
            "filter": {
                "and": {
                    "equal": [
                        {"name": "filterName", "value": ""},
                        {"name": "siteId", "value": deviceId}
                    ]
                }
            },
            "resultFilter": {
                "attribute": ["filterName", "id", "isLocal"],
                "children": {}
            }
        };

        if (sapAmi["filter"]["ip"]){
            payload["fullClassName"] = "aclfilter.IpFilter";
            payload["filter"]["and"]["equal"][0]["value"] = sapAmi["filter"]["ip"];
            let results = this.sfUtils.findNFMPGeneric(payload, sapAmi["filter"]["ip"], alienMediatorName);
            if (results) {
                sapDevice[direction + "FilterPointer"] = "IP Filter:" + results;
            }
        } else if (sapAmi["filter"]["mac"]){
            payload["fullClassName"] = "aclfilter.MacFilter";
            payload["filter"]["and"]["equal"][0]["value"] = sapAmi["filter"]["mac"];
            let results = this.sfUtils.findNFMPGeneric(payload, sapAmi["filter"]["mac"], alienMediatorName);
            if (results) {
                sapDevice[direction + "FilterPointer"] = "MAC Filter:" + results;
            }
        } else {
            sapDevice[direction + "FilterPointer"] = "";   
        }
        if (sapAmi["filter"]["ipv6"]){
            payload["fullClassName"] = "aclfilter.Ipv6Filter";
            payload["filter"]["and"]["equal"][0]["value"] = sapAmi["filter"]["ipv6"];
            let results = this.sfUtils.findNFMPGeneric(payload, sapAmi["filter"]["ipv6"], alienMediatorName);
            if (results) {
                sapDevice[direction + "Ipv6FilterPointer"] = "IPv6 Filter:" + results;
            }
        } else {
            sapDevice[direction + "Ipv6FilterPointer"] = "";    
        }
    } else {
        sapDevice[direction + "FilterPointer"] = "";
        sapDevice[direction + "Ipv6FilterPointer"] = "";
    }
};

function NFMPtoPolicerPolicyEntryOverride(lOverride) {
    let intentSchedulerOverr = {
        "policer-id": lOverride["policerId"].toString()
    };
    if (lOverride["cbs"] == "-1")
        intentSchedulerOverr["cbs"] = "default";
    else if (lOverride["cbs"] != "-2")
        intentSchedulerOverr["cbs"] = lOverride["cbs"].toString();

    if (lOverride["mbs"] == "-1")
        intentSchedulerOverr["mbs"] = "default";
    else if (lOverride["mbs"] != "-2")
        intentSchedulerOverr["mbs"] = lOverride["mbs"].toString();

    if (lOverride["pir"] != "-2" || lOverride["cir"] != "-2") {
        intentSchedulerOverr["rate"] = {}
        if (lOverride["pir"] == "-1")
            intentSchedulerOverr["rate"]["pir"] = "max";
        else if (lOverride["pir"] != "-2")
            intentSchedulerOverr["rate"]["pir"] = lOverride["pir"].toString();

        if (lOverride["cir"] == "-1")
            intentSchedulerOverr["rate"]["cir"] = "max";
        else if (lOverride["cir"] != "-2")
            intentSchedulerOverr["rate"]["cir"] = lOverride["cir"].toString();
    }

    if (lOverride["pirPercent"] != "-2.0" || lOverride["cirPercent"] != "-2.0") {
        intentSchedulerOverr["percent-rate"] = {}
        if (lOverride["pirPercent"] != "-2.0")
            intentSchedulerOverr["percent-rate"]["pir"] = lOverride["pirPercent"].toString();

        if (lOverride["cirPercent"] != "-2.0")
            intentSchedulerOverr["percent-rate"]["cir"] = lOverride["cirPercent"].toString();
    }

    if (lOverride["statsMode"] != "-1" || lOverride["statsMode"] != "noOverride") {
        if (lOverride["statsMode"] === "noStats") intentSchedulerOverr["stat-mode"] = "no-stats";
        else if (lOverride["statsMode"] === "min") intentSchedulerOverr["stat-mode"] = "minimal";
        else if (lOverride["statsMode"] === "offeredProfNoCir") intentSchedulerOverr["stat-mode"] = "offered-profile-no-cir";
        else if (lOverride["statsMode"] === "offeredTotalCIR") intentSchedulerOverr["stat-mode"] = "offered-total-cir";
        else if (lOverride["statsMode"] === "offeredPriNoCir") intentSchedulerOverr["stat-mode"] = "offered-priority-no-cir";
        else if (lOverride["statsMode"] === "offeredProfCir") intentSchedulerOverr["stat-mode"] = "offered-profile-cir";
        else if (lOverride["statsMode"] === "offeredPriCir") intentSchedulerOverr["stat-mode"] = "offered-priority-cir";
        else if (lOverride["statsMode"] === "offeredLimitedProfCIR") intentSchedulerOverr["stat-mode"] = "offered-limited-profile-cir";
        else if (lOverride["statsMode"] === "offeredProfileCapCIR") intentSchedulerOverr["stat-mode"] = "offered-profile-capped-cir";
        else if (lOverride["statsMode"] === "offeredLimitedCapCIR") intentSchedulerOverr["stat-mode"] = "offered-limited-capped-cir";
    }

    return intentSchedulerOverr;
}

function NFMPtoSchedulerPolicyEntryOverride(lOverride) {
    let intentSchedulerOverr = {
        "scheduler-name": lOverride["schedulerPolicyEntryDisplayedName"],
        "rate": {},
        "parent" : {}
    };
    if (lOverride["pir"] == "-1")
        intentSchedulerOverr["rate"]["pir"] = "max";
    else if (lOverride["pir"] != "-2")
        intentSchedulerOverr["rate"]["pir"] = lOverride["pir"].toString();

    if (lOverride["cir"] == "-1")
        intentSchedulerOverr["rate"]["cir"] = "max";
    else if (lOverride["cir"] != "-2")
        intentSchedulerOverr["rate"]["cir"] = lOverride["cir"].toString();

    if (lOverride["parentWeight"] && lOverride["parentWeight"] !== "weight0") {
        let weightArray = lOverride["parentWeight"].split('weight');
        if (weightArray.length === 2) {
            intentSchedulerOverr["parent"]["weight"] = parseInt(weightArray[1]);
        }
    }

    if (lOverride["parentCirWeight"] && lOverride["parentCirWeight"] !== "weight0") {
        let weightArray = lOverride["parentCirWeight"].split('weight');
        if (weightArray.length === 2) {
            intentSchedulerOverr["parent"]["cir-weight"] = parseInt(weightArray[1])
        }
    }

    return intentSchedulerOverr;
}

function NFMPtoAccessPolicyQueueOverride(lOverride) {
    let intentSchedulerOverr = {
        "queue-id": lOverride["accessPolicyQueueId"],
        "rate": {}
    };

    if (lOverride["committedBurstSize"] == "-1")
        intentSchedulerOverr["cbs"] = "default";
    else if (lOverride["committedBurstSize"] != "-2")
        intentSchedulerOverr["cbs"] = lOverride["committedBurstSize"].toString();

    if (lOverride["maximumBurstSize"] == "-1")
        intentSchedulerOverr["mbs"] = "default";
    else if (lOverride["maximumBurstSize"] != "-2")
        intentSchedulerOverr["mbs"] = lOverride["maximumBurstSizeBytes"].toString();


    if (lOverride["pir"] == "-1")
        intentSchedulerOverr["rate"]["pir"] = "max";
    else if (lOverride["pir"] != "-2")
        intentSchedulerOverr["rate"]["pir"] = lOverride["pir"].toString();

    if (lOverride["cir"] == "-1")
        intentSchedulerOverr["rate"]["cir"] = "max";
    else if (lOverride["cir"] != "-2")
        intentSchedulerOverr["rate"]["cir"] = lOverride["cir"].toString();

    return intentSchedulerOverr;
}

/*
   function: NFMPToIntentQoSMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map device model to intent model - Brownfield - QoS and filter
    input:
        nfmpSap:
          type: Object
          description: NFMP device object
          mandatory: True
        direction:
          type: String
          description: ingress/egress
          mandatory: True
        siteId:
          type: String
          description: device NE ID
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with QoS and filter
    examples:
      "NFMPToIntentQoSMapper": |
         sapIntentModel["ingress"] = this.NFMPToIntentQoSMapper(nfmpSapModel, "ingress", siteId);
 */
SrSvcFwk.prototype.NFMPToIntentQoSMapper = function (nfmpSap, direction, siteId) {
    let ret = {};
    ret["qos"] = {};
    ret["filter"] = {};
    let directionUpper = direction.charAt(0).toUpperCase() + direction.slice(1);
    let directionUpperFirstThreeChar = directionUpper.substring(0,3);

    if (nfmpSap[direction + "MatchQinqDot1pBits"]) {
        ret["qos"]["match-qinq-dot1p"] = nfmpSap[direction + "MatchQinqDot1pBits"]
    }

    if (direction === "egress") {
        ret["qos"]["qinq-mark-top-only"] = nfmpSap[direction + "QinqMarkTopBitsOnly"]
    }

    if (nfmpSap[direction + "SchedulerName"] && nfmpSap[direction + "SchedulerName"] !== "N/A") {
        ret["qos"]["scheduler-policy"] = {
            "policy-name": nfmpSap[direction + "SchedulerName"],
            "overrides": {}
        };
        if (nfmpSap["children-Set"] && nfmpSap["children-Set"]["service." + directionUpper + "SchedulerPolicyEntryOverride"]) {
            ret["qos"]["scheduler-policy"]["overrides"]["scheduler"] = [];
            if (Array.isArray(nfmpSap["children-Set"]["service." + directionUpper + "SchedulerPolicyEntryOverride"])) {
                nfmpSap["children-Set"]["service." + directionUpper + "SchedulerPolicyEntryOverride"].forEach(function (lOverride) {
                    ret["qos"]["scheduler-policy"]["overrides"]["scheduler"].push(NFMPtoSchedulerPolicyEntryOverride(lOverride));
                });
            } else {
                ret["qos"]["scheduler-policy"]["overrides"]["scheduler"].push(NFMPtoSchedulerPolicyEntryOverride(nfmpSap["children-Set"]["service." + directionUpper + "SchedulerPolicyEntryOverride"]));
            }
        }
    }
    if (nfmpSap[direction + "PolicerPolicyPointer"] && nfmpSap[direction + "PolicerPolicyPointer"] !== "default") {
        ret["qos"]["policer-control-policy"] = {
            "policy-name": nfmpSap[direction + "PolicerPolicyPointer"].replace("hPolicing:", "")
        }
        if (nfmpSap["children-Set"] && nfmpSap["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"]){
            let policerControllerOverride = nfmpSap["children-Set"]["service.Sap" + directionUpperFirstThreeChar + "PolicerCtlOverride"];
            ret["qos"]["policer-control-policy"]["overrides"] = {"root" :{}};

            if (policerControllerOverride["policerCtlOvrMaxRate"] && policerControllerOverride["policerCtlOvrMaxRate"] == "-1") ret["qos"]["policer-control-policy"]["overrides"]["root"]["max-rate"] = "max";
            else if (policerControllerOverride["policerCtlOvrMaxRate"] && policerControllerOverride["policerCtlOvrMaxRate"] != "-2") ret["qos"]["policer-control-policy"]["overrides"]["root"]["max-rate"] = policerControllerOverride["policerCtlOvrMaxRate"]

            if (policerControllerOverride["policerCtlOvrMinMBSSep"] !== "-2"){
                ret["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"] = {"priority":[]};
                if (policerControllerOverride["policerCtlOvrMinMBSSep"] === "-1")
                    ret["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["min-thresh-separation"] = "auto"
                else if (policerControllerOverride["policerCtlOvrMinMBSSep"] !== "-2")
                    ret["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["min-thresh-separation"] = policerControllerOverride["policerCtlOvrMinMBSSep"];

                if (policerControllerOverride["children-Set"] && policerControllerOverride["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"]){
                    if (Array.isArray(policerControllerOverride["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"])){
                        policerControllerOverride["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"].forEach(function (lOverride) {
                            let PolicerLevelOverride = {"priority-level": lOverride["level"].replace("level", "")};
                            if (lOverride["subProfPCtrlLvlOvrCumMBS"] === "-1")
                                PolicerLevelOverride["mbs-contribution"] = "auto"
                            else if (lOverride["subProfPCtrlLvlOvrCumMBS"] !== "-2")
                                PolicerLevelOverride["mbs-contribution"] = lOverride["subProfPCtrlLvlOvrCumMBS"]
                            ret["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["priority"].push(PolicerLevelOverride);
                        })
                    } else {
                        let PolicerLevelOverride = {"priority-level" : policerControllerOverride["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"]["level"].replace("level","")};
                        if (policerControllerOverride["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"]["subProfPCtrlLvlOvrCumMBS"] === "-1")
                            PolicerLevelOverride["mbs-contribution"] = "auto"
                        else
                            PolicerLevelOverride["mbs-contribution"] = policerControllerOverride["children-Set"]["service.Sap"+directionUpper+"PolicerLevelOverride"]["subProfPCtrlLvlOvrCumMBS"]
                        ret["qos"]["policer-control-policy"]["overrides"]["root"]["priority-mbs-thresholds"]["priority"].push(PolicerLevelOverride);
                    }
                }
            }
        }
    }

    if (nfmpSap[direction + "PolicyObjectPointer"] && nfmpSap[direction + "PolicyObjectPointer"] !== "Access " + directionUpper + ":1") {
        let policyRes = null;
        if (direction === "ingress") {
            policyRes = this.sfUtils.findNFMPByObjectFullName("aingr.Policy", "network:" + siteId + ":" + nfmpSap[direction + "PolicyObjectPointer"], [])["aingr.Policy"];
        } else {
            policyRes = this.sfUtils.findNFMPByObjectFullName("aengr.Policy", "network:" + siteId + ":" + nfmpSap[direction + "PolicyObjectPointer"], [])["aengr.Policy"];
        }
        ret["qos"]["sap-" + direction] = {
            "policy-name": policyRes["policyName"],
            "overrides": {}
        };
    }
    if (nfmpSap["children-Set"] && nfmpSap["children-Set"]["service." + directionUpper + "AccessPolicyQueueOverride"]) {
        if (!ret["qos"]["sap-" + direction]) {
            ret["qos"]["sap-" + direction] = {
                "overrides": {}
            }
        }
        ret["qos"]["sap-" + direction]["overrides"]["queue"] = [];
        if (Array.isArray(nfmpSap["children-Set"]["service." + directionUpper + "AccessPolicyQueueOverride"])) {
            nfmpSap["children-Set"]["service." + directionUpper + "AccessPolicyQueueOverride"].forEach(function (lOverride) {
                  ret["qos"]["sap-" + direction]["overrides"]["queue"].push(NFMPtoAccessPolicyQueueOverride(lOverride));
            });
        } else {
            ret["qos"]["sap-" + direction]["overrides"]["queue"].push(NFMPtoAccessPolicyQueueOverride(nfmpSap["children-Set"]["service." + directionUpper + "AccessPolicyQueueOverride"]));
        }
    }
    if (nfmpSap["children-Set"] && nfmpSap["children-Set"]["service.Sap" + directionUpper + "PolicerOverride"]) {
        if (!ret["qos"]["sap-" + direction]) {
            ret["qos"]["sap-" + direction] = {
                "overrides": {}
            }
        }
        ret["qos"]["sap-" + direction]["overrides"]["policer"] = [];
        if (Array.isArray(nfmpSap["children-Set"]["service.Sap" + directionUpper + "PolicerOverride"])) {
            nfmpSap["children-Set"]["service.Sap" + directionUpper + "PolicerOverride"].forEach(function (lOverride) {
                ret["qos"]["sap-" + direction]["overrides"]["policer"].push(NFMPtoPolicerPolicyEntryOverride(lOverride));
            });
        } else {
            ret["qos"]["sap-" + direction]["overrides"]["policer"].push(NFMPtoPolicerPolicyEntryOverride(nfmpSap["children-Set"]["service.Sap" + directionUpper + "PolicerOverride"]));
        }
    }

    if (direction === "ingress") {
        if (nfmpSap["sharedQueueOn"] === "true") {
            if (!ret["qos"]["sap-ingress"]) {
                ret["qos"]["sap-ingress"] = {};
            }
            if (nfmpSap["usesMultipointShared"] && nfmpSap["usesMultipointShared"] == "true") {
                ret["qos"]["sap-ingress"]["queuing-type"] = "multipoint-shared";
            } else {
                ret["qos"]["sap-ingress"]["queuing-type"] = "shared";
            }
        }
    }

    if ((nfmpSap[direction + "FilterType"] === "ip") && nfmpSap[direction + "FilterPointer"]) {
        ret["filter"]["ip"] = this.sfUtils.findNFMPByObjectFullName("aclfilter.IpFilter", "network:" + siteId + ":" + nfmpSap[direction + "FilterPointer"], [])["aclfilter.IpFilter"]["filterName"];
    } else if ((nfmpSap[direction + "FilterType"] === "mac") && nfmpSap[direction + "FilterPointer"]) {
        ret["filter"]["mac"] = this.sfUtils.findNFMPByObjectFullName("aclfilter.MacFilter", "network:" + siteId + ":" + nfmpSap[direction + "FilterPointer"], [])["aclfilter.MacFilter"]["filterName"];
    }
    if (nfmpSap[direction + "Ipv6FilterPointer"]) {
        ret["filter"]["ipv6"] = this.sfUtils.findNFMPByObjectFullName("aclfilter.Ipv6Filter", "network:" + siteId + ":" + nfmpSap[direction + "Ipv6FilterPointer"], [])["aclfilter.Ipv6Filter"]["filterName"];
    }

    if (direction === "ingress") this.NFMPToIntentQoSMapperIng({"ingress": ret}, nfmpSap, siteId);
    if (direction === "egress")this.NFMPToIntentQoSMapperEgr({"egress": ret}, nfmpSap, siteId);

    return ret;
};

/*
   function: NFMPToIntentCemMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map device model to intent model - Brownfield - CEM
    input:
        nfmpSap:
          type: Object
          description: NFMP device object
          mandatory: True
        intType:
          type: String
          description: Intent Type
          mandatory: True
    output:
     intentModel:
        type: Object
        description: Intent model with CEM
    examples:
      "NFMPToIntentCemMapper": |
         sapIntentModel["cem"] = this.NFMPToIntentCemMapper(nfmpSapModel);
 */
SrSvcFwk.prototype.NFMPToIntentCemMapper = function (nfmpSap,intType) {
    let ret = {};
    if (nfmpSap["children-Set"] && nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]) {
        let rtpHead;
        if (nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemUseRtpHeader"] === "true")
            rtpHead = true;
        else
            rtpHead = false;
        ret["rtp-header"] = rtpHead;

        if (nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemJitterBuffer"]) {
            ret["jitter-buffer"] = nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemJitterBuffer"];
        }
        if (nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemPayloadSize"]) {
            ret["payload-size"] = nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemPayloadSize"];
        }

        if (nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["activeMultipathTimeout"] && intType === "redCpipe") {
            ret["active-multipath-timeout"] = nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["activeMultipathTimeout"];
        }

        let asymDely;
        if (nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemAsymDelayEnable"] === "enabled")
            asymDely = true;
        else
            asymDely = false;

        if(asymDely) {
            ret["asymmetric-delay-control"] = {
                "enable": asymDely,
                "samples": nfmpSap["children-Set"]["cpipe.CpipeCesInterfaceSpecifics"]["cemAsymDelaySamples"]
            };
        } else {
            ret["asymmetric-delay-control"] = {
                "enable": asymDely
            };
        }

    }
    return ret;
};

/*
   function: NFMPToIntentTimeSlotsMapper
    since: NSP 21.6
    short_description: Cpipe - Helper function to generate intent SAP model
    input:
        nfmpSapPortPntr:
          type: String
          description: NFMP port pointer object
          mandatory: True
        vcType:
          type: String
          description: Vc-type
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with SAP
    examples:
      "NFMPToIntentTimeSlotsMapper": |
         let ret = this.NFMPToIntentTimeSlotsMapper(nfmpSapModel["portPointer"],vcType);
 */
SrSvcFwk.prototype.NFMPToIntentTimeSlotsMapper = function (nfmpSapPortPntr,vcType) {
    let ret;
    if(vcType === "satope3" || vcType === "satopt3") {
        ret = this.NFMPToIntentDS3TimeSlotsMapper(nfmpSapPortPntr);
    }else if(vcType === "satope1" || vcType === "satopt1" || vcType === "cesopsn" || vcType === "satopserial" || vcType === "satoptpif")
    {
        ret = this.NFMPToIntentDS0TimeSlotsMapper(nfmpSapPortPntr,vcType);
    }
    return ret;
};

/*
   function: NFMPToIntentDS0TimeSlotsMapper
    since: NSP 21.6
    short_description: Cpipe - Helper function to generate intent SAP model  - DS0
    input:
        nfmpSapPortPntr:
          type: String
          description: NFMP port pointer object
          mandatory: True
        vcType:
          type: String
          description: Vc-type
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with SAP
    examples:
      "NFMPToIntentDS0TimeSlotsMapper": |
         ret = this.NFMPToIntentDS0TimeSlotsMapper(nfmpSapPortPntr,vcType);
 */
SrSvcFwk.prototype.NFMPToIntentDS0TimeSlotsMapper = function (nfmpSapPortPntr,vcType) {
    let ret = {};
    let nfmpFwk = new MediatorFramework("NFMP");
    let ds0GrpSrchPayload = {
        "fullClassName": "tdmequipment.DS0ChannelGroup",
        "filter": {
            "equal": [
                {
                    "name": "objectFullName",
                    "value": nfmpSapPortPntr
                }
            ]
        },
        "resultFilter": {
            "attribute": [
                "parentDisplayedName"
            ],
            "children": [
                {

                    "resultFilter": {
                        "class": "tdmequipment.DS0ChannelGroupSpecifics",
                        "attribute": [
                            "timeSlotBits"
                        ]
                    }
                }
            ]
        }
    };
    let ds0GrpSrchResponse = nfmpFwk.post("/v3/search", ds0GrpSrchPayload);

    if (!(ds0GrpSrchResponse.success && ds0GrpSrchResponse["response"]))
        throw new RuntimeException("Fail to get DS0Grp info from nfm-p: " + ds0GrpSrchResponse);
    ds0GrpSrchResponse = JSON.parse(ds0GrpSrchResponse["response"]);
    this.sfLogger.info("NFMP Mapper NFMPToIntentTimeSlotsMapper From NFMP response for DS0Grp : " + ds0GrpSrchResponse);

    if (ds0GrpSrchResponse) {
        ret["parentPort"] = ds0GrpSrchResponse["tdmequipment.DS0ChannelGroup"]["parentDisplayedName"];
        let nodeTimeslot = ds0GrpSrchResponse["tdmequipment.DS0ChannelGroup"]["children-Set"]["tdmequipment.DS0ChannelGroupSpecifics"]["timeSlotBits"];

        if (!isEmpty(nodeTimeslot)) {
            let nodetime = nodeTimeslot;
            let sortednodets;

            if(Array.isArray(nodeTimeslot)) {
                nodetime = nodeTimeslot.sort(sortAlphaNum);
                let newstr = "";
                nodetime.forEach(function(str){
                    newstr =newstr + str.replace("ts","") + ",";
                });
                sortednodets = newstr.substring(0, newstr.length - 1);
            }
            else {
                sortednodets = nodeTimeslot.replace("ts","");
            }

            if(vcType === "satope1") {
                ret["timeSlots"] = "1-32";
            } else if(vcType === "satopt1") {
                ret["timeSlots"] = "1-24";
            } else if (vcType === "cesopsn" || vcType === "satoptpif"){
                ret["timeSlots"] = sortednodets;
            } else if(vcType === "satopserial" ) {
                ret["timeSlots"] = "NONE";
            }
        }

    } else {
        throw new RuntimeException("Fail to get DS0Grp : " + ds0GrpSrchResponse);
    }
    this.sfLogger.info("NFMPToIntentTimeSlotsMapper ret :{} ",JSON.stringify(ret) );
    return ret;

};

/*
   function: NFMPToIntentDS3TimeSlotsMapper
    since: NSP 21.6
    short_description: Cpipe - Helper function to generate intent SAP model  - DS3
    input:
        nfmpSapPortPntr:
          type: String
          description: NFMP port pointer object
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model with SAP
    examples:
      "NFMPToIntentDS3TimeSlotsMapper": |
         ret = this.NFMPToIntentDS3TimeSlotsMapper(nfmpSapPortPntr);
 */
SrSvcFwk.prototype.NFMPToIntentDS3TimeSlotsMapper = function (nfmpSapPortPntr) {

    let ret = {};
    let nfmpFwk = new MediatorFramework("NFMP");
    let ds3GrpSrchPayload = {
        "fullClassName": "tdmequipment.DS3E3Channel",
        "filter": {
            "equal": [
                {
                    "name": "objectFullName",
                    "value": nfmpSapPortPntr
                }
            ]
        },
        "resultFilter": {
            "attribute": [
                "parentDisplayedName"
            ]
        }
    };
    let ds3GrpSrchResponse = nfmpFwk.post("/v3/search", ds3GrpSrchPayload);

    if (!(ds3GrpSrchResponse.success && ds3GrpSrchResponse["response"]))
        throw new RuntimeException("Fail to get DS3/E3 info from nfm-p: " + ds3GrpSrchResponse);
    ds3GrpSrchResponse = JSON.parse(ds3GrpSrchResponse["response"]);
    this.sfLogger.info("NFMP Mapper NFMPToIntentDS3TimeSlotsMapper From NFMP response for DS0Grp : " + ds3GrpSrchResponse);

    if (ds3GrpSrchResponse) {
        ret["parentPort"] = ds3GrpSrchResponse["tdmequipment.DS3E3Channel"]["parentDisplayedName"];
        ret["timeSlots"] = "NONE";

    } else {
        throw new RuntimeException("Fail to get DS3Grp : " + ds3GrpSrchResponse);
    }
    this.sfLogger.info("NFMPToIntentDS3TimeSlotsMapper ret :{} ",JSON.stringify(ret) );
    return ret;

};

/*
   function: svcToNFMPMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map intent model to device model - Service level object
    input:
        svcObj:
          type: Object
          description: Service intent model objects
          mandatory: True
        siteObj:
          type: Object
          description: Site level intent model objects
          mandatory: True
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with service level properties
    examples:
      "svcToNFMPMapper": |
         "epipe.Epipe": this.srSvcUtils.svcToNFMPMapper(svcObj, siteObjArr)
 */
SrSvcFwk.prototype.svcToNFMPMapper = function (svcObj, siteObj) {
    let lSvcMgrId = null;
    if (typeof svcObj["serviceMgrId"] === "object" && svcObj["serviceMgrId"]["NFMP"]){
        lSvcMgrId = svcObj["serviceMgrId"]["NFMP"].split("-");
    } else{
        lSvcMgrId = svcObj["serviceMgrId"].split("-");
    }

    let svcPayload = {
        "displayedName": svcObj["service-name"],
        "serviceId": svcObj["ne-service-id"],
        "description": svcObj["description"] ? svcObj["description"] : "N/A",
        "id": lSvcMgrId[lSvcMgrId.length - 1]
    };

    if (svcPayload.displayedName &&svcPayload.displayedName.indexOf(":") !== -1){
        let lServiceNameArr = svcPayload.displayedName.split(":");
        if (lServiceNameArr.length === 3 && lServiceNameArr[2].indexOf("sam") !== -1){
            svcPayload.displayedName = lServiceNameArr[0];
        }
    }

    let customerExtraInfo = null;
    if (svcObj["@"] && svcObj["@"]["customerInfo"])
        customerExtraInfo = svcObj["@"]["customerInfo"];
    svcPayload["subscriberPointer"] = this.nfmpCheckCustomerAndDeploy(svcObj["customer-id"], customerExtraInfo);
    if (svcObj["nfmpAlienMediatorList"]){
        let self = this;
        svcObj["nfmpAlienMediatorList"].forEach(function (lNFMPmediator) {
            self.nfmpCheckCustomerAndDeploy(svcObj["customer-id"], customerExtraInfo, lNFMPmediator);
        })
    }
    if (svcObj["admin-state"] === "unlocked") {
        svcPayload["administrativeState"] = "up";
    } else
        svcPayload["administrativeState"] = "down";

    svcPayload["children-Set"] = siteObj;

    return svcPayload;
};

/*
   function: NFMPtoSvcMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map device model to intent model - Brownfield - Service objects
    input:
        intentModel:
          type: Object
          description: Existing intent model
          mandatory: True
        serviceModel:
          type: Object
          description: NFMP device object
          mandatory: True
        nfmpClassName:
          type: String
          description: NFMP service className - ex epipe.Epipe
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoSvcMapper": |
         this.srSvcUtils.NFMPtoSvcMapper(intentModel["service"], lServiceObj["vpls.Vpls"], "vpls.Vpls", operModel);
 */
SrSvcFwk.prototype.NFMPtoSvcMapper = function (intentModel, serviceModel, nfmpClassName, operModel) {
    intentModel["customer-id"] = operModel["tenant"][0]["id"];

    if (serviceModel && serviceModel["description"] && serviceModel["description"] !== "N/A")
        intentModel["description"] = serviceModel["description"];

    if (serviceModel && serviceModel["serviceId"]) intentModel["ne-service-id"] = serviceModel["serviceId"];

    if (serviceModel && serviceModel["administrativeState"] === "up")
        intentModel["admin-state"] = "unlocked";
    else if (serviceModel && serviceModel["administrativeState"] === "down")
        intentModel["admin-state"] = "locked";

    if(serviceModel && serviceModel["vcType"]) {
        intentModel["vc-type"] = serviceModel["vcType"];
    }
};

/*
   function: sapToNFMPMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map intent model to device model - SAP
    input:
        svcObj:
          type: Object
          description: Service intent model objects
          mandatory: True
        sapAmi:
          type: Object
          description: SAP level intent model objects
          mandatory: True
        deviceId:
          type: Object
          description: NE system ip
          mandatory: True
        neSvcType:
          type: String
          description: Service type
          mandatory: True
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: False
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with SAP
    examples:
      "sapToNFMPMapper": |
          let epPayload = this.srSvcUtils.sapToNFMPMapper(svcObjMap, siteObjMap.endpoint[j], deviceId, "epipe");
 */
SrSvcFwk.prototype.sapToNFMPMapper = function (svcObj, sapAmi, deviceId, neSvcType, alienMediatorName, requestContext) {
    if (sapAmi["port-id"] && sapAmi["port-id"].toLowerCase().indexOf("lag") == -1 && sapAmi["port-id"].toLowerCase().indexOf("esat") == -1
        && sapAmi["port-id"].toLowerCase().indexOf("pw") == -1 && sapAmi["port-id"].toLowerCase().indexOf("channel") == -1 &&
        sapAmi["port-id"].toLowerCase().indexOf("tunnel") == -1 && sapAmi["port-id"].toLowerCase().indexOf("pxc") == -1 && sapAmi["port-id"].indexOf("Port ") === -1){
            sapAmi["port-id"] = "Port "+sapAmi["port-id"];
    }
    let sapDevice = {
        "outerEncapValue": this.nfmpSapTagMapper(sapAmi["outer-vlan-tag"]),
        "innerEncapValue": this.nfmpSapTagMapper(sapAmi["inner-vlan-tag"]),
        "description": sapAmi["description"] ? sapAmi["description"] : "N/A",
        "children-Set": {}
    };

    if (sapAmi["port-id"] && sapAmi["port-id"] !== "Port N/A"){
        let deviceInfos = this.nspRestconfFwk.getPortByName(deviceId, sapAmi["port-id"], 2);
        if (deviceInfos && deviceInfos && deviceInfos["@"]["nsp-model:sources"]) {
            deviceInfos["@"]["nsp-model:sources"].forEach(function (lPortFdn) {
                if (lPortFdn.indexOf("sam") != -1)
                    sapDevice["portPointer"] = lPortFdn.replace("fdn:realm:sam:", "");
            })
        }
        if (!sapDevice["portPointer"]) {
            throw new RuntimeException("NFMP Failed to resolve portPointer - device:" + deviceId + " port-id:" + sapAmi["port-id"]);
        }
    }

    if (sapAmi["connection-profile-id"] && sapAmi["connection-profile-id"] !== null) {
        if((typeof sapAmi["outer-vlan-tag"] === "undefined" || sapAmi["outer-vlan-tag"] == "-1") && 
            (typeof sapAmi["inner-vlan-tag"] === "undefined" || sapAmi["inner-vlan-tag"] == "-1")) {
            //Do1Q ConnectionProfile
            sapDevice["connectionProfileVlan"] = "network:" + deviceId.replace(":","_") + ":VlanConnProf:" + sapAmi["connection-profile-id"];
            sapDevice["connectionProfileVlanTag"] = "outer";
            sapDevice["outerEncapValue"] = (65536 | sapAmi["connection-profile-id"]);
        } else {
            if ((typeof sapAmi["outer-vlan-tag"] === "undefined" || sapAmi["outer-vlan-tag"] == "-1")) {
                sapDevice["connectionProfileVlanTag"] = "outer"; 
                sapDevice["outerEncapValue"] = (65536 | sapAmi["connection-profile-id"]); 
            } else {
                sapDevice["connectionProfileVlanTag"] = "inner";
                sapDevice["innerEncapValue"] = (65536 | sapAmi["connection-profile-id"]);    
            }
            let lNfmpAcessInterface = this.findNFMPL2AccessInterfaceByServiceSite(svcObj["serviceMgrId"].replace("sam:", ""), deviceId, sapDevice["portPointer"], sapDevice["innerEncapValue"], sapDevice["outerEncapValue"]);
            if (!lNfmpAcessInterface) {
                sapDevice["connectionProfileVlan"] = "network:" + deviceId.replace(":","_") + ":VlanConnProf:" + sapAmi["connection-profile-id"];   
            }
        }
    }

    if (sapAmi["admin-state"] === "unlocked") {
        sapDevice["administrativeState"] = "serviceUp";
    } else {
        sapDevice["administrativeState"] = "serviceDown";
    }

    if (sapAmi["ingress"]) {
        this.IntentQoSToNFMPMapper(sapAmi["ingress"], sapDevice, "ingress", deviceId, neSvcType, alienMediatorName, svcObj, requestContext);
    }

    if (sapAmi["egress"]) {
        this.IntentQoSToNFMPMapper(sapAmi["egress"], sapDevice, "egress", deviceId, neSvcType, alienMediatorName, svcObj, requestContext);
    }

    if (sapAmi["collect-stats"]) {
        sapDevice["accountingOn"] = sapAmi["collect-stats"];
    } else {
        sapDevice["accountingOn"] = false;
    }

    if (sapAmi["accounting-policy-id"]) {
        sapDevice["accountingPolicyObjectPointer"] = "Accounting:" + sapAmi["accounting-policy-id"];
    } else {
        sapDevice["accountingPolicyObjectPointer"] = "";
    }

    if (sapAmi["multi-service-site"]) {
        sapDevice["aggregation"] = "on"
        sapDevice["aggregationSchedulerObjectPointer"] = "subscriber:" + svcObj["customer-id"] + ":site-" + deviceId.replace(":","_") + ":scheduler-" + sapAmi["multi-service-site"]
    }

    if (sapAmi["cpu-protection"] && sapAmi["cpu-protection"]["policy-id"]){
        sapDevice["dosProtection"] = "NE DoS Protection:"+ sapAmi["cpu-protection"]["policy-id"];
    }

    return sapDevice;
};

/*
   function: NFMPtoSapMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map device model to intent model - Brownfield - SAP
    input:
        nfmpSapModel:
          type: Object
          description: NFMP device object
          mandatory: True
        siteId:
          type: String
          description: NE system ip
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoSapMapper": |
         intentModel["site"]["sap-details"]["sap"].push(this.srSvcUtils.NFMPtoSapMapper(childClassVal[j], siteId));
 */
SrSvcFwk.prototype.NFMPtoSapMapper = function (nfmpSapModel, siteId) {
    let sapIntentModel = {
        "port-id": nfmpSapModel["portName"],
        "inner-vlan-tag": this.SapNfmpTagMapper(nfmpSapModel["innerEncapValue"]),
        "outer-vlan-tag": this.SapNfmpTagMapper(nfmpSapModel["outerEncapValue"])
    };
    if (nfmpSapModel["connectionProfileVlan"] && nfmpSapModel["connectionProfileVlan"] !== null) {
        let lConString =  nfmpSapModel["connectionProfileVlan"].split(":");
        sapIntentModel["connection-profile-id"] = lConString[lConString.length-1];
    }
    if (nfmpSapModel["portName"] === "N/A") sapIntentModel["port-id"] = null;
    if (nfmpSapModel["description"] && nfmpSapModel["description"] !== "N/A")
        sapIntentModel["description"] = nfmpSapModel["description"];
    if (nfmpSapModel["administrativeState"] === "serviceUp")
        sapIntentModel["admin-state"] = "unlocked";
    else
        sapIntentModel["admin-state"] = "locked";

    sapIntentModel["ingress"] = this.NFMPToIntentQoSMapper(nfmpSapModel, "ingress", siteId);
    sapIntentModel["egress"] = this.NFMPToIntentQoSMapper(nfmpSapModel, "egress", siteId);

    if (sapIntentModel["ingress"] || sapIntentModel["egress"] ){
        sapIntentModel["enable-filter"] = true
        sapIntentModel["enable-qos"] = true;
    }

    if (nfmpSapModel["accountingOn"]) {
        sapIntentModel["collect-stats"] = nfmpSapModel["accountingOn"];
    }

    if (nfmpSapModel["accountingPolicyId"] !== "0") {
        sapIntentModel["accounting-policy-id"] = nfmpSapModel["accountingPolicyId"];
    }

    if (nfmpSapModel["aggregation"] === "on"){
        let aggPointer = nfmpSapModel["aggregationSchedulerObjectPointer"].split("-")
        sapIntentModel["multi-service-site"] = aggPointer[aggPointer.length-1];
    }

    if (nfmpSapModel["dosProtection"] && nfmpSapModel["dosProtection"] !== "NE DoS Protection:254"){
        sapIntentModel["cpu-protection"] = {
            "policy-id" : nfmpSapModel["dosProtection"].split(":")[1]
        }
    }

    return sapIntentModel;
};

/*
   function: NFMPtoCpipeSapMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map device model to intent model - Brownfield - SAP
    input:
        nfmpSapModel:
          type: Object
          description: NFMP device object
          mandatory: True
        siteId:
          type: String
          description: NE system ip
          mandatory: True
        vcType:
          type: String
          description: Vc-type
          mandatory: True
        intType:
          type: String
          description: Intent Type
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoCpipeSapMapper": |
         intentModel["site"]["sap-details"]["sap"].push(this.srSvcUtils.NFMPtoSapMapper(childClassVal[j], siteId));
 */
SrSvcFwk.prototype.NFMPtoCpipeSapMapper = function (nfmpSapModel, siteId, vcType,intType) {
    let ret = this.NFMPToIntentTimeSlotsMapper(nfmpSapModel["portPointer"],vcType);

    let sapIntentModel = {
        "port-id": ret["parentPort"],
        "time-slots": ret["timeSlots"]
    };
    if (nfmpSapModel["description"] && nfmpSapModel["description"] !== "N/A")
        sapIntentModel["description"] = nfmpSapModel["description"];
    if (nfmpSapModel["administrativeState"] === "serviceUp")
        sapIntentModel["admin-state"] = "unlocked";
    else
        sapIntentModel["admin-state"] = "locked";

    sapIntentModel["ingress"] = this.NFMPToIntentQoSMapper(nfmpSapModel, "ingress", siteId);
    sapIntentModel["egress"] = this.NFMPToIntentQoSMapper(nfmpSapModel, "egress", siteId);

    if (sapIntentModel["ingress"] || sapIntentModel["egress"] ){
        sapIntentModel["enable-qos"] = true;
        sapIntentModel["enable-filter"] = true;
    }


    sapIntentModel["cem"] = this.NFMPToIntentCemMapper(nfmpSapModel,intType);

    return sapIntentModel;
};

/*
   function: sdpToNFMPMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map intent model to device model - SDP
    input:
        sdpAmi:
          type: Object
          description: SDP level intent model objects
          mandatory: True
        siteObjMap:
          type: Object
          description: Intent site level objects
          mandatory: True
        serviceId:
          type: String
          description: Service Id. If vc-id is not provided service-id will be used
          mandatory: False
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with SDP
    examples:
      "sdpToNFMPMapper": |
          let sdpDevice = this.srSvcUtils.sdpToNFMPMapper(sdpAmi, siteObjMap,svcObjMap["ne-service-id"]);
 */
SrSvcFwk.prototype.sdpToNFMPMapper = function (sdpAmi, siteObjMap, serviceId) {
    sdpAmi["sdp-bind-id"] = sdpAmi["sdp-id"];
    let sdpDevice = {
        "tunnelSelectionTerminationSiteId": "0.0.0.0",
        "pathId": sdpAmi["sdp-bind-id"],
        "description": sdpAmi["description"] ? sdpAmi["description"] : "N/A"
    };

    if (sdpAmi["vc-id"]){
        sdpDevice["vcId"] =  sdpAmi["vc-id"];
    } else {
        sdpDevice["vcId"] =  serviceId;
    }

    if (sdpAmi["admin-state"] === "unlocked") {
        sdpDevice["administrativeState"] = "circuitUp";
    } else {
        sdpDevice["administrativeState"] = "circuitDown";
    }
    if (typeof sdpAmi["collect-stats"] !== "undefined") {
        sdpDevice["accountingOn"] = sdpAmi["collect-stats"];
    }
    if (sdpAmi["accounting-policy-id"]) {
        sdpDevice["accountingPolicyPointer"] = "Accounting:" + sdpAmi["accounting-policy-id"];
    } else {
        sdpDevice["accountingPolicyPointer"] = "";
    }
    if (sdpAmi["entropy-label"]) {
        sdpDevice["entropyLabel"] = true;
        sdpDevice["hashLabelSignalCapability"] = false;
        sdpDevice["hashLabel"] = false;
    } else {
        sdpDevice["entropyLabel"] = false;
        if (typeof sdpAmi["hash-label"] !== "undefined") {
            sdpDevice["hashLabel"] = true;
            if (sdpAmi["hash-label"]["signal-capability"]) {
                sdpDevice["hashLabelSignalCapability"] = true;
            } else {
                sdpDevice["hashLabelSignalCapability"] = false;
            }
        } else {
            sdpDevice["hashLabelSignalCapability"] = false;
            sdpDevice["hashLabel"] = false;
        }
    }
    if (typeof sdpAmi["vlan-vc-tag"] !== "undefined") {
        sdpDevice["vlanVcTag"] = sdpAmi["vlan-vc-tag"];
    } else {
        sdpDevice["vlanVcTag"] = "4095"
    }

    if (sdpAmi["vc-type"] === "ether")
        sdpDevice["vcType"] = "ethernet";
    else
        sdpDevice["vcType"] = "vlan";

    if (typeof sdpAmi["pw-status"] !== "undefined") {
        if (typeof sdpAmi["pw-status"]["signaling"] !== "undefined") {
            sdpDevice["pwStatusSignaling"] = sdpAmi["pw-status"]["signaling"];
        }
        if (typeof sdpAmi["pw-status"]["block-on-peer-fault"] !== "undefined") {
            sdpDevice["blockOnPeerFault"] = sdpAmi["pw-status"]["block-on-peer-fault"];
        }
        if (typeof sdpAmi["pw-status"]["standby-signaling-slave"] !== "undefined") {
            sdpDevice["enableStandbySignalingSlave"] = sdpAmi["pw-status"]["standby-signaling-slave"];
        }  
    }

    return sdpDevice;
};

/*
   function: NFMPtoSdpMapper
    since: NSP 21.6
    short_description: NFMP managed SR - map device model to intent model - Brownfield - SDP
    input:
        siteId:
          type: String
          description: NE system ip
          mandatory: True
        nfmpSdpModel:
          type: Object
          description: NFMP device object
          mandatory: True
        serviceId:
          type: String
          description: Service Id. If vc-id is not provided service-id will be used
          mandatory: False
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoSdpMapper": |
        let lSpoke = this.srSvcUtils.NFMPtoSdpMapper(siteId, childClassVal[j], intentModel["service"]["ne-service-id"]);
 */
SrSvcFwk.prototype.NFMPtoSdpMapper = function (siteId, nfmpSdpModel, serviceId) {
    this.sfLogger.debug("[SR-SVC-FWK] NFMPtoSdpMapper  site: {} nfmpSdpModel : {}", siteId, JSON.stringify(nfmpSdpModel));
    let sdpIntentModel = {
        "source-device-id": siteId,
        "sdp-id": nfmpSdpModel["pathId"] + "",
        "destination-device-id": nfmpSdpModel["toNodeId"]
    };
    if (nfmpSdpModel["vcId"] != serviceId){
        sdpIntentModel["vc-id"] = nfmpSdpModel["vcId"];
        sdpIntentModel["override-vc-id"] = true;
    } else
        sdpIntentModel["override-vc-id"] = false;

    if (nfmpSdpModel["description"] && nfmpSdpModel["description"] !== "N/A")
        sdpIntentModel["description"] = nfmpSdpModel["description"];
    if (nfmpSdpModel["vcType"] === "ethernet")
        sdpIntentModel["vc-type"] = "ether";
    else
        sdpIntentModel["vc-type"] = "vlan";
    if (nfmpSdpModel["administrativeState"] === "circuitUp")
        sdpIntentModel["admin-state"] = "unlocked";
    else
        sdpIntentModel["admin-state"] = "locked";

    if (typeof nfmpSdpModel["accountingOn"] !== "undefined"){
        sdpIntentModel["collect-stats"] = nfmpSdpModel["accountingOn"];
    }
    if (typeof nfmpSdpModel["vlanVcTag"] !== "undefined"){
        if (nfmpSdpModel["vlanVcTag"] !== "4095") {
            sdpIntentModel["vlan-vc-tag"] =  nfmpSdpModel["vlanVcTag"];
        }
    }
    if (nfmpSdpModel["accountingPolicyId"] !== "0") {
        sdpIntentModel["accounting-policy-id"] = nfmpSdpModel["accountingPolicyId"];
    }
    if (nfmpSdpModel["entropyLabel"] && nfmpSdpModel["entropyLabel"] === "true") {
        sdpIntentModel["entropy-label"] = [];
        sdpIntentModel["entropy-label"].push(null);
    } else if (nfmpSdpModel["hashLabel"] && nfmpSdpModel["hashLabel"] === "true") {
        sdpIntentModel["hash-label"] = {};
        if (nfmpSdpModel["hashLabelSignalCapability"] && nfmpSdpModel["hashLabelSignalCapability"] === "true") {
            sdpIntentModel["hash-label"]["signal-capability"] = [];
            sdpIntentModel["hash-label"]["signal-capability"].push(null);
        }
    }

    return sdpIntentModel;
};

/*
   function: NFMPtoSdpMapper
    since: NSP 21.6
    short_description: helper function that changes NFMP inner/outer vlan tags to intent model
    input:
        tag:
          type: Integer
          description: NFMP inner/outer tag
          mandatory: True
    output:
      tag:
        type: Integer
        description: Intent inner/outer tag
 */
SrSvcFwk.prototype.nfmpSapTagMapper = function (tag) {
    if (tag === -1) {
        return 0;
    } else
        return tag;
};

/*
   function: SapNfmpTagMapper
    since: NSP 21.6
    short_description: helper function that changes intent model inner/outer tag to NFMP inner/outer tag
    input:
        tag:
          type: Integer
          description: Intent inner/outer tag
          mandatory: True
    output:
      tag:
        type: Integer
        description: NFMP inner/outer tag
 */
SrSvcFwk.prototype.SapNfmpTagMapper = function (tag) {
    if (tag == "0" || tag > 4095) {
        return -1;
    } else
        return tag;
};

/*
   function: nfmpCheckCustomerAndDeploy
    since: NSP 21.6
    short_description: Deploy NFMP customer if doesnt exits, and return nfmp customerPointer for service payload
    input:
        customerId:
          type: Integer
          description: NSP/IBSF customer id
          mandatory: True
        customerInfo:
          type: Object
          description: NSP/IBSF customer object
          mandatory: True
        alienMediatorName:
          type: Object
          description: HCO - NFMP alien mediator name
          mandatory: False
    output:
      nfmpCustomerFdn:
        type: String
        description: NFMP customer pointer.
 */
SrSvcFwk.prototype.nfmpCheckCustomerAndDeploy = function (customerId, customerInfo, alienMediatorName) {
    if (customerId && customerId != "1") {
        let payload = {
            "fullClassName": "subscr.Subscriber",
            "filter": {
                "equal": {"name": "subscriberId", "value": customerId}
            },
            "resultFilter": {
                "attribute": [
                    "objectFullName"
                ],
                "children": {}
            }
        };
        let lNfmpFwk = this.nfmpFwk;
        if (alienMediatorName)
            lNfmpFwk = new MediatorFramework(alienMediatorName);
        let customerResults = lNfmpFwk.post("/v3/search", payload);
        if (customerResults.success)
            customerResults = JSON.parse(customerResults["response"]);

        if (customerResults["subscr.Subscriber"] && customerResults["subscr.Subscriber"]["objectFullName"]) {
            this.sfLogger.debug("[SR-SVC-FWK] nfmpCheckCustomerAndDeploy found existing customer: {}", customerId);
        } else {
            this.sfLogger.info("[SR-SVC-FWK] nfmpCheckCustomerAndDeploy  didnt find customer: {}", customerId);

            if (!customerId)
                throw new RuntimeException("Customer is required for NFMP payload");

            let customerNFMPPayload = {
                "distinguishedName": "subscriber",
                "childConfigInfo": {
                    "subscr.Subscriber": {
                        "subscriberId": customerId+"",
                        "subscriberName": customerInfo["name"],
                        "description": customerInfo["description"],
                        "phoneNumber": customerInfo["phone-number"],
                        "contact": customerInfo["contact"],
                        "email" : customerInfo["email"],
                        "address" : customerInfo["address"]
                    }
                }
            };
            let customerCreateResp = lNfmpFwk.post("/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true", customerNFMPPayload);
            if (!customerCreateResp.success) {
                throw new RuntimeException("Didnt create NFMP Customer object - " + JSON.stringify(customerCreateResp));
            }
        }
    }
    return "subscriber:"+customerId;
};

/*
   function: srCheckCustomerAndDeploy
    since: NSP 21.6
    short_description: Deploy MD-SR customer if doesn't exist
    input:
        customerId:
          type: Integer
          description: NSP/IBSF customer id
          mandatory: True
        siteId:
          type: Object
          description: NE site ID
          mandatory: True
        customerInfo:
          type: Object
          description: NSP/IBSF customer object
          mandatory: True
        alienMediator:
          description: HCO - Alien mediator name
          type: String
          mandatory: False
 */
SrSvcFwk.prototype.srCheckCustomerAndDeploy = function (customerId, siteId, customerInfo, alienMediator) {
    if (!customerInfo["name"] || (customerInfo["name"] && customerInfo["name"] === "")){
        throw new RuntimeException("Cannot create customer - Site:{} NSP Customer name not found customer-id: "+siteId,customerId+" customer-name :" + customerInfo["name"]);
    }
    let ret =  customerInfo["name"] + "";

    let lCustomerNspSiteObj = this.nspRestconfFwk.findByXpath("/nsp-customer:customers/customer[id='" + customerId + "']/sites[site-id='" + siteId +"']",2);
    if (!lCustomerNspSiteObj || lCustomerNspSiteObj.length === 0){
        let lCustomer = this.nspRestconfFwk.getByXpath("/network-device-mgr:network-devices/network-device="+siteId+"/root/nokia-conf:/configure/service/customer=" + customerInfo["name"], alienMediator);
        if (!lCustomer) {
            this.sfLogger.info("[SR-SVC-FWK] srCheckCustomerAndDeploy Didn't find customer with global name {} on site : {}", customerInfo["name"], siteId);
            let payload = {
                "customer": {
                    "customer-id": customerId,
                    "phone": customerInfo["phone-number"],
                    "contact": customerInfo["contact"],
                    "description": customerInfo["description"],
                    "customer-name": customerInfo["name"]
                }
            };
            let mdcMediator;

            if(alienMediator)
                mdcMediator = new MediatorFramework(alienMediator.replace("MDC", "NSP"), this.sfLogger);
            else
                mdcMediator = new MediatorFramework("MDC", this.sfLogger);

            let deployResult = mdcMediator.post("/restconf/data/network-device-mgr:network-devices/network-device="+siteId+"/root/nokia-conf:/configure/service", payload);
            if (!deployResult.success) {
                throw new RuntimeException("[SR-SVC-FWK] Customer creation site: "+siteId+"  failed {}" + deployResult.msg);
            }
            this.sfLogger.info("[SR-SVC-FWK] srCheckCustomerAndDeploy Created customer with id {} and global name {} on site {}", customerId, customerInfo["name"], siteId);
        }
    } else {
        ret = lCustomerNspSiteObj[0]["name"]
    }
    return ret;
};

/*
   function: findNfmpSystemInterface
    since: NSP 21.6
    short_description: Helper function returns NFMP Network interface
    input:
        siteId:
          type: Object
          description: NE site ID
          mandatory: True
     output:
      nfmpNetworkIntObj:
        type: Object
        description: NFMP Network interface for given site.
 */
SrSvcFwk.prototype.findNfmpSystemInterface = function (siteId) {
    let responseObj = null;
    let payload = {
        "fullClassName": "rtr.NetworkInterface",
        "filter": {
            "and": {
                "equal": [
                    {"name": "nodeId", "value": siteId},
                    {"name": "id", "value": 1}
                ]
            }
        },
        "resultFilter": {
            "attribute": [
                "primaryIPv4Address"
            ],
            "children": {}
        }
    };
    let networkInterfaceResults = this.nfmpFwk.post("/v3/search", payload);
    if (!(networkInterfaceResults.success && networkInterfaceResults["response"]))
        throw new RuntimeException("Didnt find NetworkInterface for - " + siteId);
    networkInterfaceResults = JSON.parse(networkInterfaceResults["response"]);
    if (networkInterfaceResults["rtr.NetworkInterface"])
            responseObj = networkInterfaceResults["rtr.NetworkInterface"]["primaryIPv4Address"];
    return responseObj;
};

/*
   function: getUnusedIngressLabel
    since: NSP 21.6
    short_description: Helper function returns unused ingress vc-label
    input:
        siteId:
          type: Object
          description: NE site ID
          mandatory: True
     output:
      unusedIngressLabel:
        type: Integer
        description: unused ingress vc-label
 */
SrSvcFwk.prototype.getUnusedIngressLabel = function(siteId){
    let UsedIngressLabel = [];
    let UnusedIngress;
    let nfmpPayload = {
            "fullClassName": "svt.SpokeSdpBinding",
            "filter": {
                "equal": [
                          {"name": "fromNodeId", "value": siteId}]
            },
            "resultFilter": {
                "attribute": [
                              "ingressLabel"
                              ],
                              "children": {}
            }
    };
    let spokeBindingFetch = this.nfmpFwk.post("/v3/search", nfmpPayload);
    if (!(spokeBindingFetch.success && spokeBindingFetch["response"]))
        UnusedIngress = 1024;
    spokeBindingFetch = JSON.parse(spokeBindingFetch["response"]);
    if(spokeBindingFetch["svt.SpokeSdpBinding"])
    {
        if (Array.isArray(spokeBindingFetch["svt.SpokeSdpBinding"])){
            for (var  j = 0; j < spokeBindingFetch["svt.SpokeSdpBinding"].length; j++) {
                UsedIngressLabel.push(parseInt(spokeBindingFetch["svt.SpokeSdpBinding"][j]["ingressLabel"]));
            }
        } else {
            UsedIngressLabel.push(parseInt(spokeBindingFetch["svt.SpokeSdpBinding"]["ingressLabel"]));
        }
        UsedIngressLabel.sort(function(a, b){return a - b});
    }
    if(UsedIngressLabel && UsedIngressLabel.length > 0 && UsedIngressLabel.indexOf(1024,0) > -1)
    {
        for(var ingress in UsedIngressLabel) {
            let label = UsedIngressLabel[ingress] + 1;
            if(!(UsedIngressLabel.indexOf(label,0) > -1)){
                UnusedIngress = label;
                break;
            }
        }
    } else {
        UnusedIngress = 1024;
    }
    return UnusedIngress;
};

/*
   function: ipTransportToNFMPMapper
    since: NSP 23.11
    short_description: NFMP managed SAR 7705 - map intent model to device model - IPTransport
    input:
        ipTransportAmi:
          type: Object
          description: IPTransport intent model objects
          mandatory: True
        neSvcType:
          type: String
          description: Service type
          mandatory: True
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with IPTransport
    examples:
      "ipTransportToNFMPMapper": |
          let epPayload = this.srSvcUtils.ipTransportToNFMPMapper(ipTransportAmi, "vprn");
 */
SrSvcFwk.prototype.ipTransportToNFMPMapper = function (ipTransportAmi, neSvcType, deviceId) {
    let intDevice = {};
    if (neSvcType === "vprn") {
        intDevice["children-Set"] = {
            "vprn.IpTransportRemoteHost": []
        };
    } else {
        intDevice["children-Set"] = {
            "ies.IpTransportRemoteHost": []
        };
    }

    if (ipTransportAmi["transport-port-id"] && ipTransportAmi["transport-port-id"] !== "Port N/A"){
        let deviceInfos = this.nspRestconfFwk.getPortByName(deviceId, ipTransportAmi["transport-port-id"], 2);
        if (deviceInfos && deviceInfos && deviceInfos["@"]["nsp-model:sources"][0].indexOf("sam") != -1) {
            intDevice["portPointer"] = deviceInfos["@"]["nsp-model:sources"][0].replace("fdn:realm:sam:", "");
        } else {
            throw new RuntimeException("NFMP Failed to resolve transport portPointer - device:" + deviceId + " port-id:" + ipTransportAmi["transport-port-id"]);
        }
    }

    if (ipTransportAmi["admin-state"] === "locked") {
        intDevice["administrativeState"] = "tmnxOutOfService"
    }
    else {
        intDevice["administrativeState"] = "tmnxInService"
    }
    intDevice["description"] = ipTransportAmi["description"];
    if (ipTransportAmi["local-host"] ) {
        intDevice["localHostIpAddress"] = ipTransportAmi["local-host"]["local-host-ip-address"];
        intDevice["localHostIpAddrType"] = "ipv4";
        intDevice["localHostPortNum"] = ipTransportAmi["local-host"]["local-host-port-number"];
        intDevice["localHostProtocol"] = ipTransportAmi["local-host"]["local-host-protocol"];
    }

    if (ipTransportAmi["session-details"] ) {
        intDevice["dscp"] = ipTransportAmi["session-details"]["dscp"];
        intDevice["forwardingClass"] = ipTransportAmi["session-details"]["forwarding-class"];
        intDevice["filterUnknownHost"] = ipTransportAmi["session-details"]["filter-unknown-host"];
        intDevice["profile"] = ipTransportAmi["session-details"]["profile"];
    }

    if (ipTransportAmi["tcp"] ) {
        intDevice["tcpMaxRetries"] = ipTransportAmi["tcp"]["tcp-max-retries"];
        intDevice["tcpRetryInterval"] = ipTransportAmi["tcp"]["tcp-retry-interval"];
        intDevice["tcpInactTimeout"] = ipTransportAmi["tcp"]["tcp-in-active-timeout"];
    }
    if (ipTransportAmi["remote-hosts"] && ipTransportAmi["remote-hosts"]["remote-host"]) {

        for (var  k = 0; k < ipTransportAmi["remote-hosts"]["remote-host"].length; k++) {
            let remoteHostDevice = {
                "remoteHostId": ipTransportAmi["remote-hosts"]["remote-host"][k]["remote-host-id"],
                "displayedName": ipTransportAmi["remote-hosts"]["remote-host"][k]["name"],
                "description": ipTransportAmi["remote-hosts"]["remote-host"][k]["description"],
                "remHostIpAddress": ipTransportAmi["remote-hosts"]["remote-host"][k]["remote-host-ip-address"],
                "remHostIpAddrType": "ipv4",
                "remHostPortNum": ipTransportAmi["remote-hosts"]["remote-host"][k]["remote-host-port-number"],
                "checkTcp": ipTransportAmi["remote-hosts"]["remote-host"][k]["check-tcp"],
            };
            if (neSvcType === "vprn") {
                intDevice["children-Set"]["vprn.IpTransportRemoteHost"].push(remoteHostDevice);
            } else {
                intDevice["children-Set"]["ies.IpTransportRemoteHost"].push(remoteHostDevice);
            }
        }
    }
    return intDevice;
};

/*
   function: NFMPtoSiteMapperVpls
    since: NSP 23.11
    short_description: NFMP managed SR - map device model to intent model - Brownfield - site VPLS specific part
    input:
        aInSapIntentModel:
          type: Object
          description: Intent model
          mandatory: True
        aInNfmpSiteChildClsVal:
          type: Object
          description: NFMP device object
          mandatory: True
        aInChildClsName:
          type: String
          description: NFMP VPLS site child class name
          mandatory: True
        aInSiteType:
          type: String
          description: NFMP VPLS site type
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoSiteMapperVpls": |
         this.srSvcUtils.NFMPtoSiteMapperVpls(intentModel["site"], childClassVal, childClass, siteType);
 */
SrSvcFwk.prototype.NFMPtoSiteMapperVpls = function (aInIntSiteModel, aInNfmpSiteChildClsVal, aInChildClsName, aInSiteType, aInEnableProxyNd) {
    if (aInChildClsName === "l2fwd.SiteFib") {
        aInIntSiteModel["mac-flush"] = {};
        aInIntSiteModel["mac-flush"]["tldp"] = {};
        aInIntSiteModel["mac-flush"]["tldp"]["propagate"] = aInNfmpSiteChildClsVal["propagateMacFlush"];
        if (aInNfmpSiteChildClsVal["macFlushOnFail"] && aInNfmpSiteChildClsVal["macFlushOnFail"] === "enabled") {
            aInIntSiteModel["mac-flush"]["tldp"]["send-on-failure"] = true;
        } else {
            aInIntSiteModel["mac-flush"]["tldp"]["send-on-failure"] = false;
        }

        aInIntSiteModel["fdb"] = {};
        aInIntSiteModel["fdb"]["discard-unknown"] = aInNfmpSiteChildClsVal["discardUnknownDestinations"];

        aInIntSiteModel["fdb"]["table"] = {};
        aInIntSiteModel["fdb"]["table"]["high-wmark"] = aInNfmpSiteChildClsVal["highWatermark"];
        aInIntSiteModel["fdb"]["table"]["low-wmark"] = aInNfmpSiteChildClsVal["lowWatermark"];
        aInIntSiteModel["fdb"]["table"]["size"] = aInNfmpSiteChildClsVal["size"];

        aInIntSiteModel["fdb"]["mac-learning"] = {};
        aInIntSiteModel["fdb"]["mac-learning"]["learning"] = aInNfmpSiteChildClsVal["learningEnabled"];
        aInIntSiteModel["fdb"]["mac-learning"]["aging"] = aInNfmpSiteChildClsVal["agingEnabled"];
        aInIntSiteModel["fdb"]["mac-learning"]["local-age-time"] = aInNfmpSiteChildClsVal["localAgeTime"];
        aInIntSiteModel["fdb"]["mac-learning"]["remote-age-time"] = aInNfmpSiteChildClsVal["remoteAgeTime"];
    } else if (aInChildClsName === "shg.Site") {
        aInIntSiteModel["split-horizon-group"] = [];
        if (Array.isArray(aInNfmpSiteChildClsVal)){
            for (let  shgj = 0; shgj < aInNfmpSiteChildClsVal.length; shgj++) {
                let shGroup = {
                    "shg-name": aInNfmpSiteChildClsVal[shgj]["displayedName"],
                    "description": aInNfmpSiteChildClsVal[shgj]["description"]
                }

                shGroup["fdb"] = {
                    "saps": {
                        "discard-unprotected-dest-mac": aInNfmpSiteChildClsVal[shgj]["restrictUnprotectedDestination"]
                    }
                }

                aInIntSiteModel["split-horizon-group"].push(shGroup);
            }
        } else {
            let shGroup = {
                "shg-name": aInNfmpSiteChildClsVal["displayedName"],
                "description": aInNfmpSiteChildClsVal["description"]
            }

            shGroup["fdb"] = {
                "saps": {
                    "discard-unprotected-dest-mac": aInNfmpSiteChildClsVal["restrictUnprotectedDestination"]
                }
            }

            aInIntSiteModel["split-horizon-group"].push(shGroup);
        }
    } else if (aInChildClsName === "l2fwd.SiteIgmpSnooping") {
        if (aInSiteType === "vpls") {
            aInIntSiteModel["igmp-snooping"] = {};
            aInIntSiteModel["igmp-snooping"]["admin-state"] = "locked";
            if (aInNfmpSiteChildClsVal) {
                if (aInNfmpSiteChildClsVal["administrativeState"] === "up") {
                    aInIntSiteModel["igmp-snooping"]["admin-state"] = "unlocked";
                }
                if (aInNfmpSiteChildClsVal["reportSrcAddress"] && aInNfmpSiteChildClsVal["reportSrcAddress"].length > 0) {
                    aInIntSiteModel["igmp-snooping"]["report-source-address"] = aInNfmpSiteChildClsVal["reportSrcAddress"];
                }
                if (aInNfmpSiteChildClsVal["useQuerySrcAddress"] && aInNfmpSiteChildClsVal["useQuerySrcAddress"] == "true") {
                    aInIntSiteModel["igmp-snooping"]["query-source-address"] = aInNfmpSiteChildClsVal["querySrcAddress"];
                } else
                    aInIntSiteModel["igmp-snooping"]["query-source-address"] = "system";
            }
        }
    } else if (aInChildClsName === "vpls.ProxyNd") {
        if (aInEnableProxyNd) {
            if (aInSiteType === "vpls") {
                aInIntSiteModel["proxy-nd"] = {};
                aInIntSiteModel["proxy-nd"]["admin-state"] = "locked";
                if (aInNfmpSiteChildClsVal) {
                    if (aInNfmpSiteChildClsVal["administrativeState"] === "up") {
                        aInIntSiteModel["proxy-nd"]["admin-state"] = "unlocked";
                    }
                    aInIntSiteModel["proxy-nd"]["evpn"] = {
                        "advertise-neighbor-type": aInNfmpSiteChildClsVal["evpnNdAdvRouter"]
                    }
                }
            }
        }
    }

    return aInIntSiteModel;
};

/*
   function: siteToNFMPMapperVpls
    since: NSP 23.11
    short_description: NFMP managed SR - map intent model to device model - site VPLS specific part
    input:
        aInSiteDevice:
          type: Object
          description: NFMP payload with site
          mandatory: True
        aInSiteAmi:
          type: Object
          description: Site level intent model objects
          mandatory: True
        deviceId:
          type: Object
          description: NE system ip
          mandatory: True
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with site
    examples:
      "siteToNFMPMapperVpls": |
          this.srSvcUtils.siteToNFMPMapperVpls(sitePayload, siteObjMap);
 */
SrSvcFwk.prototype.siteToNFMPMapperVpls = function (aInSiteDevice, aInSiteAmi, aInIntType, aInIsIxrNode) {
    aInSiteDevice["children-Set"]["l2fwd.SiteFib"] = {};

    if (aInSiteAmi["mac-flush"] && aInSiteAmi["mac-flush"]["tldp"] && aInSiteAmi["mac-flush"]["tldp"]["propagate"]) {
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["propagateMacFlush"] = aInSiteAmi["mac-flush"]["tldp"]["propagate"];
    } else {
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["propagateMacFlush"] = false;
    }

    if (aInSiteAmi["mac-flush"] && aInSiteAmi["mac-flush"]["tldp"] && aInSiteAmi["mac-flush"]["tldp"]["send-on-failure"]) {
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["macFlushOnFail"] = "enabled";
    } else {
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["macFlushOnFail"] = "disabled";
    }


    (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["discard-unknown"]) ?
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["discardUnknownDestinations"] = aInSiteAmi["fdb"]["discard-unknown"] :
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["discardUnknownDestinations"] = false;
    (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["table"] && aInSiteAmi["fdb"]["table"]["high-wmark"]) ?
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["highWatermark"] = aInSiteAmi["fdb"]["table"]["high-wmark"] :
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["highWatermark"] = 95;
    (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["table"] && aInSiteAmi["fdb"]["table"]["low-wmark"]) ?
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["lowWatermark"] = aInSiteAmi["fdb"]["table"]["low-wmark"] :
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["lowWatermark"] = 90;
    (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["table"] && aInSiteAmi["fdb"]["table"]["size"]) ?
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["size"] = aInSiteAmi["fdb"]["table"]["size"] :
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["size"] = 250;
    if (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["mac-learning"]) {
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["learningEnabled"] = true;
        if (aInSiteAmi["fdb"]["mac-learning"]["learning"] === false) {
            aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["learningEnabled"] = false;
        }
    }
    if (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["mac-learning"]) {
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["agingEnabled"] = true;
        if (aInSiteAmi["fdb"]["mac-learning"]["aging"] === false) {
            aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["agingEnabled"] = false;
        }
    }
    (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["mac-learning"] && aInSiteAmi["fdb"]["mac-learning"]["local-age-time"])?
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["localAgeTime"] = aInSiteAmi["fdb"]["mac-learning"]["local-age-time"]:
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["localAgeTime"] = 300;
    (aInSiteAmi["fdb"] && aInSiteAmi["fdb"]["mac-learning"] && aInSiteAmi["fdb"]["mac-learning"]["remote-age-time"])?
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["remoteAgeTime"] = aInSiteAmi["fdb"]["mac-learning"]["remote-age-time"] :
        aInSiteDevice["children-Set"]["l2fwd.SiteFib"]["remoteAgeTime"] = 900;


    aInSiteDevice["children-Set"]["shg.Site"] = [];
    if (aInSiteAmi["split-horizon-group"]) {
        for (let  shgi = 0; shgi < aInSiteAmi["split-horizon-group"].length; shgi++) {
            let shgAmi = aInSiteAmi["split-horizon-group"][shgi];
            let lShGroup = {
                "displayedName": shgAmi["shg-name"],
                "description": shgAmi["description"]
            }

            if (!aInIsIxrNode && (aInIntType && aInIntType !== "evpn-vpls") && (shgAmi["fdb"] && shgAmi["fdb"]["saps"])) {
                if (shgAmi["fdb"]["saps"]["discard-unprotected-dest-mac"]) {
                    lShGroup["restrictUnprotectedDestination"] = true;
                } else {
                    lShGroup["restrictUnprotectedDestination"] = false;
                }
            }

            aInSiteDevice["children-Set"]["shg.Site"].push(lShGroup);
        }
    }

    if (aInSiteAmi["igmp-snooping"]) {
        if (!aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]) {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"] = {};
        }
        if (aInSiteAmi["igmp-snooping"]["admin-state"] === "unlocked") {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["administrativeState"] = "up";
        } else {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["administrativeState"] = "down";
        }
        if (aInSiteAmi["igmp-snooping"]["report-source-address"] &&
            aInSiteAmi["igmp-snooping"]["report-source-address"].length > 0) {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["reportSrcAddress"] = aInSiteAmi["igmp-snooping"]["report-source-address"];
        } else {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["reportSrcAddress"] = "0.0.0.0";
        }

        if (aInSiteAmi["igmp-snooping"]["query-source-address"] &&
            aInSiteAmi["igmp-snooping"]["query-source-address"] !== "system") {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["useQuerySrcAddress"] = true;
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["querySrcAddress"] = aInSiteAmi["igmp-snooping"]["query-source-address"];
        } else {
            aInSiteDevice["children-Set"]["l2fwd.SiteIgmpSnooping"]["useQuerySrcAddress"] = false;
        }
    }

    if (aInSiteAmi["proxy-nd"]) {
        aInSiteDevice["enableProxyNd"] = true;
        if (!aInSiteDevice["children-Set"]["vpls.ProxyNd"]) {
            aInSiteDevice["children-Set"]["vpls.ProxyNd"] = {};
        }
        if (aInSiteAmi["proxy-nd"]["admin-state"] === "unlocked") {
            aInSiteDevice["children-Set"]["vpls.ProxyNd"]["administrativeState"] = "up";
        } else {
            aInSiteDevice["children-Set"]["vpls.ProxyNd"]["administrativeState"] = "down";
        }
        aInSiteDevice["children-Set"]["vpls.ProxyNd"]["evpnNdAdvRouter"] = aInSiteAmi["proxy-nd"]["evpn"]["advertise-neighbor-type"];
    } else {
        aInSiteDevice["enableProxyNd"] = false;
    }
};

/*
   function: NFMPtoSdpMapperVpls
    since: NSP 23.11
    short_description: NFMP managed SR - map device model to intent model - Brownfield - sdp VPLS specific part
    input:
        aInSdpIntModel
          type: Object
          description: Intent model
          mandatory: True
        aInNfmpSdpModel:
          type: Object
          description: NFMP device object
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoSdpMapperVpls": |
          this.srSvcUtils.NFMPtoSdpMapperVpls(lSpoke, siteId, childClassVal[j], intentModel["service"]["ne-service-id"]);
 */
SrSvcFwk.prototype.NFMPtoSdpMapperVpls = function (aInSdpIntModel, aInNfmpSdpModel) {
    if (!aInSdpIntModel["igmp-snooping"]) {
        aInSdpIntModel["igmp-snooping"] = {};
    }
    if (aInNfmpSdpModel["children-Set"] &&
        aInNfmpSdpModel["children-Set"]["svt.SdpBindingIgmpSnpgCfg"] &&
        aInNfmpSdpModel["children-Set"]["svt.SdpBindingIgmpSnpgCfg"]["maxNbrGroups"] &&
        aInNfmpSdpModel["children-Set"]["svt.SdpBindingIgmpSnpgCfg"]["maxNbrGroups"] > 0) {
        aInSdpIntModel["igmp-snooping"] = {
            "maximum-number-groups": aInNfmpSdpModel["children-Set"]["svt.SdpBindingIgmpSnpgCfg"]["maxNbrGroups"]
        }
    }

    if (!aInSdpIntModel["fdb"]) {
        aInSdpIntModel["fdb"] = {};
    }
    if (aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]) {
        aInSdpIntModel["fdb"] = {
            "discard-unknown-source": aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["discardUnknownSource"],
            "auto-learn-mac-protect": aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["autoLearnMacProtect"]
        }

        if (aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["maxEntries"] > 0) {
            aInSdpIntModel["fdb"]["maximum-mac-addresses"] =
                aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["maxEntries"];
        }

        if (aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSource"] === "true") {
            let actionDev = aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSourceAction"];
            if (aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSourceAction"]) {
                if (actionDev === "disable") {
                    aInSdpIntModel["fdb"]["protected-src-mac-violation-action"] = "sdp-bind-oper-down";
                } else if (actionDev === "alarmOnly") {
                    aInSdpIntModel["fdb"]["protected-src-mac-violation-action"] = "alarm-only";
                } else if (actionDev === "disCardFrame") {
                    aInSdpIntModel["fdb"]["protected-src-mac-violation-action"] = "discard";
                }
            }
        }

        if (aInSdpIntModel["sdp-type"] === "spoke") {
            if (!aInSdpIntModel["fdb"]["mac-learning"]) {
                aInSdpIntModel["fdb"]["mac-learning"] = {}
            }
            aInSdpIntModel["fdb"]["mac-learning"]["learning"] =
                aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["learningEnabled"];
            aInSdpIntModel["fdb"]["mac-learning"]["aging"] =
                aInNfmpSdpModel["children-Set"]["l2fwd.CircuitFib"]["agingEnabled"];
        }
    }

    if (aInNfmpSdpModel["children-Set"]["l2fwd.MeshCircuitFib"] && aInNfmpSdpModel["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSource"] === "true") {
        aInSdpIntModel["fdb"] = {};
        let actionDev = aInNfmpSdpModel["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSourceAction"];
        if (aInNfmpSdpModel["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSourceAction"]) {
            if (actionDev === "disable") {
                aInSdpIntModel["fdb"]["protected-src-mac-violation-action"] = "sdp-bind-oper-down";
            } else if (actionDev === "alarmOnly") {
                aInSdpIntModel["fdb"]["protected-src-mac-violation-action"] = "alarm-only";
            } else if (actionDev === "disCardFrame") {
                aInSdpIntModel["fdb"]["protected-src-mac-violation-action"] = "discard";
            }
        }
    }

    if (aInNfmpSdpModel["macPinning"]) {
        if (aInNfmpSdpModel["macPinning"] === "enabled") {
            aInSdpIntModel["fdb"]["mac-pinning"] = true;
        } else {
            aInSdpIntModel["fdb"]["mac-pinning"] = false;
        }
    }

    if (aInNfmpSdpModel["controlWord"]) {
        if (aInNfmpSdpModel["controlWord"] === "preferred") {
            aInSdpIntModel["control-word"] = true;
        } else {
            aInSdpIntModel["control-word"] = false;
        }
    }

    if (aInNfmpSdpModel["forceQinqVcFwdingWithType"] && aInNfmpSdpModel["forceQinqVcFwdingWithType"] === "stagCtag") {
        aInSdpIntModel["force-vc-forwarding"] = "qinq-s-tag-c-tag";
    } else if (aInNfmpSdpModel["forceQinqVcFwdingWithType"] && aInNfmpSdpModel["forceQinqVcFwdingWithType"] === "ctagCtag") {
        aInSdpIntModel["force-vc-forwarding"] = "qinq-c-tag-c-tag";
    } else if (aInNfmpSdpModel["forceVlanVcForwarding"] == "true")
        aInSdpIntModel["force-vc-forwarding"] = "vlan";

    if (aInNfmpSdpModel["children-Set"]["vpls.InterfacePimSnoopingV6"]) {
        if (!aInSdpIntModel["pim-snooping"]) {
            aInSdpIntModel["pim-snooping"] = {}
        }
        if (aInNfmpSdpModel["children-Set"]["vpls.InterfacePimSnoopingV6"]["maxGroups"]) {
            aInSdpIntModel["pim-snooping"]["maximum-number-groups"] = aInNfmpSdpModel["children-Set"]["vpls.InterfacePimSnoopingV6"]["maxGroups"];
        }
    }

    return aInSdpIntModel;
};

/*
   function: sdpToNFMPMapperVpls
    since: NSP 23.11
    short_description: NFMP managed SR - map intent model to device model - sdp VPLS specific part
    input:
        aInSdpDevice:
          type: Object
          description: NFMP payload with site
          mandatory: True
        aInSdpAmi:
          type: Object
          description: sdp level intent model objects
          mandatory: True
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with sdp
    examples:
      "sdpToNFMPMapperVpls": |
          this.srSvcUtils.sdpToNFMPMapperVpls(sdpDevice, sdpAmi, siteObjMap,svcObjMap["ne-service-id"]);
*/
SrSvcFwk.prototype.sdpToNFMPMapperVpls = function (aInSdpDevice, aInSdpAmi, deviceId, aInIntType, aInIsIxrNode) {
    if (aInSdpDevice) {
        if (!aInSdpDevice["children-Set"]) {
            aInSdpDevice["children-Set"] = {};
        }

        if (aInSdpAmi["fdb"]) {
            if (aInSdpAmi["sdp-type"] !== "mesh") {
                if (!aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]) {
                    aInSdpDevice["children-Set"]["l2fwd.CircuitFib"] = {};
                }
                if (aInSdpAmi["fdb"]["maximum-mac-addresses"] && aInSdpAmi["fdb"]["maximum-mac-addresses"] > 0) {
                    aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["maxEntries"] =
                        aInSdpAmi["fdb"]["maximum-mac-addresses"];
                } else {
                    aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["maxEntries"] = 0;
                }
                aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["discardUnknownSource"] =
                    aInSdpAmi["fdb"]["discard-unknown-source"];
                aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["autoLearnMacProtect"] =
                    aInSdpAmi["fdb"]["auto-learn-mac-protect"];
                if (aInSdpAmi["fdb"]["mac-learning"]) {
                    aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["learningEnabled"] =
                        aInSdpAmi["fdb"]["mac-learning"]["learning"];
                    aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["agingEnabled"] =
                        aInSdpAmi["fdb"]["mac-learning"]["aging"];
                }

                if (!aInIsIxrNode && aInIntType !== "evpn-vpls") {
                    if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"]) {
                        aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSource"] = "true";
                        if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"] === "sdp-bind-oper-down") {
                            aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSourceAction"] = "disable";
                        } else if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"] === "alarm-only") {
                            aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSourceAction"] = "alarmOnly";
                        } else if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"] === "discard"){
                            aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSourceAction"] = "disCardFrame";
                        }
                    } else {
                        aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSource"] = "false";
                        aInSdpDevice["children-Set"]["l2fwd.CircuitFib"]["restrictProtectedSourceAction"] = "disable";
                    }
                }
            } else {
                let isSar = this.sfUtils.is7705Node(deviceId);
         
                if (!aInIsIxrNode && aInIntType !== "evpn-vpls" && !isSar) {
                    if (!aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]) {
                        aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"] = {};
                    }
                    if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"]) {
                        aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSource"] = "true";
                        if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"] === "sdp-bind-oper-down") {
                            aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSourceAction"] = "disable";
                        } else if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"] === "alarm-only") {
                            aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSourceAction"] = "alarmOnly";
                        } else if (aInSdpAmi["fdb"]["protected-src-mac-violation-action"] === "discard"){
                            aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSourceAction"] = "disCardFrame";
                        }
                    } else {
                        aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSource"] = "false";
                        aInSdpDevice["children-Set"]["l2fwd.MeshCircuitFib"]["restrictProtectedSourceAction"] = "disable";
                    }
                }
            }

            if (!(aInSdpAmi["fdb"]["mac-pinning"] == null)) {
                if (aInSdpAmi["fdb"]["mac-pinning"]) {
                    aInSdpDevice["macPinning"] = "enabled";
                } else {
                    aInSdpDevice["macPinning"] = "disabled";
                }
            }
        }

        if (aInSdpAmi["igmp-snooping"]) {
            if (!aInSdpDevice["children-Set"]["svt.SdpBindingIgmpSnpgCfg"]) {
                aInSdpDevice["children-Set"]["svt.SdpBindingIgmpSnpgCfg"] = {};
            }
            if (aInSdpAmi["igmp-snooping"]["maximum-number-groups"]) {
                aInSdpDevice["children-Set"]["svt.SdpBindingIgmpSnpgCfg"]["maxNbrGroups"] = aInSdpAmi["igmp-snooping"]["maximum-number-groups"];
            } else {
                aInSdpDevice["children-Set"]["svt.SdpBindingIgmpSnpgCfg"]["maxNbrGroups"] = 0;
            }
        }

        let isSar = deviceId ? this.sfUtils.is7705Node(deviceId) : false;
        if(!isSar) {
            if (aInSdpAmi["dhcp"] && aInSdpAmi["dhcp"]["snoop"]) {
                aInSdpDevice["children-Set"]["vpls.CircuitDhcpRelayCfg"] = {"snooping": "enabled"}
            } else if (aInSdpAmi["dhcp"]) {
                aInSdpDevice["children-Set"]["vpls.CircuitDhcpRelayCfg"] = {"snooping": "disabled"}
            }
        }
    }

    if (aInSdpAmi["control-word"]) {
        aInSdpDevice["controlWord"] = "preferred";
    } else {
        aInSdpDevice["controlWord"] = "notPreferred";
    }

    if (aInSdpAmi["force-vc-forwarding"]){
        if (aInSdpAmi["force-vc-forwarding"] === "vlan"){
            aInSdpDevice["forceVlanVcForwarding"] = true;
            aInSdpDevice["forceQinqVcFwdingWithType"] = "none"
        } else if (aInSdpAmi["force-vc-forwarding"] === "qinq-c-tag-c-tag"){
            aInSdpDevice["forceQinqVcFwdingWithType"] = "ctagCtag"
            aInSdpDevice["forceVlanVcForwarding"] = false;
        } else if (aInSdpAmi["force-vc-forwarding"] === "qinq-s-tag-c-tag"){
            aInSdpDevice["forceQinqVcFwdingWithType"] = "stagCtag"
            aInSdpDevice["forceVlanVcForwarding"] = false;
        } else {
            aInSdpDevice["forceVlanVcForwarding"] = false;
            aInSdpDevice["forceQinqVcFwdingWithType"] = "none";
        }
    }

    return aInSdpDevice;
};

/*
   function: NFMPtoSapMapperVpls
    since: NSP 23.11
    short_description: NFMP managed SR - map device model to intent model - Brownfield - SAP VPLS specific part
    input:
        aInSapIntentModel:
          type: Object
          description: Intent model
          mandatory: True
        aInNfmpSapModel:
          type: Object
          description: NFMP device object
          mandatory: True
        siteId:
          type: String
          description: NE system ip
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPtoSapMapperVpls": |
         self.srSvcUtils.NFMPtoSapMapperVpls(lSapIntentModel1, childClassVal, siteId);
 */
SrSvcFwk.prototype.NFMPtoSapMapperVpls = function (aInSapIntentModel, aInNfmpSapModel, siteId, intType) {
    let shgPointer = aInNfmpSapModel["shgSitePointer"];
    if (shgPointer && shgPointer.indexOf("undefined") === -1) {
        let shgStrArray = shgPointer.split(":" + siteId + ":shg-");
        if (shgStrArray.length > 1) {
            aInSapIntentModel["split-horizon-group"] = shgStrArray[1];
        }
    }

    if (aInNfmpSapModel["memberOperGroupName"] !== "" && aInNfmpSapModel["memberOperGroupName"] !== ""){
        aInSapIntentModel["oper-group"] = aInNfmpSapModel["memberOperGroupName"];
    }

    if (aInNfmpSapModel["children-Set"]) {
        if (aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]) {
            aInSapIntentModel["fdb"] = {
                "discard-unknown-source": aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["discardUnknownSource"],
                "auto-learn-mac-protect": aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["autoLearnMacProtect"]
            }
            if (aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["maxEntries"] &&
                aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["maxEntries"] > 0) {
                aInSapIntentModel["fdb"]["maximum-mac-addresses"] = aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["maxEntries"];
            } else {
                aInSapIntentModel["fdb"]["maximum-mac-addresses"] = null;
            }

            if (!aInSapIntentModel["fdb"]["mac-learning"]) {
                aInSapIntentModel["fdb"]["mac-learning"] = {}
            }
            aInSapIntentModel["fdb"]["mac-learning"]["learning"] = aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["learningEnabled"];
            aInSapIntentModel["fdb"]["mac-learning"]["aging"] = aInNfmpSapModel["children-Set"]["l2fwd.AccessInterfaceFib"]["agingEnabled"];
        }

        if ( intType !== "evpn-vpls") {
            if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"] &&
                aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]["macPinning"]) {
                if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]["macPinning"] === "enabled") {
                    aInSapIntentModel["fdb"]["mac-pinning"] = true;
                } else {
                    aInSapIntentModel["fdb"]["mac-pinning"] = false;
                }
            }

            if (aInNfmpSapModel["children-Set"]["vpls.CircuitDhcpRelayCfg"] &&
                aInNfmpSapModel["children-Set"]["vpls.CircuitDhcpRelayCfg"]["snooping"]) {
                aInSapIntentModel["dhcp"] = {"snoop":true}
            } else {
                aInSapIntentModel["dhcp"] = {"snoop":false}
            }
        }

        if (aInNfmpSapModel["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]){
            aInSapIntentModel["dhcp"] = {"lease-populate":{
                    "max-leases": aInNfmpSapModel["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["leasePopulate"]
                }
            }
            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["snooping"] === "enabled")
                aInSapIntentModel["dhcp"]["snoop"] = true;
            else
                aInSapIntentModel["dhcp"]["snoop"] = false;

            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["administrativeState"] === "enabled")
                aInSapIntentModel["dhcp"]["admin-state"] = "unlocked"
            else
                aInSapIntentModel["dhcp"]["admin-state"] = "locked"

        }

        if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]){
            if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] === "sourceIpAddr")
                aInSapIntentModel["anti-spoof"] = "source-ip-addr";
            else if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] === "sourceMacAddr")
                aInSapIntentModel["anti-spoof"] = "source-mac-addr";
            else if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] === "sourceIpAndMacAddr")
                aInSapIntentModel["anti-spoof"] = "source-ip-and-mac-addr";
            else if (aInNfmpSapModel["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] === "nextHopIpAndMacAddr")
                aInSapIntentModel["anti-spoof"] = "next-hop-ip-and-mac-addr";
        }

        if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]){
            aInSapIntentModel["igmp-snooping"] = {
                "import-policy" : aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["importPolicy"],
                "mcac" : {
                    "bandwidth":{
                        "total" : "unlimited",
                        "mandatory" : "unlimited"
                    }
                },
                "static" : {
                    "group" :[]
                }
            }
            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["maxNbrGroups"] != "0")
                aInSapIntentModel["igmp-snooping"]["maximum-number-groups"] = aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["maxNbrGroups"];
            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["sendQueries"] === "enabled")
                aInSapIntentModel["igmp-snooping"]["send-queries"] = true;
            else
                aInSapIntentModel["igmp-snooping"]["send-queries"] = false;

            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["mCastCacPolicyPointer"] !== "" && aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["mCastCacPolicyPointer"] !== "N/A")
                aInSapIntentModel["igmp-snooping"]["mcac"]["policy"] = aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["mCastCacPolicyPointer"].replace("Multicast CAC:","");

            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["unconstrainedBandwidth"] != "-1")
                aInSapIntentModel["igmp-snooping"]["mcac"]["bandwidth"]["total"] = aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["unconstrainedBandwidth"];

            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["preRsvdMandatoryBandwidth"] != "-1")
                aInSapIntentModel["igmp-snooping"]["mcac"]["bandwidth"]["mandatory"] = aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["preRsvdMandatoryBandwidth"];

            if (aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"] &&
                aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp"]){
                if (Array.isArray(aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp"])){
                    aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp"].forEach(function (lGroup) {
                        igmpSnoopingStaticMCGrpReverse(lGroup, aInSapIntentModel["igmp-snooping"]["static"]["group"])
                    })
                } else {
                    igmpSnoopingStaticMCGrpReverse(aInNfmpSapModel["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp"], aInSapIntentModel["igmp-snooping"]["static"]["group"])
                }
            }
        }

        if (aInNfmpSapModel["children-Set"]["vpls.InterfacePimSnooping"]){
            if (!aInSapIntentModel["pim-snooping"]) {
                aInSapIntentModel["pim-snooping"] = {}
            }
            if (aInNfmpSapModel["children-Set"]["vpls.InterfacePimSnooping"]["maxGroups"]) {
                aInSapIntentModel["pim-snooping"]["maximum-number-groups"] = aInNfmpSapModel["children-Set"]["vpls.InterfacePimSnooping"]["maxGroups"];
            }
        }
    }
    return aInSapIntentModel;
};

function igmpSnoopingStaticMCGrpReverse(nfmpAmi, intentGrp) {
    let found = false;
    intentGrp.forEach(function (lIntentGroup) {
        if (lIntentGroup["group-address"] === nfmpAmi["grpAddr"] && nfmpAmi["srcAddr"] !== "0.0.0.0"){
            lIntentGroup["source"].push({"source-address": nfmpAmi["srcAddr"]});
            found = true;
        }
    })
    if (!found){
        if (nfmpAmi["srcAddr"] === "0.0.0.0")
            intentGrp.push({"group-address":nfmpAmi["grpAddr"], "starg" :{}})
        else
            intentGrp.push({"group-address":nfmpAmi["grpAddr"], "source" :[{"source-address": nfmpAmi["srcAddr"]}]})
    }
}

/*
   function: sapToNFMPMapperVpls
    since: NSP 23.11
    short_description: NFMP managed SR - map intent model to device model - SAP VPLS specific part
    input:
        aInSapDevice:
          type: Object
          description: NFMP payload with SAP
          mandatory: True
        svcObj:
          type: Object
          description: Service intent model objects
          mandatory: True
        sapAmi:
          type: Object
          description: SAP level intent model objects
          mandatory: True
        deviceId:
          type: Object
          description: NE system ip
          mandatory: True
    output:
      nfmpDeviceModel:
        type: Object
        description: NFMP payload with SAP
    examples:
      "sapToNFMPMapperVpls": |
          this.srSvcUtils.sapToNFMPMapperVpls(sapDevice, svcObjMap, sapAmi, deviceId);
 */
SrSvcFwk.prototype.sapToNFMPMapperVpls = function (aInSapDevice, svcObj, sapAmi, deviceId, intType) {
    if (sapAmi["split-horizon-group"]) {
        aInSapDevice["shgSitePointer"] = svcObj["serviceMgrId"] + ":" + deviceId.replaceAll(":","_") + ":shg-" + sapAmi["split-horizon-group"];
    }

    if (sapAmi["oper-group"]){
        aInSapDevice["memberOperGroupName"] = sapAmi["oper-group"];
    } else
        aInSapDevice["memberOperGroupName"] = ""

    if (!aInSapDevice["children-Set"]) {
        aInSapDevice["children-Set"] = {};
    }

    let isCPSap = (sapAmi["connection-profile-id"] && sapAmi["connection-profile-id"] !== null);
    if (!aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"] && !isCPSap) {
        aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"] = {};
    }
    let isSar = this.sfUtils.is7705Node(deviceId);
    if ( intType !== "evpn-vpls") {
        aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"] = {
            "macPinning": "disabled"
        };
        if(!isSar)
            aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] = "disabled";
    }

    if (sapAmi["fdb"]) {
        if (!aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]) {
            aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"] = {};
        }

        if (sapAmi["fdb"]["maximum-mac-addresses"] && sapAmi["fdb"]["maximum-mac-addresses"] > 0) {
            aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]["maxEntries"] = sapAmi["fdb"]["maximum-mac-addresses"];
        } else {
            aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]["maxEntries"] = 0;
        }

        if (!(this.sfUtils.isIxrR6OrENode(deviceId) || this.sfUtils.isIxrsNode(deviceId))) aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]["discardUnknownSource"] = sapAmi["fdb"]["discard-unknown-source"];
        aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]["autoLearnMacProtect"] = sapAmi["fdb"]["auto-learn-mac-protect"];
        aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]["learningEnabled"] = sapAmi["fdb"]["mac-learning"]["learning"];
        aInSapDevice["children-Set"]["l2fwd.AccessInterfaceFib"]["agingEnabled"] = sapAmi["fdb"]["mac-learning"]["aging"];

        if ( intType !== "evpn-vpls") {
            if (sapAmi["fdb"]["mac-pinning"]) {
                aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["macPinning"] = "enabled";
            } else {
                aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["macPinning"] = "disabled";
            }
        }
    }

    if (sapAmi["dhcp"]) {
        aInSapDevice["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"] = {
            "leasePopulate" : 0
        };
        if (sapAmi["dhcp"]["snoop"])
            aInSapDevice["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["snooping"] = "enabled";
        else
            aInSapDevice["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["snooping"] = "disabled";

        if (sapAmi["dhcp"]["admin-state"] === "locked")
            aInSapDevice["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["administrativeState"] = "disabled";
        else
            aInSapDevice["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["administrativeState"] = "enabled";

        if (sapAmi["dhcp"]["lease-populate"] && sapAmi["dhcp"]["lease-populate"]["max-leases"])
            aInSapDevice["children-Set"]["vpls.L2AccessItfDhcpRelayCfg"]["leasePopulate"] =  sapAmi["dhcp"]["lease-populate"]["max-leases"];
    }

    if (!isSar) {
        if (sapAmi["anti-spoof"]) {
            if (sapAmi["anti-spoof"] === "source-ip-addr")
                aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] = "sourceIpAddr";
            else if (sapAmi["anti-spoof"] === "source-mac-addr")
                aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] = "sourceMacAddr";
            else if (sapAmi["anti-spoof"] === "source-ip-and-mac-addr")
                aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] = "sourceIpAndMacAddr";
            else if (sapAmi["anti-spoof"] === "next-hop-ip-and-mac-addr")
                aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] = "nextHopIpAndMacAddr";
        } else if (sapAmi["anti-spoof"] === false) {
            aInSapDevice["children-Set"]["antispoof.L2AntiSpoofing"]["antiSpoofing"] = "disabled"
        }
    }

    if (!isCPSap) {
        if (sapAmi["igmp-snooping"]){
            aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"] = {
                "importPolicy" : "N/A",
                "mCastCacPolicyPointer" : "",
                "unconstrainedBandwidth" : "-1",
                "preRsvdMandatoryBandwidth" : "-1",
                "children-Set" : {
                    "vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp" : []
                }
            };
            if (sapAmi["igmp-snooping"]["import-policy"])
                aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["importPolicy"] = sapAmi["igmp-snooping"]["import-policy"];

            if (sapAmi["igmp-snooping"]["maximum-number-groups"])
                aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["maxNbrGroups"] = sapAmi["igmp-snooping"]["maximum-number-groups"];
            else
                aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["maxNbrGroups"] = 0;

            if (sapAmi["igmp-snooping"]["send-queries"])
                aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["sendQueries"] = "enabled"
            else
                aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["sendQueries"] = "disabled"

            if (sapAmi["igmp-snooping"]["mcac"]){
                if(sapAmi["igmp-snooping"]["mcac"]["policy"]){
                    aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["mCastCacPolicyPointer"] = "Multicast CAC:" + sapAmi["igmp-snooping"]["mcac"]["policy"];
                }
                if (sapAmi["igmp-snooping"]["mcac"]["bandwidth"]){
                    if (sapAmi["igmp-snooping"]["mcac"]["bandwidth"]["total"] && sapAmi["igmp-snooping"]["mcac"]["bandwidth"]["total"] !== "unlimited")
                        aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["unconstrainedBandwidth"] = sapAmi["igmp-snooping"]["mcac"]["bandwidth"]["total"];
                    else
                        aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["unconstrainedBandwidth"] = "-1";

                    if (sapAmi["igmp-snooping"]["mcac"]["bandwidth"]["mandatory"] && sapAmi["igmp-snooping"]["mcac"]["bandwidth"]["mandatory"] !== "unlimited")
                        aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["preRsvdMandatoryBandwidth"] = sapAmi["igmp-snooping"]["mcac"]["bandwidth"]["mandatory"];
                    else
                        aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["preRsvdMandatoryBandwidth"] = "-1"
                }
            }
            if (sapAmi["igmp-snooping"]["static"] && sapAmi["igmp-snooping"]["static"]["group"]){
                sapAmi["igmp-snooping"]["static"]["group"].forEach(function (lGroup) {
                    let lGroupNfmp = {"grpAddr":lGroup["group-address"]}
                    if (lGroup["starg"]) {
                        lGroupNfmp["srcAddr"] = "0.0.0.0";
                        aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp"].push(lGroupNfmp);
                    } else if (lGroup["source"]){
                        lGroup["source"].forEach(function (lSource) {
                            lGroupNfmp["srcAddr"] = lSource["source-address"];
                            aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"]["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp"].push(JSON.parse(JSON.stringify(lGroupNfmp)));
                        })
                    }
                })
            }
        } else {
            aInSapDevice["children-Set"]["vpls.L2AccessInterfaceIgmpSnpgCfg"] = {
                "importPolicy" : "N/A",
                "mCastCacPolicyPointer" : "",
                "unconstrainedBandwidth" : "-1",
                "preRsvdMandatoryBandwidth" : "-1",
                "children-Set" : {
                    "vpls.L2AccessInterfaceIgmpSnpgStaticMcastGrp" : []
                }
            };
        }
    }
    return aInSapDevice;
};

/*
   function: NFMPToIntentQoSMapperIng
    since: NSP 23.11
    short_description: NFMP managed SR - map device model to intent model - Brownfield - vpls/epipe ingress specific part
    input:
        aInSapIntentModel:
          type: Object
          description: Intent model
          mandatory: True
        aInNfmpSap:
          type: Object
          description: NFMP device object
          mandatory: True
        aInNeId:
          type: String
          description: device NE ID
          mandatory: True
    output:
      intentModel:
        type: Object
        description: Intent model
    examples:
      "NFMPToIntentQoSMapperIng": |
             this.NFMPToIntentQoSMapperIng(aInSapIntentModel, aInNfmpSapModel, siteId);
 */
SrSvcFwk.prototype.NFMPToIntentQoSMapperIng = function (aInSapIntentModel, aInNfmpSap, aInNeId) {
    if (this.sfUtils.isIxrR6OrENode(aInNeId)) {
        if (!aInSapIntentModel["ingress"]) aInSapIntentModel["ingress"] = {};
        aInSapIntentModel["ingress"]["aggregate-policer"] = {};
        if (aInNfmpSap["sapIngressAggregateMeterRate"] == -1) {
            aInSapIntentModel["ingress"]["aggregate-policer"]["rate"] = "max";
        } else if (aInNfmpSap["sapIngressAggregateMeterRate"] >= 144 && aInNfmpSap["sapIngressAggregateMeterRate"] <= 1000000000){
            aInSapIntentModel["ingress"]["aggregate-policer"]["rate"] = aInNfmpSap["sapIngressAggregateMeterRate"];
        }
        if (aInNfmpSap["sapIngressAggregateMeterBurst"] == -1) {
            aInSapIntentModel["ingress"]["aggregate-policer"]["burst"] = "default";
        } else {
            aInSapIntentModel["ingress"]["aggregate-policer"]["burst"] = aInNfmpSap["sapIngressAggregateMeterBurst"];
        }
        if (aInNfmpSap["sapIngressAggregateMeterCIR"] == -1) {
            aInSapIntentModel["ingress"]["aggregate-policer"]["cir"] = "max";
        } else if (aInNfmpSap["sapIngressAggregateMeterCIR"] != -2) {
            aInSapIntentModel["ingress"]["aggregate-policer"]["cir"] = aInNfmpSap["sapIngressAggregateMeterCIR"];
        }
        if (aInNfmpSap["sapIngressAggregateMeterCBS"] == -1) {
            aInSapIntentModel["ingress"]["aggregate-policer"]["cbs"] = "default";
        } else if (aInNfmpSap["sapIngressAggregateMeterCBS"] != -2) {
            aInSapIntentModel["ingress"]["aggregate-policer"]["cbs"] = aInNfmpSap["sapIngressAggregateMeterCBS"];
        }

        let isQinQ = aInNfmpSap["innerEncapValue"] && aInNfmpSap["innerEncapValue"] !== "0";
        let vlanAction = aInNfmpSap["ingressQtagManipulateAction"];
        if ((vlanAction !== "none" && (!isQinQ || vlanAction !== "popOuterAndInner") && vlanAction !== "popOuter")) {
            //NON default VLAN is configured
            aInSapIntentModel["ingress"]["vlan-manipulation"] = {};
            if (vlanAction === "pushOuterAndInner" || vlanAction === "pushOuter") {
                aInSapIntentModel["ingress"]["vlan-manipulation"]["action"] = "push";     
            } else if (vlanAction === "preserve") {
                aInSapIntentModel["ingress"]["vlan-manipulation"]["action"] = "preserve";    
            } else if (vlanAction === "popOuter" || vlanAction === "replaceOuter") {
                aInSapIntentModel["ingress"]["vlan-manipulation"]["action"] = "translate-1-to-1";
            } else if (vlanAction === "popOuterAndReplaceInner") {
                aInSapIntentModel["ingress"]["vlan-manipulation"]["action"] = "translate-2-to-1";
            } else if (vlanAction === "popOuterAndInner" || vlanAction === "replaceOuterAndInner") {
                aInSapIntentModel["ingress"]["vlan-manipulation"]["action"] = "translate-2-to-2";
            }
            aInSapIntentModel["ingress"]["vlan-manipulation"]["inner-tag"] = aInNfmpSap["ingressInnerQtag"] === "-1" ? "null" : aInNfmpSap["ingressInnerQtag"];  
            aInSapIntentModel["ingress"]["vlan-manipulation"]["outer-tag"] = aInNfmpSap["ingressOuterQtag"] === "-1" ? "null" : aInNfmpSap["ingressOuterQtag"];

        }
    }
    if (this.sfUtils.is7705Node(aInNeId)){
        if (aInNfmpSap["ingressSchedulerMode"]) {
            aInSapIntentModel["ingress"]["scheduler-mode"] =  aInNfmpSap["ingressSchedulerMode"];  
        }
        if (aInNfmpSap["rateType"] === "kbps") {
            if (!aInSapIntentModel["ingress"]["agg-rate"]) {
                aInSapIntentModel["ingress"]["agg-rate"] = {};
            }
            if (aInNfmpSap["ingressAggRateLimit"] != -1) {
                aInSapIntentModel["ingress"]["agg-rate"]["rate"] = aInNfmpSap["ingressAggRateLimit"];
            }
            if (aInNfmpSap["ingressAggCIR"] == -1) {
                aInSapIntentModel["ingress"]["agg-rate"]["cir"] = "max";
            } else {
                aInSapIntentModel["ingress"]["agg-rate"]["cir"] = aInNfmpSap["ingressAggCIR"];
            }
        } 
    }

    return aInSapIntentModel;
};

/*
   function: IntentQoSToNFMPMapperIng
    since: NSP 23.11
    short_description: NFMP managed SR - map intent model to device model - vpls/epipe ingress specific part
    input:
        aInSapAmi:
          type: Object
          description: Intent SAP object
          mandatory: True
        aInSapDevice:
          type: Object
          description: Existing NFMP object
          mandatory: True
        aInNeId:
          type: String
          description: device NE ID
          mandatory: True
      neSvcType:
        description: service type
        type: String
        mandatory: False
        since: 24.8
    examples:
      "IntentQoSToNFMPMapperIng": |
         this.IntentQoSToNFMPMapperIng(sapAmi["ingress"], aInSapDevice, deviceId);
 */
SrSvcFwk.prototype.IntentQoSToNFMPMapperIng = function (aInSapAmi, aInSapDevice, aInNeId, neSvcType) {
    if(neSvcType===undefined) { neSvcType = '' };
    if (this.sfUtils.isIxrR6OrENode(aInNeId)) {
        if (aInSapAmi["aggregate-policer"]) {
            if (aInSapAmi["aggregate-policer"]["rate"] === "max") {
                aInSapDevice["sapIngressAggregateMeterRate"] = -1;
            } else {
                aInSapDevice["sapIngressAggregateMeterRate"] = aInSapAmi["aggregate-policer"]["rate"];
            }
            if (aInSapAmi["aggregate-policer"]["burst"] === "default") {
                aInSapDevice["sapIngressAggregateMeterBurst"] = -1;
            } else {
                aInSapDevice["sapIngressAggregateMeterBurst"] = aInSapAmi["aggregate-policer"]["burst"];
            }
            if (aInSapAmi["aggregate-policer"]["cir"]) {
                if (aInSapAmi["aggregate-policer"]["cir"] === "max") {
                    aInSapDevice["sapIngressAggregateMeterCIR"] = -1;
                } else {
                    aInSapDevice["sapIngressAggregateMeterCIR"] = aInSapAmi["aggregate-policer"]["cir"];
                }
            } else {
                aInSapDevice["sapIngressAggregateMeterCIR"] = -2;
            }
            if (aInSapAmi["aggregate-policer"]["cbs"]) {
                if (aInSapAmi["aggregate-policer"]["cbs"] === "default") {
                    aInSapDevice["sapIngressAggregateMeterCBS"] = -1;
                } else {
                    aInSapDevice["sapIngressAggregateMeterCBS"] = aInSapAmi["aggregate-policer"]["cbs"];
                }
            } else {
                aInSapDevice["sapIngressAggregateMeterCBS"] = -2;
            }
        } else {
            aInSapDevice["sapIngressAggregateMeterRate"] = -1;
            aInSapDevice["sapIngressAggregateMeterBurst"] = -1;
            aInSapDevice["sapIngressAggregateMeterCIR"] = -2;
            aInSapDevice["sapIngressAggregateMeterCBS"] = -2;
        }

        let isQinQ = aInSapDevice["innerEncapValue"] && aInSapDevice["innerEncapValue"] !== "0";
        let vlanAction = isQinQ ? "popOuterAndInner" : "popOuter";
        let vlanOuterTag = "-1";
        let vlanInnerTag = "-1";
        if (aInSapAmi["vlan-manipulation"]) {
            if (aInSapAmi["vlan-manipulation"]["action"]) {
                if (aInSapAmi["vlan-manipulation"]["action"] === "preserve") {
                    vlanAction =  "preserve";
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "push") {
                    vlanAction =   isQinQ ? "pushOuterAndInner" : "pushOuter";
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "translate-1-to-1") {
                    if (aInSapAmi["vlan-manipulation"]["outer-tag"] && aInSapAmi["vlan-manipulation"]["outer-tag"] === "null") {
                        vlanAction =  "popOuter";
                    } else {
                        vlanAction =  "replaceOuter";
                    }
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "translate-2-to-2") {
                    if ((aInSapAmi["vlan-manipulation"]["outer-tag"] && aInSapAmi["vlan-manipulation"]["outer-tag"] === "null") &&
                        (aInSapAmi["vlan-manipulation"]["inner-tag"] && aInSapAmi["vlan-manipulation"]["inner-tag"] === "null")) {
                        vlanAction =  "popOuterAndInner";
                    } else {
                        vlanAction =  "replaceOuterAndInner";
                    }
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "translate-2-to-1") {
                    if ((aInSapAmi["vlan-manipulation"]["outer-tag"] && aInSapAmi["vlan-manipulation"]["outer-tag"] === "null")) {
                        vlanAction =  "popOuterAndInner";
                    } else {
                        vlanAction =  "popOuterAndReplaceInner";
                    }
                }
                if (typeof aInSapAmi["vlan-manipulation"]["inner-tag"] !== "undefined" && aInSapAmi["vlan-manipulation"]["inner-tag"] !== "null") {
                    vlanInnerTag = aInSapAmi["vlan-manipulation"]["inner-tag"];    
                }
                if (typeof aInSapAmi["vlan-manipulation"]["outer-tag"] !== "undefined" && aInSapAmi["vlan-manipulation"]["outer-tag"] !== "null") {
                    vlanOuterTag = aInSapAmi["vlan-manipulation"]["outer-tag"];
                } 
            }
        } 
        aInSapDevice["ingressQtagManipulateAction"] = vlanAction; 
        aInSapDevice["ingressInnerQtag"] = vlanInnerTag;  
        aInSapDevice["ingressOuterQtag"] = vlanOuterTag;
    }
    if (this.sfUtils.is7705Node(aInNeId)) {
        if (aInSapAmi["scheduler-mode"]) {
            aInSapDevice["ingressSchedulerMode"] =  aInSapAmi["scheduler-mode"];  
        }
        if (aInSapAmi["agg-rate"]) {
            aInSapDevice["rateType"] = "kbps";
    
            if (aInSapAmi["agg-rate"]["rate"] == null) {
                aInSapDevice["ingressAggRateLimit"] = -1;
            } else {
                aInSapDevice["ingressAggRateLimit"] = aInSapAmi["agg-rate"]["rate"];
            }
            if (neSvcType !== 'cpipe') {
                if (aInSapAmi["agg-rate"]["cir"] === "max") {
                    aInSapDevice["ingressAggCIR"] = -1;
                } else {
                    aInSapDevice["ingressAggCIR"] = aInSapAmi["agg-rate"]["cir"];
                }
            }
        } else {
            aInSapDevice["ingressAggRateLimit"] = -1;
            if (!neSvcType !== 'cpipe') {
                aInSapDevice["ingressAggCIR"] = 0;
            }
        }
    }  
};

/*
   function: NFMPToIntentQoSMapperEgr
    since: NSP 23.11
    short_description: NFMP managed SR - map device model to intent model - Brownfield - vpls/epipe egress specific part
    input:
        aInSapIntentModel:
          type: Object
          description: Intent model
          mandatory: True
        aInNfmpSap:
          type: Object
          description: NFMP device object
          mandatory: True
    examples:
      "NFMPToIntentQoSMapperEgr": |
             this.NFMPToIntentQoSMapperVplsEgr(aInSapIntentModel, aInNfmpSapModel);
 */
SrSvcFwk.prototype.NFMPToIntentQoSMapperEgr = function (aInSapIntentModel, aInNfmpSap, aInNeId) {
    if (!aInSapIntentModel["egress"]) aInSapIntentModel["egress"] = {};

    if (!aInSapIntentModel["egress"]["qos"]) {
        aInSapIntentModel["egress"]["qos"] = {};
    }

    aInSapIntentModel["egress"]["qos"]["vlan-qos-policy"] = {};
    if (aInNfmpSap["egressVlanQosPolicyObjectPointer"]) {
        let egrVQP = aInNfmpSap["egressVlanQosPolicyObjectPointer"].replace("VlanQosPolicy7250SROS:", "");
        if (egrVQP === "default") {
            egrVQP = "";
        }
        aInSapIntentModel["egress"]["qos"]["vlan-qos-policy"]["policy-name"] = egrVQP
    }
    if (aInNfmpSap["sapEgressVlanQosPlcyPortRedirect"] && aInNfmpSap["sapEgressVlanQosPlcyPortRedirect"] === "true") {
        aInSapIntentModel["egress"]["qos"]["vlan-qos-policy"]["port-redirect"] = true
    } else {
        aInSapIntentModel["egress"]["qos"]["vlan-qos-policy"]["port-redirect"] = false
    }

    if (aInNfmpSap["egressRemarkPolicyObjectPointer"]) {
        let egrRP = aInNfmpSap["egressRemarkPolicyObjectPointer"].replace("EgressRemarkPolicy7250SROS:", "");
        if (egrRP === "default") {
            egrRP = "";
        }
        aInSapIntentModel["egress"]["qos"]["egress-remark-policy"]= {
            "policy-name": egrRP
        }
    }

    if (aInNfmpSap["rateType"] === "kbps") {
        if (!aInSapIntentModel["egress"]["agg-rate"]) {
            aInSapIntentModel["egress"]["agg-rate"] = {};
        }
        if (aInNfmpSap["egressAggRateLimit"] != -1) {
            aInSapIntentModel["egress"]["agg-rate"]["rate"] = aInNfmpSap["egressAggRateLimit"];
        }
        if (aInNfmpSap["egressAggCIR"] == -1) {
            aInSapIntentModel["egress"]["agg-rate"]["cir"] = "max";
        } else {
            aInSapIntentModel["egress"]["agg-rate"]["cir"] = aInNfmpSap["egressAggCIR"];
        }
    } else if (aInNfmpSap["rateType"] === "percentRate") {
        if (!aInSapIntentModel["egress"]["percent-agg-rate"]) {
            aInSapIntentModel["egress"]["percent-agg-rate"] = {};
        }
        if (aInNfmpSap["egressPirPercent"]) {
            aInSapIntentModel["egress"]["percent-agg-rate"]["pir"] = aInNfmpSap["egressPirPercent"];
        }
        if (aInNfmpSap["egressCirPercent"]) {
            aInSapIntentModel["egress"]["percent-agg-rate"]["cir"] = aInNfmpSap["egressCirPercent"];
        }
    }
    if (aInNfmpSap["egressSchedulerMode"]) {
        aInSapIntentModel["egress"]["scheduler-mode"] =  aInNfmpSap["egressSchedulerMode"];  
    }
    if (this.sfUtils.isIxrR6OrENode(aInNeId)) {
        let isQinQ = aInNfmpSap["innerEncapValue"] && aInNfmpSap["innerEncapValue"] !== "0";
        let vlanAction = aInNfmpSap["egressQtagManipulateAction"];
        if ((vlanAction !== "none" && (!isQinQ || vlanAction !== "pushOuterAndInner") && vlanAction !== "pushOuter")) {
            //NON default VLAN is configured
            aInSapIntentModel["egress"]["vlan-manipulation"] = {};
            if (vlanAction === "pushOuterAndInner" || vlanAction === "pushOuter") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "push";     
            } else if (vlanAction === "preserve") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "preserve";    
            } else if (vlanAction === "popOuter") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "translate-1-to-1";
                aInSapIntentModel["egress"]["vlan-manipulation"]["tag"] = "null";
            } else if (vlanAction === "replaceOuter") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "translate-1-to-1";
                aInSapIntentModel["egress"]["vlan-manipulation"]["tag"] = "use-sap-vlan";
            } else if (vlanAction === "popOuterAndInner") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "translate-2-to-2";
                aInSapIntentModel["egress"]["vlan-manipulation"]["tag"] = "null";
            }  else if (vlanAction === "replaceOuterAndInner") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "translate-2-to-2";
                aInSapIntentModel["egress"]["vlan-manipulation"]["tag"] = "use-sap-vlan";
            }  else if (vlanAction === "replaceAndPushOuter") {
                aInSapIntentModel["egress"]["vlan-manipulation"]["action"] = "translate-1-to-2";
                aInSapIntentModel["egress"]["vlan-manipulation"]["tag"] = "null";
            } 
        }
    }

    return aInSapIntentModel;
};

/*
   function: IntentQoSToNFMPMapperEgr
    since: NSP 23.11
    short_description: NFMP managed SR - map intent model to device model - vpls/epipe egress specific part
    input:
        aInSapAmi:
          type: Object
          description: Intent SAP object
          mandatory: True
        aInSapDevice:
          type: Object
          description: Existing NFMP object
          mandatory: True
      neSvcType:
        description: service type
        type: String
        mandatory: False
        since: 24.8
    examples:
      "IntentQoSToNFMPMapperEgr": |
             this.IntentQoSToNFMPMapperEgr(sapAmi["egress"], aInSapDevice);
 */
SrSvcFwk.prototype.IntentQoSToNFMPMapperEgr = function (aInSapAmi, aInSapDevice, aInNeId, neSvcType) {
    if(neSvcType===undefined) { neSvcType = '' };
    if(aInSapAmi["qos"] && aInSapAmi["qos"]["vlan-qos-policy"]) {
        let vlanQosPolicyName = "default";
        if (aInSapAmi["qos"]["vlan-qos-policy"]["policy-name"]) {
            vlanQosPolicyName = aInSapAmi["qos"]["vlan-qos-policy"]["policy-name"];
        }
        aInSapDevice["egressVlanQosPolicyObjectPointer"] = "VlanQosPolicy7250SROS:" + vlanQosPolicyName;

        if (aInSapAmi["qos"]["vlan-qos-policy"]["port-redirect"]) {
            aInSapDevice["sapEgressVlanQosPlcyPortRedirect"] = true;
        } else {
            aInSapDevice["sapEgressVlanQosPlcyPortRedirect"] = false;
        }
    }

    let remarPolicyName = "default"
    if(aInSapAmi["qos"] && aInSapAmi["qos"]["egress-remark-policy"] && aInSapAmi["qos"]["egress-remark-policy"]["policy-name"]) {
        remarPolicyName = aInSapAmi["qos"]["egress-remark-policy"]["policy-name"];
    }
    aInSapDevice["egressRemarkPolicyObjectPointer"] = "EgressRemarkPolicy7250SROS:" + remarPolicyName;

    if (aInSapAmi["agg-rate"]) {
        aInSapDevice["rateType"] = "kbps";

        if (aInSapAmi["agg-rate"]["rate"] == null) {
            aInSapDevice["egressAggRateLimit"] = -1;
        } else {
            aInSapDevice["egressAggRateLimit"] = aInSapAmi["agg-rate"]["rate"];
        }
        if (!this.sfUtils.is7750Node(aInNeId) &&  neSvcType !== 'cpipe') {
            if (aInSapAmi["agg-rate"]["cir"] === "max") {
                aInSapDevice["egressAggCIR"] = -1;
            } else {
                aInSapDevice["egressAggCIR"] = aInSapAmi["agg-rate"]["cir"];
            }
        }
    } else {
        aInSapDevice["egressAggRateLimit"] = -1;
        if (!this.sfUtils.is7750Node(aInNeId)  &&  neSvcType !== 'cpipe') {
            aInSapDevice["egressAggCIR"] = 0;
        }
    }

    if (aInSapAmi["percent-agg-rate"]) {
        aInSapDevice["rateType"] = "percentRate";

        if (aInSapAmi["percent-agg-rate"]["pir"]) {
            if (aInSapAmi["percent-agg-rate"]["pir"].indexOf(".") !== -1)
                aInSapDevice["egressPirPercent"] = aInSapAmi["percent-agg-rate"]["pir"];
            else
                aInSapDevice["egressPirPercent"] =  parseFloat(aInSapAmi["percent-agg-rate"]["pir"]).toFixed(1);
        } else{
            aInSapDevice["egressPirPercent"] = 100;
        }

        if (!this.sfUtils.is7750Node(aInNeId)) {
            if (aInSapAmi["percent-agg-rate"]["cir"]) {
                if (aInSapAmi["percent-agg-rate"]["pir"].indexOf(".") !== -1)
                    aInSapDevice["egressCirPercent"] = aInSapAmi["percent-agg-rate"]["cir"];
                else
                    aInSapDevice["egressCirPercent"] =  parseFloat(aInSapAmi["percent-agg-rate"]["cir"]).toFixed(1);
            } else {
                aInSapDevice["egressCirPercent"] = 0;
            }
        }
    }

    if (aInSapAmi["scheduler-mode"]) {
        aInSapDevice["egressSchedulerMode"] =  aInSapAmi["scheduler-mode"];  
    }

    if (this.sfUtils.isIxrR6OrENode(aInNeId)) {
        let isQinQ = aInSapDevice["innerEncapValue"] && aInSapDevice["innerEncapValue"] !== "0";
        let vlanAction = isQinQ ? "pushOuterAndInner" : "pushOuter";
        if (aInSapAmi["vlan-manipulation"]) {
            if (aInSapAmi["vlan-manipulation"]["action"]) {
                if (aInSapAmi["vlan-manipulation"]["action"] === "preserve") {
                    vlanAction =  "preserve";
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "push") {
                    vlanAction =   isQinQ ? "pushOuterAndInner" : "pushOuter";
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "translate-1-to-1") {
                    if (aInSapAmi["vlan-manipulation"]["tag"] === "null") {
                        vlanAction =  "popOuter";    
                    } else {
                        vlanAction =  "replaceOuter";    
                    }
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "translate-2-to-2") {
                    if (aInSapAmi["vlan-manipulation"]["tag"] === "null") {
                        vlanAction =  "popOuterAndInner";
                    } else {
                        vlanAction =  "replaceOuterAndInner";    
                    }
                } else if (aInSapAmi["vlan-manipulation"]["action"] === "translate-1-to-2") {
                    vlanAction =  "replaceAndPushOuter";    
                }
            }
        }
        aInSapDevice["egressQtagManipulateAction"] = vlanAction;
    }
};

/*
   function: NFMPToIntentMapperBgpVsiPlcy
    since: NSP 23.11
    short_description: Reverse mapping - Map device model to intent model - BGP policy
    input:
        childClassVal:
          type: Object
          description: NFMP class attributes
        intentInterface:
          type: Object
          description: Current intent bgp policy object
          mandatory: True
    examples:
      "NFMPToIntentMapperBgpVsiPlcy": |
           this.srSvcUtils.NFMPToIntentMapperBgpVsiPlcy(intentModel["site"][lEvpnType]["bgp-instance"]["vsi-import"],
                                                 childClassVal["children-Set"]["vpls.BgpAdVsiImportPolicy"])
*/
SrSvcFwk.prototype.NFMPToIntentMapperBgpVsiPlcy = function (aInIntPolicyList, aInNfmpClassVal) {
    for (var  k = 1; k <= 5; k++) {
        if (aInNfmpClassVal["policy" + k] !== "")
            aInIntPolicyList.push(aInNfmpClassVal["policy" + k]);
    }
};

/*
   function: IntentToNFMPMapperBgpVsiPlcy
    since: NSP 23.11
    short_description: Reverse mapping - Map device model to intent model - policy mapping
    input:
        aInNfmpPolicyList:
          type: Object
          description: NFMP class attributes
          mandatory: True
        aInIntPolicyList:
          type: Object
          description: Intent policy object
          mandatory: True
    output:
      intentModel:
        type: Object
        description: intent model after translation
    examples:
      "IntentToNFMPMapperBgpVsiPlcy": |
            this.srSvcUtils.IntentToNFMPMapperBgpVsiPlcy(bgpCfgDevice["children-Set"]["vpls.BgpAdVsiImportPolicy"],
                                                         siteObjMap.vxlan["bgp-instance"]["vsi-import"])
*/
SrSvcFwk.prototype.IntentToNFMPMapperBgpVsiPlcy = function (aInNfmpPolicyList, aInIntPolicyList) {
    if (aInIntPolicyList) {
        for (var  k = 1; k <= 5; k++) {
            if (aInIntPolicyList && aInIntPolicyList[k - 1]){
                aInNfmpPolicyList["policy" + k] = aInIntPolicyList[k - 1];
            }
            else
                aInNfmpPolicyList["policy" + k] = "";
        }
    } else {
        for (var  k = 1; k <= 5; k++) {
            aInNfmpPolicyList["policy" + k] = "";
        }
    }

    return aInNfmpPolicyList;
};

SrSvcFwk.prototype.mdSRAdminStateDeploy = function(deviceModel)  {
    if (deviceModel && deviceModel["admin-state"] && deviceModel["admin-state"] === "locked") {
        deviceModel["admin-state"] = "disable"
    } else if (deviceModel && deviceModel["admin-state"] && deviceModel["admin-state"] === "unlocked")
        deviceModel["admin-state"] = "enable"
}

SrSvcFwk.prototype.mdSRAdminStateSync = function(intentModel)  {
    if (intentModel && intentModel["admin-state"] && intentModel["admin-state"] === "enable") {
        intentModel["admin-state"] = "unlocked"
    } else if (intentModel)
        intentModel["admin-state"] = "locked"
}

SrSvcFwk.prototype.findNFMPL2AccessInterfaceByServiceSite = function (serviceMgrId, siteId, portPointer, innerEncapValue, outerEncapValue) {
    let payload = {
        "fullClassName": "service.L2AccessInterface",
        "filter": {
            "and": {
                "equal": [
                    {"name": "svcComponentId", "value": serviceMgrId.replace("svc-mgr:service-","")},
                    {"name": "nodeId", "value": siteId},
                    {"name": "portPointer", "value": portPointer},
                    {"name": "outerEncapValue", "value": outerEncapValue},
                    {"name": "innerEncapValue", "value": innerEncapValue}
                ]
            }
        }
    };
    let results = this.nfmpFwk.post("/v3/search", payload);
    if (results.success && !(results.response === "{}" || results.response.indexOf("does not exist") !== -1)) {
        return JSON.parse(results["response"]);
    } else
        return null;
};
