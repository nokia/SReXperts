load({
    script: resourceProvider.getResource('sf-logger.js'),
    name: 'ServiceFulfillmentLogger'
});
load({
    script: resourceProvider.getResource('nsp-restconf-fwk.js'),
    name: 'nsp-restconf-fwk'
});
load({
    script: resourceProvider.getResource('sf-utils.js'),
    name: 'util-fwk'
});

function ServiceOperationModelFwk() {}

/*
   function: getName
    since: NSP 22.6
    short_description: Extract service name. If brown-field service, remove NSP appended objects.
    input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
 */
ServiceOperationModelFwk.prototype.getName = function(requestContext) {
    let lService = requestContext.get("target");
    if (requestContext.get("target").indexOf(":") !== -1) {
        let lServiceNameArr = requestContext.get("target").split(":");
        if (lServiceNameArr.length === 3 && lServiceNameArr[2].indexOf("sam") !== -1) {
            lService = lServiceNameArr[0];
        }
        if (lServiceNameArr.length === 3 && lServiceNameArr[2].indexOf("mdm") !== -1) {
            lService = lServiceNameArr[0];
        }
    }
    return lService;
};

/*
   function: populateServiceModel
    since: NSP 22.6
    short_description: Populate Service operational model.
    description:
        - populate service level operational model properties
    input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
    output:
      serviceModel:
        type: Object
        description: Service operational model payload.
 */
ServiceOperationModelFwk.prototype.populateServiceModel = function(requestContext) {
    requestContext.get("sfLogger").debug("[ServiceOperationModelFwk] intent model {}", JSON.stringify(requestContext.get("svcObjMap")));
    let servicePayload = {};

    if (!requestContext.get("svcObjMap"))
        throw new RuntimeException("Service level object is null");
    else if (!requestContext.get("svcType"))
        throw new RuntimeException("Cannot resolve svcType");
    else if (!requestContext.get("intentType"))
        throw new RuntimeException("Cannot resolve intent type");
    else if (!requestContext.get("intentTypeVersion"))
        throw new RuntimeException("Cannot resolve intent version");
    else if (!requestContext.get("target"))
        throw new RuntimeException("Cannot resolve target");

    servicePayload["origin"] = "ibsf";
    servicePayload["service-id"] = requestContext.get("target");
    servicePayload["name"] = this.getName(requestContext);

    if (requestContext.get("svcObjMap")["description"])
        servicePayload["description"] = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(requestContext.get("svcObjMap")["description"]);
    else
        servicePayload["description"] = "";

    if (requestContext.get("svcObjMap")["admin-state"])
        servicePayload["admin-state"] = requestContext.get("svcObjMap")["admin-state"];

    if (requestContext.get("svcObjMap")["ne-service-id"])
        servicePayload["ne-service-id"] = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(requestContext.get("svcObjMap")["ne-service-id"]);
    else if (requestContext.get("siteObjMap") && requestContext.get("siteObjMap")[Object.keys(requestContext.get("siteObjMap"))[0]] && requestContext.get("siteObjMap")[Object.keys(requestContext.get("siteObjMap"))[0]][0] &&
        requestContext.get("siteObjMap")[Object.keys(requestContext.get("siteObjMap"))[0]][0]["ne-service-id"])
        servicePayload["ne-service-id"] = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(requestContext.get("siteObjMap")[Object.keys(requestContext.get("siteObjMap"))[0]][0]["ne-service-id"]);

    if (requestContext.get("svcObjMap")["serviceMgrId"] && requestContext.get("svcObjMap")["serviceMgrId"] != "-1") {
        if (typeof requestContext.get("svcObjMap")["serviceMgrId"] === "object" && requestContext.get("svcObjMap")["serviceMgrId"]["NFMP"]){
            let lSvcMgrId = requestContext.get("svcObjMap")["serviceMgrId"]["NFMP"].split("-");
            servicePayload["id"] = lSvcMgrId[lSvcMgrId.length - 1];
        } else {
            let lSvcMgrId = requestContext.get("svcObjMap")["serviceMgrId"].split("-");
            servicePayload["id"] = lSvcMgrId[lSvcMgrId.length - 1];
        }
    } else {
        servicePayload["id"] = "0";
    }

    if (requestContext.get("svcObjMap")["@"]) servicePayload["@"] = JSON.parse(JSON.stringify(requestContext.get("svcObjMap")["@"]));

    if (servicePayload["@"] && servicePayload["@"]["nsp-model:sources"] && servicePayload["@"]["nsp-model:sources"].length !== 0){
        servicePayload["@"]["nsp-model:sources"] = servicePayload["@"]["nsp-model:sources"].reduce(function(a,b){
            if (a.indexOf(b) < 0 ) a.push(b);
            return a;
        },[]);
    }

    // MDM
    if (requestContext.get("svcObjMap")["customer-id"])
    {
        let lName = "N/A"
        if (servicePayload["@"] && servicePayload["@"]["customerInfo"] && servicePayload["@"]["customerInfo"]["name"]) {
            lName = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(servicePayload["@"]["customerInfo"]["name"]);
            servicePayload["tenant"] = [{
                "name": lName,
                "id": requestContext.get("svcObjMap")["customer-id"].toString()
            }];
        }
    }
    // NFMP
    if (requestContext.get("svcObjMap")["serviceMgrId"] && requestContext.get("svcObjMap")["serviceMgrId"] != "-1" && requestContext.get("rpcToState") === "deployed" && requestContext.get("svcObjMap")["@"]) {
        if (servicePayload["tenant"] && servicePayload["tenant"].length > 0 && requestContext.get("svcObjMap")["@"] &&  requestContext.get("svcObjMap")["@"]["nsp-model:sources"]) {
            servicePayload["tenant"][0]["@"] = {};
            servicePayload["tenant"][0]["@"]["nsp-model:sources"] = [];
            servicePayload["tenant"][0]["@"]["nsp-model:sources"].push(requestContext.get("svcObjMap")["@"]["nsp-model:sources"][0] + "@customerDetails")
        }
    }
    servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"] = {};
    servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["intent-type"] = requestContext.get("intentType");
    servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["intent-type-version"] = requestContext.get("intentTypeVersion");
    servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["intent-instance-identifier"] = requestContext.get("target");
    if (!requestContext.get("rpcToState"))
        servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["slc-state"] = "saved";
    else
        servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["slc-state"] = requestContext.get("rpcToState");
    if (requestContext.get("rpcTemplateName"))
        servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["template-name"] = requestContext.get("rpcTemplateName");
    if (requestContext.get("svcObjMap")["vc-type"])
        servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["vc-type"] = requestContext.get("svcObjMap")["vc-type"];
    if (requestContext.get("svcObjMap")["ring-element-instance-id"])
        servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["ring-element-instance-id"] = requestContext.get("svcObjMap")["ring-element-instance-id"];
    if (requestContext.get("svcObjMap")["job-id"])
        servicePayload["service-extension:" + requestContext.get("svcType") + "-svc"]["job-id"] = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(requestContext.get("svcObjMap")["job-id"]);

    return servicePayload;
};

/*
   function: create
    since: NSP 22.6
    short_description: Perform POST to create operational model entry
    description:
        - Perform Post to create Operational model entry
        - Create only if no entry found
    input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
 */
ServiceOperationModelFwk.prototype.create = function(requestContext) {
    let lFetchSvc = new NspRestconfFwk(requestContext.get("sfLogger")).getServiceRootElements(requestContext.get("svcType"), requestContext.get("target"));
    if (!lFetchSvc) {
        let servicePayload = this.populateServiceModel(requestContext);
        //Add service sources
        if (servicePayload["@"]) {
            servicePayload["@"]["nsp-model:sources"].push("fdn:yang:nsp-service-intent:/nsp-service-intent:intent-base/intent[service-name='" + requestContext.get("target") + "'][intent-type='" + requestContext.get("intentType") + "']");
        } else {
            servicePayload["@"] = {
                "nsp-model:sources": ["fdn:yang:nsp-service-intent:/nsp-service-intent:intent-base/intent[service-name='"
                + requestContext.get("target") + "'][intent-type='" + requestContext.get("intentType") + "']"]
            }
        }

        //Add customer info, if customer-id in payload.
        if (requestContext.get("svcObjMap")["customer-id"])
        {
            let lName = "N/A"
            if (servicePayload["@"] && servicePayload["@"]["customerInfo"] && servicePayload["@"]["customerInfo"]["name"]) {
                lName = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(servicePayload["@"]["customerInfo"]["name"]);
            } else {
                let lCustomerNspObj = new NspRestconfFwk(requestContext.get("sfLogger")).findByXpath("/nsp-customer:customers/customer[id='"+requestContext.get("svcObjMap")["customer-id"]+"']",2);
                if (lCustomerNspObj && lCustomerNspObj[0] && lCustomerNspObj[0]["name"]) {
                    lName = new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(lCustomerNspObj[0]["name"]);
                }
            }
            servicePayload["tenant"] = [{
                "name": lName,
                "id": new ServiceFulfillmentIntentUtils(requestContext.get("sfLogger")).convertToString(requestContext.get("svcObjMap")["customer-id"])
            }];
        }

        let response = new NspRestconfFwk(requestContext.get("sfLogger")).createService(servicePayload, requestContext.get("svcType"));
        if (response.httpStatus !== 201 && response.httpStatus !== 204 && response.httpStatus !== 200) {
            throw new RuntimeException("Service operational model create failed - " + response["response"]);
        }
    } else
        throw new RuntimeException("Service operational model create failed - OperModel entry already found - " + requestContext.get("target"));
};

/*
   function: deleteSvc
    since: NSP 22.6
    short_description: Perform DELETE action on operational model entry
    input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
 */
ServiceOperationModelFwk.prototype.deleteSvc = function(requestContext) {
    let response = new NspRestconfFwk(requestContext.get("sfLogger")).deleteService(requestContext.get("svcType"), requestContext.get("target"));
    if (response.httpStatus !== 201 && response.httpStatus !== 204 && response.httpStatus !== 200) {
        throw new RuntimeException("Service operational model delete failed - " + response["response"]);
    }
};

/*
   function: deployed
    since: NSP 22.6
    short_description: Perform PATCH action to operational model entry with OLC state deployed
    description:
        - PATCH operational service model (prior deployment) with OLC state deployed
        - Site list is populated with nsp-model:sources  - to support resync after deployment
    input:
        requestContext:
          type: HashMap
          description: Thread local attribute map for each intent instance.
          mandatory: True
        ignorePost:
          type: boolean
          description: if false or undefined, operational model patch will not be made
          mandatory: False
 */
ServiceOperationModelFwk.prototype.deployed = function(requestContext, ignorePost) {
    requestContext.get("sfLogger").debug("[ServiceOperationModelFwk] deployed  intentSiteModel {}", JSON.stringify(requestContext.get("siteObjMap")));
    requestContext.put("rpcToState", "deployed");
    let servicePayload = this.populateServiceModel(requestContext);
    let alienServicePayload = {};

    servicePayload["site"] = [];
    servicePayload["endpoint"] = [];
    for (var  device in requestContext.get("siteObjMap")) {
        for (var  siteArrObj in requestContext.get("siteObjMap")[device]) {
            let siteAmi = requestContext.get("siteObjMap")[device][siteArrObj];
            let sitePayload = {};
            let alienSitePayload = {};

            sitePayload["service-name"] = servicePayload["name"];
            sitePayload["site-id"] = device;

            if (siteAmi["site-name"]) {
                sitePayload["name"] = siteAmi["site-name"] + "";
            } else {
                sitePayload["name"] = servicePayload["name"] + "";
            }

            if (!(siteAmi["@"] && siteAmi["@"]["svcSource"]) && !ignorePost) {
                throw new RuntimeException("Didnt find site FDN for device - " + device);
            }
            sitePayload["@"] = {};
            sitePayload["@"]["nsp-model:sources"] = [];
            if (siteAmi["@"] && siteAmi["@"]["typeAndVersionMap"] && siteAmi["@"]["typeAndVersionMap"]["alienMediatorName"]){
                let alienNspMediatorName = siteAmi["@"]["typeAndVersionMap"]["alienMediatorName"].replace("NFM-P", "NSP").replace("MDC", "NSP");
                if (!alienServicePayload[alienNspMediatorName]) {
                    alienServicePayload[alienNspMediatorName] = JSON.parse(JSON.stringify(servicePayload));
                    delete alienServicePayload[alienNspMediatorName]["service-extension:" + requestContext.get("svcType") + "-svc"];
                    delete alienServicePayload[alienNspMediatorName]["origin"];
                    alienServicePayload[alienNspMediatorName]["site"] = [];
                }

                alienSitePayload = JSON.parse(JSON.stringify(sitePayload))

                let lFetchSvc = new NspRestconfFwk(requestContext.get("sfLogger")).getServiceSite(requestContext.get("svcType"), requestContext.get("target"), "[site-id='"+device+"'][name='"+sitePayload["name"]+"']");
                if (lFetchSvc && lFetchSvc.length === 1 && lFetchSvc[0]["@"] && lFetchSvc[0]["@"]["nsp-model:sources"]){
                    let serviceId = null;
                    lFetchSvc[0]["@"]["nsp-model:sources"].forEach(function (lSource) {
                        if (lSource.indexOf("fdn:model:mdm:"+device) !== -1) {
                            serviceId = lSource.split("'")[1]
                        }
                    })
                    if (!serviceId)
                        throw new RuntimeException("Failed to resolve remote service-id for device - " + device);
                    alienServicePayload[alienNspMediatorName]["service-id"] = serviceId;
                    let lFetchRemoteSvc = new NspRestconfFwk(requestContext.get("sfLogger")).getServiceRootElements(requestContext.get("svcType"), serviceId, null, null, alienNspMediatorName);
                    if (lFetchRemoteSvc && lFetchRemoteSvc["id"] && lFetchRemoteSvc["id"] !== "0") {
                        alienServicePayload[alienNspMediatorName]["@"]["nsp-model:sources"] = ["fdn:realm:sam:svc-mgr:service-" + lFetchRemoteSvc["id"]]
                        siteAmi["@"]["svcSource"] = "fdn:realm:sam:svc-mgr:service-" + lFetchRemoteSvc["id"] + ":" + device;
                    }
                }

                sitePayload["@"]["nsp-model:sources"] = ["fdn:model:mdm:"+device+":/nsp-service:services/service-layer/" +
                    requestContext.get("svcType")+"[service-id='" + alienServicePayload[alienNspMediatorName]["service-id"] + "']/site[site-id='"+device+"'][name='"+sitePayload["name"]+"']"];


                alienSitePayload["@"]["nsp-model:sources"] = alienSitePayload["@"]["nsp-model:sources"].concat(siteAmi["@"]["svcSource"]);
                if (siteAmi["@"]["typeAndVersionMap"]["mediation"] === "nfmp") sitePayload["@"]["nsp-model:sources"] = sitePayload["@"]["nsp-model:sources"].concat(siteAmi["@"]["svcSource"]);
                alienServicePayload[alienNspMediatorName]["site"].push(alienSitePayload);
            } else
                sitePayload["@"]["nsp-model:sources"] = sitePayload["@"]["nsp-model:sources"].concat(siteAmi["@"]["svcSource"]);

            servicePayload["site"].push(sitePayload);
            if (siteAmi["@"]["overrideEp"])
            {
                for (var  endpoint in siteAmi["@"]["overrideEp"])
                {
                    servicePayload["endpoint"].push(siteAmi["@"]["overrideEp"][endpoint]);
                }
            }
        }
    }

    if (!ignorePost){
        let response = new NspRestconfFwk(requestContext.get("sfLogger")).patchService(servicePayload, requestContext.get("svcType"));
        if (response.httpStatus !== 201 && response.httpStatus !== 204 && response.httpStatus !== 200) {
            throw new RuntimeException("Failed to update service [" + requestContext.get("target") + "] in NSP store. Response = " + JSON.parse(response["response"]));
        }

        if(Object.keys(alienServicePayload).length > 0){
            Object.keys(alienServicePayload).forEach(function (lMediator) {
                let lFetchSvc = new NspRestconfFwk(requestContext.get("sfLogger")).getServiceRootElements(requestContext.get("svcType"), alienServicePayload[lMediator]["service-id"], null, null, lMediator);
                let alienRes = null;
                if (lFetchSvc) {
                    alienRes = new NspRestconfFwk(requestContext.get("sfLogger")).patchService(alienServicePayload[lMediator], requestContext.get("svcType"), lMediator);
                } else
                    alienRes = new NspRestconfFwk(requestContext.get("sfLogger")).updateService(alienServicePayload[lMediator], requestContext.get("svcType"), lMediator);

                if (alienRes.httpStatus !== 201 && alienRes.httpStatus !== 204 && alienRes.httpStatus !== 200) {
                    throw new RuntimeException("Failed to update service [" + requestContext.get("target") + "] in Remote NSP store. Response = " + JSON.parse(alienRes["response"]));
                }
            })
        }
    }

    //Auto Audit
    let autoAuditEnabled = false;
    let lables=ibnService.findIntentTypeByName(requestContext.get("intentType"),requestContext.get("intentTypeVersion")).getIntentTypeLabelValues().toString();
    if (lables!==null && lables.indexOf("autoAudit") !== -1){
        try {
            if (resourceProvider.getResource('auto-audit.json')){
                autoAuditEnabled = true;
            }
        } catch (e) {
            logger.error("autoAudit file not found - " + e)
        }
    }

    if (autoAuditEnabled) {
        let requestBody = {
            "input": {
                "intent-type": requestContext.get("intentType"),
                "intent-instance": requestContext.get("target"),
                "fdns":[]
            }
        };

        //NFMP
        if (servicePayload["@"] && servicePayload["@"]["nsp-model:sources"]){
            servicePayload["@"]["nsp-model:sources"].forEach(function (lSvcSource) {
                if (lSvcSource.indexOf("svc-mgr") !== -1)
                    requestBody["input"]["fdns"].push(lSvcSource)
            })
        }

        //MDM
        if (servicePayload["site"]){
            servicePayload["site"].forEach(function (lSite) {
                if (lSite["@"] && lSite["@"]["nsp-model:sources"]){
                    lSite["@"]["nsp-model:sources"].forEach(function (lSiteSource) {
                        if (lSiteSource && lSiteSource.indexOf("fdn:model:mdm:") !== -1 && lSiteSource.indexOf("state") === -1)
                            requestBody["input"]["fdns"].push(lSiteSource)
                    })
                }
            })
        }

        let url = new NspRestconfFwk(requestContext.get("sfLogger")).constructURL("/restconf/operations/nsp-intent-audit:updateAll", "POST");
        let response = new NspRestconfFwk(requestContext.get("sfLogger")).mediatorFwk.post(url, requestBody);
        if (response.httpStatus !== 201 && response.httpStatus !== 204 && response.httpStatus !== 200) {
            requestContext.get("sfLogger").error("Failed to update autoAudit keys for [" + requestContext.get("target") + "]. Response = " + JSON.parse(response["response"]));
        }
    }
};
