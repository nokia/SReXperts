var intentTypeName = "evpn-epipe";
var svcType = "eline";
var serviceNS = "http://www.nokia.com/management-solutions/" + intentTypeName;
RuntimeException = Java.type('java.lang.RuntimeException');



load({script: resourceProvider.getResource('sf-logger.js'), name: 'ServiceFulfillmentLogger'});
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk'});
load({script: resourceProvider.getResource('sf-intent-fwk.js'), name: 'sf-intent-fwk'});
load({script: resourceProvider.getResource('sr-device-mapper.js'), name: 'sr-device-mapper'});
load({script: resourceProvider.getResource('sf-utils.js'), name: 'util-fwk'});
var sfUtils = new ServiceFulfillmentIntentUtils();
load({script: resourceProvider.getResource('job-manager-fwk.js'), name: 'nsp-job-manager-fwk'});
load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();
load({script: resourceProvider.getResource('svc-oper-model-fwk.js'), name: 'oper-model-fwk'});
load({script: resourceProvider.getResource('resource-reservation-fwk.js'), name: 'resource-reservation-fwk'});
load({script: resourceProvider.getResource('sr-device-mapper-21-2.js'), name: 'sr-device-mapper-21-2'});
load({script: resourceProvider.getResource('ixr-device-mapper.js'), name: 'ixr-device-mapper'});
load({script: resourceProvider.getResource('ixr-device-mapper-21-2.js'), name: 'ixr-device-mapper-21-2'});
load({script: resourceProvider.getResource('approved-misalignment.js'), name: 'ApprovedMisAlignmentFWK'});
load({script: resourceProvider.getResource('oam-fwk.js'), name: 'oam-fwk'});

var svcIntentHelperFwk = new IBSFIntentHelper();
var approvedMisAlignmentFWK = new ApprovedMisAlignmentFWK();

var oamFWK = new oamFWK();
var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn"
};

var nsToModule = {
    serviceNS: intentTypeName
};

var extensionConfigObject = {
    setIntentTypeVariable: function(requestContext) {
        requestContext.put("intentType", intentTypeName);
        requestContext.put("intentTypeVersion", sfUtils.getIntentTypeVersion(intentTypeName,requestContext.get("target")));
        requestContext.put("svcType", svcType);
        requestContext.put("mdcMapper",  {
            "srDeviceMapper": new SrDeviceMapper(svcIntentHelperFwk.sfLogger),
            "srDeviceMapper212": new SrDeviceMapper212(svcIntentHelperFwk.sfLogger),
            "ixrDeviceMapper": new IxrDeviceMapper(svcIntentHelperFwk.sfLogger),
            "ixrDeviceMapper212": new IxrDeviceMapper212(svcIntentHelperFwk.sfLogger)
        });
        requestScope.set(requestContext);
    },

    setSiteAndServiceObj: function(requestContext) {
        svcIntentHelperFwk.transformSvcObj({"site-a": "", "site-b": ""}, requestContext);
        svcIntentHelperFwk.transformSiteObj("site-a", requestContext);
        mergeBySite("site-b", requestContext);
        buildMultiHomingSites(requestContext);
    }
};

svcIntentHelperFwk.setExtensionConfig(extensionConfigObject);

function synchronize(input) {
    return svcIntentHelperFwk.synchronize(input);
}

function audit(input) {
    //return svcIntentHelperFwk.audit(input);
    return approvedMisAlignmentFWK.resolveAudit(svcIntentHelperFwk.audit(input));
}

function executeStateAction(input) {
    return svcIntentHelperFwk.rpcAction(input);
}


function executeOAMAction(input) {
    



    
    
    let serviceName = input.getTarget();
    logger.debug("target Return {}",  serviceName);

    let lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
    logger.debug("buildReconcileSites Return {}", JSON.stringify(lConfig, null ,2));

    let transformedData = oamFWK.extractSiteDetails(lConfig,serviceName)
    logger.debug("transformed_data Return {}", JSON.stringify(transformedData, null ,2)); 
    let results = oamFWK.createTest(transformedData)
    logger.debug("transformed_data Return {}", JSON.stringify(results, null ,2)); 

    // please create the test here and print it in the logs and format the output data in xml and return to display in RPC call


    
    return "";
}


function reconcile(input) {
    var ReconcileOutput = Java.type('com.nokia.fnms.controller.ibn.intenttype.spi.ReconcileOutput');
    var requestContext = svcIntentHelperFwk.reconcile(input);
    var intentModel = buildReconcileSites(requestContext.get("intentModel"), input);
    var lreturn = '<configuration xmlns="http://www.nokia.com/management-solutions/ibn"><evpn-epipe xmlns="http://www.nokia.com/management-solutions/evpn-epipe">' +
        sfUtils.OBJtoXML(intentModel) + "</evpn-epipe></configuration>";
    return new ReconcileOutput(lreturn, null, "false", false, false, requestContext.get("currentTopology"));
}

function buildReconcileSites (intentModel, input){
    var lConfig;
    var lCurrentConfig;
    if (input.getJsonIntentConfiguration()) {
        lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        lCurrentConfig = lConfig[Object.keys(lConfig)[0]];
    }
    var ret = JSON.parse(JSON.stringify(intentModel));
    ret["site-a"] = {};
    ret["site-b"] = {};

    if (lCurrentConfig && lCurrentConfig["site-a"] && lCurrentConfig["site-a"]["device-id"]){
        ret["site-a"]["multi-homing-site-details"] = {};
        ret["site-a"]["device-id"] = lCurrentConfig["site-a"]["device-id"];
        if (lCurrentConfig["site-a"]["multi-homing-site-details"] && lCurrentConfig["site-a"]["multi-homing-site-details"]["device-id"]){
            ret["site-a"]["multi-homing-site-details"] = {"device-id" : lCurrentConfig["site-a"]["multi-homing-site-details"]["device-id"]}
        }
    }
    if (lCurrentConfig && lCurrentConfig["site-b"] && lCurrentConfig["site-b"]["device-id"] && intentModel["site-details"]
        && intentModel["site-details"]["site"] && intentModel["site-details"]["site"].length>1){
        ret["site-b"]["multi-homing-site-details"] = {};
        ret["site-b"]["device-id"] = lCurrentConfig["site-b"]["device-id"];
        if (lCurrentConfig["site-b"]["multi-homing-site-details"] && lCurrentConfig["site-b"]["multi-homing-site-details"]["device-id"]){
            ret["site-b"]["multi-homing-site-details"] = {"device-id" : lCurrentConfig["site-b"]["multi-homing-site-details"]["device-id"]}
        }
    }

    if (intentModel["site-details"] && intentModel["site-details"]["site"] && intentModel["site-details"]["site"].length>0){
        var HashMap = Java.type('java.util.HashMap');
        var remoteLocalTag = new HashMap();
        intentModel["site-details"]["site"].forEach(function (lSite) {
            var lLocalAc = null;
            var lRemoteAc = null;

            logger.info("buildReconcileSites current ret payload {}", JSON.stringify(ret));

            if (ret["site-a"]["device-id"] && lSite["device-id"] === ret["site-a"]["device-id"]){
                ret["site-a"] = sfUtils.objectAssign(lSite, ret["site-a"]);
            } else if (ret["site-b"]["device-id"] && lSite["device-id"] === ret["site-b"]["device-id"]){
                ret["site-b"] = sfUtils.objectAssign(lSite, ret["site-b"]);
            } else if (ret["site-a"]["multi-homing-site-details"] && ret["site-a"]["multi-homing-site-details"]["device-id"] && lSite["device-id"] === ret["site-a"]["multi-homing-site-details"]["device-id"]){
                ret["site-a"]["multi-homing-site-details"] = sfUtils.objectAssign(buildReconcileMHPayload(lSite), ret["site-a"]["multi-homing-site-details"]);
            } else if (ret["site-b"]["multi-homing-site-details"] && ret["site-b"]["multi-homing-site-details"]["device-id"] && lSite["device-id"] === ret["site-b"]["multi-homing-site-details"]["device-id"]) {
                ret["site-b"]["multi-homing-site-details"] = sfUtils.objectAssign(buildReconcileMHPayload(lSite), ret["site-b"]["multi-homing-site-details"]);
            } else if (!ret["site-a"]["device-id"]) {
                ret["site-a"] = sfUtils.objectAssign(lSite, ret["site-a"]);
            } else {
                var lAcItr = remoteLocalTag.keySet().iterator();
                var found = false;
                while (lAcItr.hasNext()) {
                    var itrIndex = lAcItr.next();
                    var otherAcTag = remoteLocalTag.get(itrIndex);
                    if (lSite["local-ac"] && lSite["remote-ac"] && lSite["local-ac"]["eth-tag"]  && lSite["remote-ac"]["eth-tag"]
                        && lSite["local-ac"]["eth-tag"] === otherAcTag["local"] && lSite["remote-ac"]["eth-tag"] === otherAcTag["remote"]){
                        if (ret["site-a"]["device-id"] && itrIndex === ret["site-a"]["device-id"]){
                            ret["site-a"]["multi-homing-site-details"] = sfUtils.objectAssign(buildReconcileMHPayload(lSite), ret["site-a"]["multi-homing-site-details"]);
                            found = true;
                        } else if (ret["site-b"]["device-id"] && itrIndex === ret["site-b"]["device-id"]){
                            ret["site-b"]["multi-homing-site-details"] = sfUtils.objectAssign(buildReconcileMHPayload(lSite), ret["site-b"]["multi-homing-site-details"]);
                            found = true;
                        } else
                            throw new RuntimeException ("Found MultiHoming site but failed to identify parent site");
                    }
                }
                if (!ret["site-b"]["device-id"] && found === false) {
                    ret["site-b"] = sfUtils.objectAssign(lSite, ret["site-b"]);
                } else if (found){
                    //do nothing
                } else {
                    throw new RuntimeException ("Failed to map site object");
                }
            }

            if (lSite["local-ac"] && lSite["local-ac"]["eth-tag"] && lSite["remote-ac"] && lSite["remote-ac"]["eth-tag"]){
                lLocalAc = lSite["local-ac"]["eth-tag"];
                lRemoteAc = lSite["remote-ac"]["eth-tag"];
            }
            remoteLocalTag.put(lSite["device-id"], {"local":lLocalAc, "remote":lRemoteAc});
        })
    }
    delete ret["site-details"];
    if (!ret["site-b"] || Object.keys(ret["site-b"]).length === 0) delete ret["site-b"];
    logger.info("buildReconcileSites Return {}", JSON.stringify(ret, null ,2));
    return ret;
}

function buildReconcileMHPayload (sitePayload){
    var ret = {"device-id" : sitePayload["device-id"]};
    if (sitePayload["sap-details"] && sitePayload["sap-details"]["sap"] && sitePayload["sap-details"]["sap"][0]){
        ret["port-id"] = sitePayload["sap-details"]["sap"][0]["port-id"];
        ret["inner-vlan-tag"] = sitePayload["sap-details"]["sap"][0]["inner-vlan-tag"];
        ret["outer-vlan-tag"] = sitePayload["sap-details"]["sap"][0]["outer-vlan-tag"];
        ret["admin-state"] = sitePayload["sap-details"]["sap"][0]["admin-state"];
        ret["description"] = sitePayload["sap-details"]["sap"][0]["description"];
    }
    if (sitePayload["mpls"] && sitePayload["mpls"]["bgp-instance"] && sitePayload["mpls"]["bgp-instance"]["route-distinguisher"])
        ret["route-distinguisher"] = sitePayload["mpls"]["bgp-instance"]["route-distinguisher"];
    if (sitePayload["vxlan"] && sitePayload["vxlan"]["bgp-instance"] && sitePayload["vxlan"]["bgp-instance"]["route-distinguisher"])
        ret["route-distinguisher"] = sitePayload["vxlan"]["bgp-instance"]["route-distinguisher"];
    return ret;
}

function buildMultiHomingSites(requestContext) {
    if (!requestContext) requestContext = requestScope.get();
    var siteObjMap = requestContext.get("siteObjMap");
    for (let  site in siteObjMap) {
        var lSiteObj = siteObjMap[site][0];
        if (lSiteObj["multi-homing-site-details"] && lSiteObj["multi-homing-site-details"]["device-id"]) {
            var multiHomingSite = JSON.parse(JSON.stringify(lSiteObj["multi-homing-site-details"]));
            delete lSiteObj["multi-homing-site-details"];
            logger.info("Found MultiHomingSites " + JSON.stringify(multiHomingSite));
            if (!siteObjMap[multiHomingSite["device-id"]])
                siteObjMap[multiHomingSite["device-id"]] = {};
            siteObjMap[multiHomingSite["device-id"]] = JSON.parse(JSON.stringify(siteObjMap[site]));
            siteObjMap[multiHomingSite["device-id"]][0]["device-id"] = multiHomingSite["device-id"];
            if (siteObjMap[multiHomingSite["device-id"]][0]["sap-details"] && siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"] && siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"][0]) {
                siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"][0]["port-id"] = multiHomingSite["port-id"];
                siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"][0]["inner-vlan-tag"] = multiHomingSite["inner-vlan-tag"];
                siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"][0]["outer-vlan-tag"] = multiHomingSite["outer-vlan-tag"];
                siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"][0]["admin-state"] = multiHomingSite["admin-state"];
                siteObjMap[multiHomingSite["device-id"]][0]["sap-details"]["sap"][0]["description"] = multiHomingSite["description"];
            }
            if (siteObjMap[multiHomingSite["device-id"]][0]["mpls"] && siteObjMap[multiHomingSite["device-id"]][0]["mpls"]["bgp-instance"] && siteObjMap[multiHomingSite["device-id"]][0]["mpls"]["bgp-instance"] ["route-distinguisher"]) {
                siteObjMap[multiHomingSite["device-id"]][0]["mpls"]["bgp-instance"] ["route-distinguisher"] = multiHomingSite["route-distinguisher"];
            }
            if (siteObjMap[multiHomingSite["device-id"]][0]["vxlan"] && siteObjMap[multiHomingSite["device-id"]][0]["vxlan"]["bgp-instance"] && siteObjMap[multiHomingSite["device-id"]][0]["vxlan"]["bgp-instance"] ["route-distinguisher"]) {
                siteObjMap[multiHomingSite["device-id"]][0]["vxlan"]["bgp-instance"] ["route-distinguisher"] = multiHomingSite["route-distinguisher"];
            }

        }
    }

    logger.info("buildMultiHomingSites siteObjMap = " + JSON.stringify(siteObjMap));
    requestContext.put("siteObjMap", siteObjMap);
}

function mergeBySite(objKey, requestContext) {
    if (!requestContext)
        requestContext = requestScope.get();
    var retSiteObj = requestContext.get("siteObjMap");
    svcIntentHelperFwk.transformSiteObj(objKey);
    var obj = requestContext.get("siteObjMap");
    for (let  prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            if (!retSiteObj[prop]) {
                retSiteObj[prop] = {};
            }
            retSiteObj[prop] = obj[prop];
        }
    }
    requestContext.put("siteObjMap", retSiteObj);
}

function getUacValidationObjects(input) {
    let intInstName = input.getTarget();
    logger.info(intentTypeName + " " + intInstName + ": Calling getUacValidationObjects, processing uac validation.");
    function getNeList(intInfo, returnNeSet, currIntConf) {
        // intInfo:
        //    {
        //         "ne-service-id": 1000,
        //             "customer-id": 17,
        //             "admin-state": "unlocked",
        //             "site-a": {
        //             "device-id": "1.1.1.1"
        //         },
        //         "site-b": {
        //             "device-id": "2.2.2.2"
        //         }
        //     }
        let lNeIds;
        let neSet = new Set();
        if (intInfo) {
            if (intInfo["site-a"]){
                if (intInfo["site-a"]["device-id"]) {
                    neSet.add(intInfo["site-a"]["device-id"]);
                } else if (currIntConf && currIntConf["site-a"] && currIntConf["site-a"]["device-id"]) {
                    neSet.add(currIntConf["site-a"]["device-id"]);
                }
            }
            if (intInfo["site-b"]) {
                if (intInfo["site-b"]["device-id"]) {
                    neSet.add(intInfo["site-b"]["device-id"]);
                } else if (currIntConf && currIntConf["site-b"] && currIntConf["site-b"]["device-id"]) {
                    neSet.add(currIntConf["site-b"]["device-id"]);
                }
            }

            // For the service scale validation, no sdp analyze, sdp cannot be deployed to NE without site configured
            // for the sdp source-device-id.

            if (returnNeSet) {
                return neSet;
            }

            if (neSet.size > 0) {
                lNeIds = "";
                neSet.forEach(function (aInNeId) {
                    lNeIds =
                        lNeIds + "<ne-id xmlns=\"http://www.nokia.com/management-solutions/" + "uac-validation-intent" + "\">"
                        + aInNeId + "</ne-id>"
                });
            }
        }

        return lNeIds;
    }

    function getNeListWithUrl(actName, actUrl, intConf, xml2JsonFn) {

        let lCurrentIntConf = xml2JsonFn(input.getIntentConfiguration())['configuration'][intentTypeName];
        // lCurrentIntConf:
        // {
        //     "site-a": {
        //     "site-name": "jun-epipe-810",
        //         "device-id": "15.15.15.15"
        //      },
        //     "xmlns": "urn:nokia:nsp:model:nsp-service-intent:services:epipe",
        //     "customer-id": 1,
        //     "site-b": "",
        //     "admin-state": "unlocked",
        //     "ne-service-id": 810,
        //     "sdp-details": ""
        // }

        let lNeIds;
        let lSiteName;
        let lNeSet = new Set();

        if (actUrl) {
            let plSvcLevelConfig;
            let pldNeSet;
            if (actName === "patch") {
                // service level potential change properties. Design intent: any of these properties exists in the payload,
                // return all the NEs in the current intent config.
                let svcLevelProps = ["mtu", "evpn-type", "description", "admin-state"];
                if (intConf) {
                    let payloadIntKey;
                    let payloadKeys = Object.keys(intConf);
                    for (let i = 0; i < payloadKeys.length; i++) {
                        if (payloadKeys[i] === "intent" || payloadKeys[i].lastIndexOf(":intent") > -1) {
                            payloadIntKey = payloadKeys[i];
                            break;
                        }
                    }

                    if (actUrl.endsWith("intent-specific-data/evpn-epipe:evpn-epipe")) {
                        plSvcLevelConfig = intConf;
                    } else {
                        if (intConf && intConf[payloadIntKey] && intConf[payloadIntKey][0] && intConf[payloadIntKey][0]["intent-specific-data"] && intConf[payloadIntKey][0]["intent-specific-data"]["evpn-epipe:evpn-epipe"]) {
                            plSvcLevelConfig = intConf[payloadIntKey][0]["intent-specific-data"]["evpn-epipe:evpn-epipe"];
                        }
                    }

                    if (plSvcLevelConfig) {
                        let svcLevalPatch = false;
                        for (let propI = 0;  propI < svcLevelProps.length; propI++) {
                            let prop = svcLevelProps[propI];
                            if (plSvcLevelConfig.hasOwnProperty(prop)) {
                                svcLevalPatch = true;
                            }
                            if (svcLevalPatch) {
                                break;
                            }
                        }
                        if (svcLevalPatch) {
                            logger.debug(intentTypeName + " " + intInstName + ": Calling getUacValidationObjects, processing getNeList on current intent config for uac validation.");
                            lNeSet = getNeList(lCurrentIntConf, true);
                        }
                    }
                }
            }

            let intSpecIndex = actUrl.lastIndexOf("intent-specific-data/evpn-epipe:evpn-epipe");
            if (intSpecIndex > -1) {
                // site-a/b
                let siteStartIndex = actUrl.lastIndexOf("site-a");
                if (siteStartIndex === -1) {
                    siteStartIndex = actUrl.lastIndexOf("site-b");
                }
                if (siteStartIndex > -1 && siteStartIndex > intSpecIndex) {
                    lSiteName = actUrl.substring(siteStartIndex, siteStartIndex + 6);
                }

                if (!lSiteName && actName === "delete") {
                    logger.debug(intentTypeName + " " + intInstName + ": Calling getUacValidationObjects, processing getNeList on current intent config for uac validation.");
                    return getNeList(lCurrentIntConf);
                }

                if (lSiteName) {  // site name on the url
                    if (lCurrentIntConf && lCurrentIntConf[lSiteName] && lCurrentIntConf[lSiteName]["device-id"]) {
                        lNeSet.add(lCurrentIntConf[lSiteName]["device-id"])
                    }
                } else {
                    if (actName === "patch") {
                        // site-a/b could be in the payload with/without device-id
                        if (intConf) {
                            if (intConf["site-a"]) {
                                if (intConf && intConf["site-a"] && intConf["site-a"]["device-id"]) {
                                    lNeSet.add(intConf["site-a"]["device-id"])
                                } else if (lCurrentIntConf && lCurrentIntConf["site-a"] && lCurrentIntConf["site-a"]["device-id"]) {
                                    lNeSet.add(lNeSet["site-a"]["device-id"]);
                                }
                            }
                            if (intConf["site-b"]) {
                                if (intConf && intConf["site-b"] && intConf["site-b"]["device-id"]) {
                                    lNeSet.add(intConf["site-b"]["device-id"])
                                } else if (lCurrentIntConf && lCurrentIntConf["site-b"] && lCurrentIntConf["site-b"]["device-id"]) {
                                    lNeSet.add(lNeSet["site-b"]["device-id"]);
                                }
                            }
                        }
                    }
                }
            } else {
                if (actName === "delete") {
                    logger.debug(intentTypeName + " " + intInstName + ": Calling getUacValidationObjects, processing getNeList on current intent config for uac validation.");
                    return getNeList(lCurrentIntConf);
                } else if (actName === "patch") {
                    pldNeSet = getNeList(plSvcLevelConfig, true, lCurrentIntConf);
                    for (const value of pldNeSet) {
                        lNeSet.add(value);
                    }
                }
            }
        }

        if (lNeSet.size > 0) {
            lNeIds = "";
            lNeSet.forEach(function (aInNeId) {
                lNeIds =
                    lNeIds + "<ne-id xmlns=\"http://www.nokia.com/management-solutions/" + "uac-validation-intent" + "\">"
                    + aInNeId + "</ne-id>"
            })
        }

        return lNeIds;
    }

    function getPutNeList(actUrl, intConf, xml2JsonFn) {
        let lCurrentIntConf = xml2JsonFn(input.getIntentConfiguration())['configuration'][intentTypeName];
        let lNeSet = new Set();
        let lNeIds;
        let lIntName = input.getTarget();

        if (actUrl) {
            let intTargetIndex = actUrl.lastIndexOf("intent=" + lIntName + ",evpn-epipe");
            if (intTargetIndex > -1) {
                let intSpecIndex = actUrl.lastIndexOf("intent-specific-data/evpn-epipe:evpn-epipe");
                if (intSpecIndex === -1) {
                    let payloadNeSet = new Set();
                    if (intConf) {
                        let payloadIntKey;
                        let payloadKeys = Object.keys(intConf);
                        for (let i = 0; i < payloadKeys.length; i++) {
                            if (payloadKeys[i] === "intent" || payloadKeys[i].lastIndexOf(":intent") > -1) {
                                payloadIntKey = payloadKeys[i];
                                break;
                            }
                        }

                        if (intConf && intConf[payloadIntKey] && intConf[payloadIntKey][0] && intConf[payloadIntKey][0]["intent-specific-data"] && intConf[payloadIntKey][0]["intent-specific-data"]["evpn-epipe:evpn-epipe"]) {
                            payloadNeSet = getNeList(intConf[payloadIntKey][0]["intent-specific-data"]["evpn-epipe:evpn-epipe"], true, false, lCurrentIntConf);
                        }
                    }
                    logger.debug(intentTypeName + " " + intInstName + ": Calling getUacValidationObjects, processing getNeList on current intent config for uac validation.");
                    lNeSet = getNeList(lCurrentIntConf, true);
                    payloadNeSet.forEach(function (neId) {
                        lNeSet.add(neId)
                    });
                } else {
                    let siteIndex = actUrl.lastIndexOf("site-a");
                    let siteName = "site-a";
                    if (siteIndex === -1) {
                        siteIndex = actUrl.lastIndexOf("site-b");
                        siteName = "site-b";
                    }
                    if (siteIndex === -1) {
                        let payloadNeSet = getNeList(intConf, true, false, lCurrentIntConf);
                        logger.debug(intentTypeName + " " + intInstName + ": Calling getUacValidationObjects, processing getNeList on current intent config for uac validation.");
                        lNeSet = getNeList(lCurrentIntConf, true);
                        payloadNeSet.forEach(function (neId) {
                            lNeSet.add(neId)
                        });
                    } else {
                        if (siteIndex > -1) {
                            if (intConf && intConf["device-id"]) {
                                lNeSet.add(intConf["device-id"]);
                            } else {
                                if (lCurrentIntConf && lCurrentIntConf[siteName] && lCurrentIntConf[siteName]["device-id"]) {
                                    lNeSet.add(lCurrentIntConf[siteName]["device-id"]);
                                }
                            }
                        }
                    }
                }
            }
        }

        if (lNeSet.size > 0) {
            lNeIds = "";
            lNeSet.forEach(function (aInNeId) {
                lNeIds =
                    lNeIds + "<ne-id xmlns=\"http://www.nokia.com/management-solutions/" + "uac-validation-intent"
                    + "\">"
                    + aInNeId + "</ne-id>"
            })
        }

        return lNeIds;
    }

    return sfUtils.retrieveUacObjects(input, getNeList, getNeListWithUrl, getPutNeList, intentTypeName, intInstName);
}

//UI Suggest Calls
function suggestDeviceNames(context) {
    return nspRestconfFwk.getNe(context.getInputValues()["arguments"]["device-id"],context.getInputValues()["arguments"]["__token"]);
}

function suggestCustomerNames(context) {
    return nspRestconfFwk.getCustomer();
}

function suggestPortIdsSiteA(context) {
    var ret = [];
    logger.info("suggestPortIdsSiteA getInputValues:" + context.getInputValues());
    try {
        var deviceId = context.getInputValues()["arguments"]["__parent"]["site-a"]["device-id"];
        var portSuggestString = context.getInputValues()["arguments"]["port-id"];
        if (deviceId)
            ret = nspRestconfFwk.getAccessHybridPortByNe(deviceId, portSuggestString);
    } catch (e) {
        logger.error("" + e.message);
    }
    return ret;
}

function suggestPortIdsSiteB(context) {
    var ret = [];
    logger.info("suggestPortIdsSiteB getInputValues:" + context.getInputValues());
    try {
        var deviceId = context.getInputValues()["arguments"]["__parent"]["site-b"]["device-id"];
        var portSuggestString = context.getInputValues()["arguments"]["port-id"];
        if (deviceId)
            ret = nspRestconfFwk.getAccessHybridPortByNe(deviceId, portSuggestString);
    } catch (e) {
        logger.error("" + e.message);
    }
    return ret;
}

function suggestPortIdsMultiHomingA(context) {
    var ret = [];
    logger.info("suggestPortIdsMultiHomingA getInputValues:" + context.getInputValues());
    try {
        var deviceId = context.getInputValues()["arguments"]["site-a"]["multi-homing-site-details"]["device-id"];
        var portSuggestString = context.getInputValues()["arguments"]["port-id"];
        if (deviceId)
            ret = nspRestconfFwk.getAccessHybridPortByNe(deviceId, portSuggestString);
    } catch (e) {
        logger.error("" + e.message);
    }
    return ret;
}

function suggestPortIdsMultiHomingB(context) {
    var ret = [];
    logger.info("suggestPortIdsMultiHomingB getInputValues:" + context.getInputValues());
    try {
        var deviceId = context.getInputValues()["arguments"]["site-b"]["multi-homing-site-details"]["device-id"];
        var portSuggestString = context.getInputValues()["arguments"]["port-id"];
        if (deviceId)
            ret = nspRestconfFwk.getAccessHybridPortByNe(deviceId, portSuggestString);
    } catch (e) {
        logger.error("" + e.message);
    }
    return ret;
}

function suggestGetAccountingPolicySiteA(context) {
    var deviceId = context.getInputValues()["arguments"]["__parent"]["site-a"]["device-id"];

    var typeVersionMap={};
    if(deviceId!==''){
        typeVersionMap = sfUtils.getTypeVersionMediation(deviceId);
    }
    if (typeVersionMap["mediation"] === "mdc") {
        return nspRestconfFwk.getAccountingPoliciesMdc(deviceId, typeVersionMap["alienMediatorName"]);
    } else if (typeVersionMap["mediation"] === "nfmp") {
        return nspRestconfFwk.getAccountingPoliciesNfmp(deviceId, typeVersionMap["alienMediatorName"]);
    } else {
        return [];
    }
}

function suggestGetAccountingPolicySiteB(context) {
    var deviceId = context.getInputValues()["arguments"]["__parent"]["site-b"]["device-id"];

    var typeVersionMap={};
    if(deviceId!==''){
        typeVersionMap = sfUtils.getTypeVersionMediation(deviceId);
    }
    if (typeVersionMap["mediation"] === "mdc") {
        return nspRestconfFwk.getAccountingPoliciesMdc(deviceId, typeVersionMap["alienMediatorName"]);
    } else if (typeVersionMap["mediation"] === "nfmp") {
        return nspRestconfFwk.getAccountingPoliciesNfmp(deviceId, typeVersionMap["alienMediatorName"]);
    } else {
        return [];
    }
}

function suggestGetConnectionProfileSiteA(context) {
    let deviceId = context.getInputValues()["arguments"]["__parent"]["site-a"]["device-id"];

    let typeVersionMap={};
    if(deviceId!==''){
        typeVersionMap = sfUtils.getTypeVersionMediation(deviceId);
    }
    if (typeVersionMap["mediation"] === "mdc") {
        return nspRestconfFwk.getConnectionProfilesMdc(deviceId, typeVersionMap["alienMediatorName"]);
    } else if (typeVersionMap["mediation"] === "nfmp") {
        return nspRestconfFwk.getConnectionProfilesNfmp(deviceId, typeVersionMap["alienMediatorName"]);
    } else {
        return [];
    }
}

function suggestGetConnectionProfileSiteB(context) {
    let deviceId = context.getInputValues()["arguments"]["__parent"]["site-b"]["device-id"];

    let typeVersionMap={};
    if(deviceId!==''){
        typeVersionMap = sfUtils.getTypeVersionMediation(deviceId);
    }
    if (typeVersionMap["mediation"] === "mdc") {
        return nspRestconfFwk.getConnectionProfilesMdc(deviceId, typeVersionMap["alienMediatorName"]);
    } else if (typeVersionMap["mediation"] === "nfmp") {
        return nspRestconfFwk.getConnectionProfilesNfmp(deviceId, typeVersionMap["alienMediatorName"]);
    } else {
        return [];
    }
}
